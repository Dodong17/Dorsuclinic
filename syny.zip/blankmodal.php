<?php
function Modals()
{
    ob_start();
?>
 
    <div id="delete_modal" class="modal" style="display: none;">
        <div class="w-[90%] md:w-[30%] max-h-[80vh] bg-white rounded-2xl p-5 overflow-y-scroll flex justify-center items-center flex-col gap-4">
        <div class="flex justify-end items-center gap-3">
                        <div class="px-6 py-2 text-white bg-red rounded-2xl cursor-pointer hover:bg-red/80" onclick="closeAddModal()">Cancel</div>
                        <button id="submit_button" type="submit" class="px-6 py-2 text-white bg-blue rounded-2xl hover:bg-blue/80">Add</button>
                    </div>
        </div>
    </div>



<?php
    return ob_get_clean();
}
?>