/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './**/*.php', 
    './**/*.html', 
  ],
  theme: {
    extend: {
      fontFamily: {
        varela: ['VarelaRound', 'sans-serif'],
      },
      colors: {
        "black": "#1A1A1A",
        "white": "#EFF1F3",
        "green": "#22C7B8",
        "orange": "#FF8C00",
        "blue": "#003399",
        "yellow": "#ffcc00",
        "red": "#DE3733",
  
      },
    },
  },
  plugins: [],
}
