<?php
function MainLayout($bodyContent, $directoryName)
{
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>My Project</title>
        <link rel="stylesheet" href="/<?php echo $directoryName ?>/assets/css/output.css">
        <link rel="stylesheet" href="/<?php echo $directoryName ?>/assets/css/notyf.min.css">
        <link rel="stylesheet" href="/<?php echo $directoryName ?>/assets/font-awesome/css/font-awesome.min.css">
        <!-- Include Flatpickr CSS -->
        <link rel="stylesheet" href="/<?php echo $directoryName ?>/node_modules/flatpickr/dist/flatpickr.min.css">
    </head>

    <body class="font-varela bg-black text-white">
        <div class="absolute top-0 left-0 w-screen h-screen z-50 bg-black flex justify-center items-center" id="loading-screen">
            <p class="text-white">Loading....</p>
        </div>

        <?php include $bodyContent; ?>

        <!-- Include JavaScript libraries -->
        <script src="/<?php echo $directoryName ?>/node_modules/axios/dist/axios.min.js"></script>
        <script src="/<?php echo $directoryName ?>/node_modules/jsonwebtoken/index.js"></script>
        <script src="/<?php echo $directoryName ?>/assets/js/app.js"></script>
        <script src="/<?php echo $directoryName ?>/assets/js/notyf.min.js"></script>
        <!-- Include Flatpickr JS -->
        <script src="/<?php echo $directoryName ?>/node_modules/flatpickr/dist/flatpickr.min.js"></script>
    </body>

    </html>
<?php
}
?>
