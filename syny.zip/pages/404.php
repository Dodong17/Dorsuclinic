<?php 
include 'config/database.php';

?>

<h1>404 - Page Not Found</h1>
<p>Sorry, we couldn't find the page you're looking for.</p>


<script>

    window.onload = document.getElementById('loading-screen').style.display = "none";
</script>