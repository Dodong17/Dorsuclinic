<?php
include 'config/database.php';
$role = "user";

?>

<script>
    const validateToken = async () => {
        document.getElementById("loading-screen").style.display = "flex";

        try {
            const response = await axios.post(`/<?php echo $directoryName; ?>/api/VerifyToken.php`, {}, {
                headers: {
                    "Authorization": "Bearer " + localStorage.getItem("token")
                }
            });


            if (response.data.status === "success") {
                const user = response.data.data.data;
                if (user.role !== "<?php echo $role; ?>") {
                    alert("Access denied. You do not have permission to view this page.");
                    window.location.href = "/<?php echo $directoryName; ?>/";
                } else {
                    document.getElementById("page-id").style.display = "flex";
                }
            } else {
                alert(response.data.message || "Invalid token. Please log in again.");
                window.location.href = "/<?php echo $directoryName; ?>/";
                localStorage.removeItem("token");
                localStorage.removeItem("id");
                localStorage.removeItem("role");
            }
        } catch (error) {
            localStorage.removeItem("token");
            localStorage.removeItem("id");
            localStorage.removeItem("role");
            alert("Unauthorized. Please log in again.");
            window.location.href = "/<?php echo $directoryName; ?>/";
        }finally{
        document.getElementById("loading-screen").style.display = "none";

        }
    }
    window.onload = validateToken;
</script>