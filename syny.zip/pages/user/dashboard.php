<?php
require "template/Validator.php";
include 'template/Sidebar.php';

include "components/DashboardModal.php";
include "scripts/dashboard.php";
include "scripts/modals.php";

function Content()
{
    ob_start();
?>

    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        h1 {
            font-size: 24px;
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }

        .section-title {
            font-size: 20px;
            color: #000;
            margin-bottom: 15px;
        }

        .section-description {
            font-size: 16px;
            color: #000;
            margin-bottom: 25px;
        }

        #tooth-container {
            display: grid;
            grid-template-columns: repeat(8, 1fr);
            gap: 12px;
            margin-top: 20px;
        }

        #tooth-container .tooth-item {
            background-color: #ecf0f1;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            color: #000;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease, background-color 0.3s ease;
        }

        #tooth-container .tooth-item:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
            background-color: #bdc3c7;
        }

        @media (max-width: 768px) {
            #tooth-container {
                grid-template-columns: repeat(4, 1fr);
            }
        }

        #table-container {
            margin-top: 40px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .btn {
            background-color: #3498db;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #2980b9;
        }
    </style>
<div class="container">
    <h1 id="welcome-message" style="font-size: 2.5em; line-height: 1.2;">
        Welcome to DORSU Clinic Appointment System. Book your appointment at ease.
    </h1>

    <div class="section-title">Tooth Extraction History</div>
    <p class="section-description">
        Here you can view the history of tooth extractions performed at the clinic.
    </p>

    <div id="tooth-container">
        <div class="tooth-item">Tooth 1</div>
        <div class="tooth-item">Tooth 2</div>
        <div class="tooth-item">Tooth 3</div>
        <div class="tooth-item">Tooth 4</div>
        <div class="tooth-item">Tooth 5</div>
        <div class="tooth-item">Tooth 6</div>
        <div class="tooth-item">Tooth 7</div>
        <div class="tooth-item">Tooth 8</div>
    </div>

    <div id="table-container">
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th style="border: 1px solid #ddd; padding: 8px;">Date</th>
                    <th style="border: 1px solid #ddd; padding: 8px;">Tooth ID</th>
                    <th style="border: 1px solid #ddd; padding: 8px;">Procedure</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="border: 1px solid #ddd; padding: 8px;">12/12/2024</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">Tooth 3</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">Extraction</td>
                </tr>
            </tbody>
        </table>
    </div>

    <div style="text-align: center; margin-top: 30px;" class="text-black">
    </div>
</div>

<script>
    const fullName = localStorage.getItem("full_name");
    if (fullName) {
        const welcomeMessage = document.getElementById("welcome-message");
        welcomeMessage.innerHTML = `Welcome to DORSU Clinic Appointment System, <span style="font-weight: bold;">${fullName}</span>. Book your appointment at ease.`;
    }
</script>



<?php
    return ob_get_clean();
}
?>

<?php
Sidebar(Content(), Modals());
?>
