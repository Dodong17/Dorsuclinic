<?php
require "template/Validator.php";
include 'template/Sidebar.php';

include "components/BookingModal.php";




include "scripts/modals.php";
include "scripts/booking.php";


function Content()
{
    ob_start();
?>

    <div class="  w-full h-screen max-h-[calc(100vh-100px)] overflow-y-scroll p-5 text-black">
        <div class="flex justify-end items-center p-5 md:px-10 gap-3">

            <!-- <select name="find_date" id="find_date" class="py-3 px-5 rounded-2xl text-black" style="color: black;" onchange="handleFindDate(this.value)">
                <option value="">🔍 Find by date</option>
            </select> -->
            <button class="bg-blue py-3 px-5 text-white rounded-2xl hover:bg-blue/90" onclick="openBookingModal()">Make Booking</button>
        </div>
        <div class=" px-10 flex flex-col">

            <table id="dataTable" class="w-full text-left text-gray-700 bg-white shadow-md rounded-2xl overflow-hidden">
                <thead class="bg-blue text-white">
                    <tr>
                        <th class="p-4 font-semibold">Booking Date</th>
                        <th class="p-4 font-semibold">Session</th>
                        <th class="p-4 font-semibold">Status</th>
                        <th class="p-4 font-semibold">Assigned Doctor</th>
                        <th class="p-4 font-semibold">Actions</th>
                    </tr>
                </thead>
                <tbody id="tableBody">
                </tbody>
            </table>
            <div class="text-black py-5 flex justify-between items-center">
                <p>Showing <span id="showing">0</span> of <span id="total">0</span> bookings</p>
                <div>
                    <button class="prev-btn bg-blue text-white rounded-2xl px-5 py-2">Previous</button>
                    <button class="next-btn bg-blue text-white rounded-2xl px-5 py-2">Next</button>
                </div>
            </div>


        </div>


    </div>

<?php
    return ob_get_clean();
}
?>

<?php
// Call the Sidebar function and pass the content
Sidebar(Content(), Modals());
?>