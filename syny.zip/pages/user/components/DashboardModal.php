<?php
function Modals()
{
    ob_start();
?>

    <div id="tooth_details_modal" class="modal z-50" style="display: none;">
        <div class="w-[90%] md:w-[30%] max-h-[80vh] bg-white rounded-2xl p-5 overflow-y-scroll flex justify-center items-center flex-col gap-4">
            <!-- Modal Content -->
            <div class="flex justify-center items-center gap-3">
                <div class="text-xl font-semibold">Details</div>
            </div>

            <!-- Date -->
            <div class="flex justify-start w-full gap-2">
                <div class="font-medium text-gray-700">Date:</div>
                <div id="formatted-date" class="text-gray-900"></div>
            </div>

            <!-- Description -->
            <div class="flex justify-start w-full gap-2">
                <div class="font-medium text-gray-700">Description:</div>
                <div id="description" class="text-gray-900">11</div>
            </div>

            <!-- Teeth Number -->
            <div class="flex justify-start w-full gap-2">
                <div class="font-medium text-gray-700">Teeth No:</div>
                <div id="teeth-no" class="text-gray-900">32</div>
            </div>

            <!-- Close Button -->
            <div class="flex justify-center items-center gap-3">
                <div class="px-6 py-2 text-white bg-red rounded-2xl cursor-pointer hover:bg-red/80" onclick="closeToothDetailsModal()">Close</div>
            </div>
        </div>
    </div>



<?php
    return ob_get_clean();
}
?>