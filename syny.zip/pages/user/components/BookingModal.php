<?php
function Modals()
{
    ob_start();
?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.6.9/flatpickr.min.css" rel="stylesheet">

<!-- Booking Modal -->
<div id="booking_modal" class="modal" style="display: none;">
    <div class="modal-content" style="
        display: flex;
        gap: 30px;
        width: 90%;
        max-width: 900px;
        max-height: 85vh;
        background: linear-gradient(135deg, #2c3e50, #34495e);
        border-radius: 16px;
        padding: 40px;
        overflow-y: auto;
        box-shadow: 0px 20px 80px rgba(0, 0, 0, 0.4);
        position: relative;
        transition: all 0.3s ease-in-out;
        opacity: 0.9;
    ">
        <!-- Left Column: Form -->
        <div style="flex: 2; position: relative;">
            <!-- Close button -->
            <div class="close-btn" onclick="closeBookingModal()" style="
                position: absolute;
                top: 20px;
                right: 20px;
                font-size: 2rem;
                font-weight: bold;
                color: #bbb;
                cursor: pointer;
                transition: color 0.3s ease;
            ">&times;</div>

            <!-- Round Logo -->
            <div style="text-align: center; margin-bottom: 20px;">
                <div style=" 
                    width: 60px; 
                    height: 60px; 
                    border-radius: 50%; 
                    background-color: #3498db; 
                    display: flex; 
                    justify-content: center; 
                    align-items: center; 
                    margin: 0 auto;">
                    <i class="fas fa-calendar-alt" style="font-size: 1.5rem; color: #fff;"></i>
                </div>
            </div>

            <!-- Title -->
            <h1 style="
                font-size: 2rem;
                font-weight: 700;
                color: #fff;
                text-align: center;
                margin-bottom: 30px;
                font-family: 'Poppins', sans-serif;
                letter-spacing: 1px;
            ">Make a Booking!</h1>

            <!-- Form -->
            <form onsubmit="createBooking(event)">
                <!-- Date -->
                <div style="margin-bottom: 20px;">
                    <label for="date2" style="
                        display: block;
                        font-size: 1rem;
                        font-weight: 600;
                        color: #ddd;
                        margin-bottom: 8px;
                    ">Select Date</label>
                    <input type="text" name="date" id="date2" placeholder="Select date" 
                        onchange="updatePreview('date', this.value); getSlot(this.value)" 
                        style="
                            width: 100%;
                            padding: 14px;
                            border-radius: 12px;
                            border: 1px solid #555;
                            background: #1e2a35;
                            font-size: 1rem;
                            color: #fff;
                            transition: all 0.3s;
                            font-family: 'Poppins', sans-serif;
                            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.2);
                        " class="glow-input">
                    <p id="date_error_message" style="color: #e74c3c; font-size: 0.9rem; margin-top: 5px;"></p>
                </div>

                <!-- Service -->
                <div style="margin-bottom: 20px;">
                    <label for="service" style="
                        display: block;
                        font-size: 1rem;
                        font-weight: 600;
                        color: #ddd;
                        margin-bottom: 8px;
                    ">Select Service</label>
                    <select name="service" id="service" required style="
                        width: 100%;
                        padding: 14px;
                        border-radius: 12px;
                        border: 1px solid #555;
                        background: #1e2a35;
                        font-size: 1rem;
                        color: #fff;
                        font-family: 'Poppins', sans-serif;
                        transition: all 0.3s;
                        box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.2);
                    " onchange="updatePreview('service', this.value)" class="glow-input">
                        <option value="">Select service</option>
                        <option value="Consultation">Consultation</option>
                        <option value="Follow-up">Follow-up</option>
                        <option value="Treatment">Treatment</option>
                    </select>
                </div>

                <!-- Session -->
                <div style="margin-bottom: 20px;">
                    <label for="session" style="
                        display: block;
                        font-size: 1rem;
                        font-weight: 600;
                        color: #ddd;
                        margin-bottom: 8px;
                    ">Select Session</label>
                    <select name="session" id="session" required style="
                        width: 100%;
                        padding: 14px;
                        border-radius: 12px;
                        border: 1px solid #555;
                        background: #1e2a35;
                        font-size: 1rem;
                        color: #fff;
                        font-family: 'Poppins', sans-serif;
                        transition: all 0.3s;
                        box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.2);
                    " onchange="updatePreview('session', this.value)" class="glow-input">
                        <option value="">Select session</option>
                    </select>
                </div>

                <!-- Action Buttons -->
                <div style="display: flex; justify-content: flex-end; gap: 15px; margin-top: 20px;">
                    <div onclick="closeBookingModal()" style="
                        padding: 12px 20px;
                        border-radius: 12px;
                        background-color: rgba(231, 76, 60, 0.8);
                        color: #fff;
                        font-weight: 600;
                        font-size: 1rem;
                        cursor: pointer;
                        text-align: center;
                        transition: all 0.3s ease-in-out;
                        font-family: 'Poppins', sans-serif;
                    ">
                        Cancel
                    </div>
                    <button type="submit" id="submit_button" style="
                        padding: 12px 20px;
                        border-radius: 12px;
                        background-color: rgba(52, 152, 219, 0.8);
                        color: #fff;
                        font-weight: 600;
                        font-size: 1rem;
                        border: none;
                        cursor: pointer;
                        transition: all 0.3s ease-in-out;
                        font-family: 'Poppins', sans-serif;
                    ">
                        Create
                    </button>
                </div>
            </form>
        </div>

        <!-- Right Column: Preview -->
        <div style="
            flex: 1;
            background: rgba(44, 62, 80, 0.95);
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.3);
            border: 1px solid #555;
        " class="glow-preview">
            <h2 style="
                font-size: 1.5rem;
                font-weight: 600;
                color: #fff;
                margin-bottom: 15px;
                text-align: center;
                font-family: 'Poppins', sans-serif;
            ">Your Booking</h2>
            <div id="preview" style="
                font-size: 1rem;
                color: #ddd;
                font-family: 'Poppins', sans-serif;
                line-height: 1.8;
            ">
                <p><strong>Date:</strong> <span id="preview_date">Not selected</span></p>
                <p><strong>Service:</strong> <span id="preview_service">Not selected</span></p>
                <p><strong>Session:</strong> <span id="preview_session">Not selected</span></p>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.6.9/flatpickr.min.js"></script>
<script>
    flatpickr("#date2", {
        dateFormat: "Y-m-d",
        minDate: "today",  
    });

    function updatePreview(field, value) {
        const previewElement = document.getElementById(`preview_${field}`);
        if (previewElement) {
            previewElement.innerText = value || "Not selected";
        }
    }

    function createBooking(event) {
        event.preventDefault();
        const date = document.getElementById('date2').value;
        const service = document.getElementById('service').value;
        const session = document.getElementById('session').value;

        if (!date || !service || !session) {
            alert('All fields are required!');
            return;
        }

        console.log('Creating booking with:', { date, service, session });
        // Add your booking logic here.
    }

    function getSlot(date) {
        console.log('Selected date:', date);
        fetch(`/api/getSessions?date=${date}`)
            .then(response => response.json())
            .then(data => {
                console.log('Fetched sessions:', data.sessions);
                const sessionDropdown = document.getElementById('session');
                sessionDropdown.innerHTML = '<option value="">Select session</option>';
                data.sessions.forEach(session => {
                    const option = document.createElement('option');
                    option.value = session.id;
                    option.textContent = session.name;
                    sessionDropdown.appendChild(option);
                });
            })
            .catch(error => console.error('Error fetching sessions:', error));
    }

    function closeBookingModal() {
        const modal = document.getElementById('booking_modal');
        modal.style.display = 'none';
    }
</script>
<?php
    return ob_get_clean();
}
