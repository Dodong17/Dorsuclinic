<script>
    function openBookingModal() {
        document.getElementById("booking_modal").style.display = "flex";
        fetchAppointmentSchedule();
        getServices();
        document.getElementById("session").value = "";
    }

    function closeBookingModal() {
        document.getElementById("booking_modal").style.display = "none";
    }

    function openDeleteModal(id) {
        document.getElementById("delete_confirmation_modal").style.display = "flex";
        document.getElementById("confirm_delete_button").setAttribute("data-id", id);
    }

    function closeDeleteModal() {
        document.getElementById("delete_confirmation_modal").style.display = "none";
    }

    function formatDate(dateString) {
        const date = new Date(dateString);
        const options = {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
            hour12: true
        };
        return date.toLocaleString('en-US', options);
    }

    function openToothDetails(data) {

        document.getElementById("tooth_details_modal").style.display = "flex";
        document.getElementById("formatted-date").textContent = formatDate(data.date);
        document.getElementById("description").textContent = data.description;
        document.getElementById("teeth-no").textContent = data.teeth_no;

    }

    function closeToothDetailsModal() {
        document.getElementById("tooth_details_modal").style.display = "none";
    }


    function open_prescription_details(data) {

        fetchPrescriptions(data.id)
    }

    function closePrescriptionDetails(){
        const prescriptionDetails = document.getElementById("prescription_details");
        prescriptionDetails.style.display = "none";
    }

    const fetchPrescriptions = async (booking_id) => {
        const notyf = new Notyf();
        try {
            const res = await axios.post(`/<?php echo $directoryName; ?>/api/fetchPrescriptionByBookingId.php`, {
                booking_id: booking_id
            });

            if (res.status === 200) {
                const prescriptions = res.data;

                const prescriptionDetails = document.getElementById("prescription_details");
                prescriptionDetails.style.display = "flex";
                document.getElementById("prescription-booking-id").textContent = prescriptions[0].booking_id;
                document.getElementById("prescription-user-name").textContent = prescriptions[0].user_name;
                document.getElementById("prescription-doctor-name").textContent = prescriptions[0].doctor_name;
                document.getElementById("prescription-created-at").textContent = prescriptions[0].created_at;
                document.getElementById("prescription-medicine").textContent = prescriptions[0].medicine;
                document.getElementById("prescription-notes").textContent = prescriptions[0].notes;
            } else {
                notyf.error("Error fetching prescriptions");
            }
        } catch (error) {
            console.log(error)
        }
    }
</script>