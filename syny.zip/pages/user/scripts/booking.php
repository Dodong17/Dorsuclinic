<script>
    const fetchAppointmentSchedule = async () => {
        const notyf = new Notyf();

        const date_selector2 = document.getElementById("date2");
        const error_message = document.getElementById("date_error_message");

        console.log(date_selector2.value);

        try {
            // Fetch the appointment schedule
            const response = await axios.get(`/<?php echo $directoryName; ?>/api/appointmentschedule.php`);
            const results = response.data.results;

            console.log(results); // Debugging: Log fetched results

            // Extract available dates from results
            const availableDates = results.map(result => result.date); // Assuming date is in 'YYYY-MM-DD' format
            console.log("Available Dates:", availableDates); // Debugging: Log available dates

            // Calculate the current date in 'YYYY-MM-DD' format
            const today = new Date();
            const currentDate = today.toISOString().split("T")[0];
            console.log("Current Date:", currentDate);

            if (date_selector2) {
                // Clear any existing value or restrictions
                date_selector2.value = "";
                date_selector2.setAttribute("min", currentDate); // Set minimum date to today's date

                // Use a date picker library (e.g., flatpickr) for finer control
                flatpickr(date_selector2, {
                    enable: availableDates.filter(date => date >= currentDate), // Enable only future available dates
                    dateFormat: "Y-m-d", // Match the date format in your results
                });
            }

        

           
        } catch (error) {
            console.error(error);
            notyf.error("Error fetching booking dates");
        }
    };





    const getServices = async () => {
        const notyf = new Notyf();
        const service_selector = document.getElementById("service");
        const role = localStorage.getItem("role"); // Get role from localStorage

        try {
            const response = await axios.get(`/<?php echo $directoryName; ?>/api/services.php`);
            const services = response.data.services;

            // Clear any existing options
            service_selector.innerHTML = "";

            // Add the default "Select service" option
            const defaultOption = document.createElement("option");
            defaultOption.value = "";
            defaultOption.text = "Select service";
            service_selector.appendChild(defaultOption);


            services.forEach(service => {
                const availableRoles = service.available_to.split(",");

                // Check if the role exists in the availableRoles array
                if (availableRoles.includes(role)) {
                    const option = document.createElement("option");
                    option.value = service.service_name;
                    option.text = service.service_name;
                    service_selector.appendChild(option);
                }
            });

        } catch (error) {
            console.error(error);
            notyf.error("Error fetching services");
        }
    };

    const fetchBookings = async (page = 1, limit = 10, query = "") => {
        const notyf = new Notyf();
        axios.interceptors.request.use(
            config => {

                return config;
            },
            error => {
                return Promise.reject(error);
            }
        );

        axios.interceptors.response.use(
            response => {

                return response;
            },
            error => {

                return Promise.reject(error);
            }
        );

        try {
            const response = await axios.get(`/${"<?php echo $directoryName; ?>"}/api/booking.php?user_id=${localStorage.getItem("id")}&page=${page}&limit=${limit}&query=${encodeURIComponent(query)}`);

            const {
                bookings,
                total
            } = response.data;
            // const uniqueDates = new Set();

            // Update table body with fetched doctor data
            const tableBody = document.getElementById('tableBody');
            tableBody.innerHTML = "";
            if (bookings.length > 0) {
                bookings.forEach((item) => {
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-gray-50';
                    row.innerHTML = `
            <td class="px-4 py-3">${item.booking_date}</td>
            <td class="px-4 py-3">${item.session}</td>
            <td class="px-4 py-3">${item.status}</td>
            <td class="px-4 py-3">${item.doctor_name}</td>
            <td class="px-4 py-3 space-x-3">
                
                ${item.status === 'pending' ? `
                    <button onclick='openDeleteModal(${item.id})'>
                        <i class="fa fa-trash-o text-red" style="font-size: 1.5rem;" aria-hidden="true"></i>
                    </button>
                ` : ''}

                 ${item.status === 'completed' ? `
                    <button onclick='open_prescription_details(${JSON.stringify(item)})'>
                        <i class="fa fa-eye text-blue" style="font-size: 1.5rem;" aria-hidden="true"></i>
                    </button>
                ` : ''}
            </td>
        `;
                    tableBody.appendChild(row);
                });
            } else {
                tableBody.innerHTML = `
        <tr>
            <td colspan="5" class="px-4 py-3 text-center text-gray-500">No data found.</td>
        </tr>
    `;
            }

            // const dateSelector = document.getElementById('find_date');
            // dateSelector.innerHTML = ""; // Clear previous options

            // const defaultOption = document.createElement("option");
            // defaultOption.value = "";
            // defaultOption.text = "🔍 Find by date";
            // dateSelector.appendChild(defaultOption);

            // // Add unique booking dates as options
            // uniqueDates.forEach((date) => {
            //     const option = document.createElement("option");
            //     option.value = date; // Set value to the date
            //     option.text = date; // Set text to the date
            //     dateSelector.appendChild(option);
            // });

            // Update pagination display
            const totalPages = Math.ceil(total / limit);
            document.getElementById('showing').textContent = bookings.length;
            document.getElementById('total').textContent = total;

            // Update previous/next button states
            const prevButton = document.querySelector('.prev-btn');
            const nextButton = document.querySelector('.next-btn');
            prevButton.disabled = page === 1;
            nextButton.disabled = page === totalPages;

            // Add event listeners for pagination
            prevButton.onclick = () => fetchBookings(page - 1, limit);
            nextButton.onclick = () => fetchBookings(page + 1, limit);
        } catch (error) {
            console.error('Error loading doctors:', error);
            tableBody.innerHTML = `<td colspan="5" class="px-4 py-3">Error fetching bookings</td>`;

        }
    }

    window.addEventListener("load", () => fetchBookings(1, 10, ""))


    const getSlot = async (date) => {
        const notyf = new Notyf();
        const session_selector = document.getElementById("session");
        console.log(date);

        try {
            // Clear any existing options in the session selector
            session_selector.innerHTML = "";

            // Fetch the slots for the selected date
            const response = await axios.get(`/<?php echo $directoryName; ?>/api/getslot.php?date=${date}`);
            const data = response.data[0]; // Assuming you only get one object in the response



            // Add the default "Select session" option
            const defaultOption = document.createElement("option");
            defaultOption.value = "";
            defaultOption.text = "Select session";
            session_selector.appendChild(defaultOption);

            if (response.status === 200) {
                // Add the Morning Session option if available
                const morningSession = document.createElement("option");
                morningSession.value = "Morning Session";
                morningSession.text = `Morning Session (${data.morning_slot})`;

                // Disable option if the morning_slot is 0
                if (data.morning_slot === 0) {
                    morningSession.disabled = true;
                    morningSession.text = "Morning Session (No avilable slot)";
                }

                session_selector.appendChild(morningSession);

                // Add the Afternoon Session option if available
                const afternoonSession = document.createElement("option");
                afternoonSession.value = "Afternoon Session";
                afternoonSession.text = `Afternoon Session (${data.afternoon_slot})`;

                // Disable option if the afternoon_slot is 0
                if (data.afternoon_slot === 0) {
                    afternoonSession.disabled = true;
                    afternoonSession.text = "Afternoon Session (No avilable slot)";
                }

                session_selector.appendChild(afternoonSession);
            } else {
                notyf.error("Error fetching sessions");
            }

        } catch (error) {
            const defaultOption = document.createElement("option");
            defaultOption.value = "";
            defaultOption.text = "Select session";
            session_selector.appendChild(defaultOption);
            // notyf.error("Error fetching sessions");
        }
    };


    const createBooking = async (event) => {
        event.preventDefault();
        const notyf = new Notyf();
        const date = document.getElementById("date2").value;
        const session = document.getElementById("session").value;
        const service = document.getElementById("service").value;

        try {
            const response = await axios.post(`/<?php echo $directoryName; ?>/api/booking.php`, {
                user_id: localStorage.getItem("id"),
                booking_date: date,
                session: session,
                service: service
            });
            if (response.status === 200) {
                notyf.success("Booking created successfully");
                date.value = "";
                service.value = "";
                session.value = "";
                fetchBookings(1, 10, "");
                closeBookingModal();
            } else {
                notyf.error("Error creating booking");
            }
        } catch (error) {
            notyf.error("Error creating booking");
        }
    }

    function handleFindDate(date) {
        fetchBookings(date);
    }

    const deleteBooking = async () => {
        const notyf = new Notyf();
        const deleteButton = document.getElementById("confirm_delete_button");
        const id = deleteButton.getAttribute("data-id");

        // Set loading state
        deleteButton.innerText = "Deleting...";
        deleteButton.disabled = true;

        try {
            const response = await axios.delete(`/<?php echo $directoryName; ?>/api/booking.php?id=${id}`);

            if (response.status === 200) {
                notyf.success("Booking deleted successfully");
                fetchBookings(1, 10, "");
                closeDeleteModal();
            } else {
                notyf.error("Error deleting booking");
            }
        } catch (error) {
            notyf.error("Error deleting booking");
        } finally {
            // Reset button state
            deleteButton.innerText = "Delete";
            deleteButton.disabled = false;
        }
    };
</script>