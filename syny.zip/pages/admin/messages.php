<?php
require "template/Validator.php";
include 'template/Sidebar.php';
include 'config/database.php';
include 'scripts/messages/messages_data.php';

function Content()
{
    ob_start();
?>

<style>
    .unread-indicator {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background-color: red;
        margin-left: 10px;
        display: inline-block;
    }
</style>

<div class="flex w-full h-screen max-h-[calc(100vh-100px)] text-black">
    <div class="w-1/3 border-r border-gray-300 p-5 overflow-y-auto relative">
        <input type="text"
            class="w-full p-3 border border-gray-300 rounded-lg mb-2"
            placeholder="Search contacts"
            oninput="handleSearch(this.value)">
        <h2 class="text-lg font-semibold mb-4">Contacts</h2>
        <ul class="space-y-2" id="contact-list">
        </ul>
    </div>

    <div class="flex-1 p-5 overflow-hidden h-full">
        <div class="bg-white rounded-lg shadow p-4 h-full flex justify-center items-center flex-col gap-4" id="no-conversation-view">
            Please select from the contacts list to start a conversation.
        </div>
        <div class="bg-white rounded-lg shadow p-4 h-full flex flex-col" id="conversation-view" style="display: none;">
            <div class="overflow-y-auto flex-1 mb-4">
                <div class="space-y-4 max-h-[500px] h-full overflow-y-auto" id="message-container">
                </div>
            </div>
            <div class="mt-4">
                <input type="text" id="message-input" class="w-full p-3 border border-gray-300 rounded-lg" placeholder="Type a message...">
                <button id="send-button" class="bg-blue text-white rounded-lg p-3 mt-2 w-full hover:bg-blue/80 transition duration-200">Send</button>
            </div>
        </div>
    </div>
</div>

<?php
    return ob_get_clean();
}

Sidebar(Content(), "");
?>
