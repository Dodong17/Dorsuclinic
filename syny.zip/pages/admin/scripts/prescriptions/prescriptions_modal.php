<script>
    function openPrescriptionDetails(data) {
        // Populate modal fields

        const formattedDate = new Date(data.created_at).toLocaleString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
        });
        document.getElementById('prescription-booking-id').textContent = data.booking_id;
        document.getElementById('prescription-user-name').textContent = data.user_name;
        document.getElementById('prescription-doctor-name').textContent = data.doctor_name;
        document.getElementById('prescription-created-at').textContent = formattedDate;
        document.getElementById('prescription-medicine').textContent = data.medicine;
        document.getElementById('prescription-notes').textContent = data.notes;

        // Display the modal
        document.getElementById('prescription_details').style.display = 'flex';
    }

    function closePrescriptionDetails() {
        document.getElementById('prescription_details').style.display = 'none';
    }
</script>