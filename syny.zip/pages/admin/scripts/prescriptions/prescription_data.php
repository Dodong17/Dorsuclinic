<script>
    const fetchPrescriptions = async (page = 1, limit = 10, query = "") => {
        const notyf = new Notyf();
        axios.interceptors.request.use(
            config => {

                return config;
            },
            error => {
                return Promise.reject(error);
            }
        );

        axios.interceptors.response.use(
            response => {

                return response;
            },
            error => {

                return Promise.reject(error);
            }
        );

        try {
            const response = await axios.get(`/${"<?php echo $directoryName; ?>"}/api/prescriptions.php?page=${page}&limit=${limit}&query=${encodeURIComponent(query)}`);

            const {
                prescriptions,
                total
            } = response.data;
            // const uniqueDates = new Set();

            // Update table body with fetched doctor data
            const tableBody = document.getElementById('tableBody');
            tableBody.innerHTML = "";
            if (prescriptions.length > 0) {

                prescriptions.forEach((item) => {
                    // uniqueDates.add(item.booking_date);
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-gray-50';
                    row.innerHTML = `
                    <td class="px-4 py-3">${item.booking_id}</td>
                    <td class="px-4 py-3">${item.user_name}</td>
                    <td class="px-4 py-3">${item.doctor_name}</td>
                    <td class="px-4 py-3">${item.medicine}</td>
                      <td class="px-4 py-3">${item.notes}</td>
                         <td class="px-4 py-3 space-x-3">
                        <button onclick='openPrescriptionDetails(${JSON.stringify(item)})'><i class="fa fa-eye text-blue" style="font-size: 1.5rem;" aria-hidden="true"></i></button>
                    </td>
                    

                `;

                    tableBody.appendChild(row);
                });
            } else {
                tableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="px-4 py-3 text-center text-gray-500">No data found.</td>
                </tr>
            `;
            }

            // Update pagination display
            const totalPages = Math.ceil(total / limit);
            document.getElementById('showing').textContent = prescriptions.length;
            document.getElementById('total').textContent = total;

            // Update previous/next button states
            const prevButton = document.querySelector('.prev-btn');
            const nextButton = document.querySelector('.next-btn');
            prevButton.disabled = page === 1;
            nextButton.disabled = page === totalPages;

            // Add event listeners for pagination
            prevButton.onclick = () => fetchPrescriptions(page - 1, limit);
            nextButton.onclick = () => fetchPrescriptions(page + 1, limit);
        } catch (error) {
            console.error('Error loading doctors:', error);
            tableBody.innerHTML = `<td colspan="5" class="px-4 py-3">Error fetching prescriptions</td>`;

        }

    }

    window.addEventListener("load", () => fetchPrescriptions(1, 10, ""))
</script>