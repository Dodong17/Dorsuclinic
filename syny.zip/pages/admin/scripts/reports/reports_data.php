<script>
    const fetchCompleted = async (page = 1, limit = 10, query = "") => {
        const notyf = new Notyf();
        axios.interceptors.request.use(
            config => {

                return config;
            },
            error => {
                return Promise.reject(error);
            }
        );

        axios.interceptors.response.use(
            response => {

                return response;
            },
            error => {

                return Promise.reject(error);
            }
        );

        try {
            const response = await axios.get(`/${"<?php echo $directoryName; ?>"}/api/booking.php?page=${page}&limit=${limit}&query=${encodeURIComponent(query)}&status=completed`);

            const {
                bookings,
                total
            } = response.data;
            const uniqueServices = new Set();
            const uniqueSessions = new Set();

            // const uniqueDates = new Set();

            // Update table body with fetched doctor data
            const tableBody = document.getElementById('tableBody');
            tableBody.innerHTML = "";
            if (bookings.length > 0) {


                bookings.forEach((item) => {
                    // console.log(item)
                    uniqueServices.add(item.service);
                    uniqueSessions.add(item.session);
                    // uniqueDates.add(item.booking_date);
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-gray-50';
                    row.innerHTML = `
                    <td class="px-4 py-3">${item.user_name}</td>
                    <td class="px-4 py-3">${item.booking_date}</td>
                    <td class="px-4 py-3">${item.service}</td>

                    <td class="px-4 py-3">${item.session}</td>
                    <td class="px-4 py-3">${item.status}</td>
                      <td class="px-4 py-3">${item.doctor_name}</td>
                   

                `;
                    tableBody.appendChild(row);
                });
            } else {
                tableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="px-4 py-3 text-center text-gray-500">No data found.</td>
                </tr>
            `;
            }

            const servicesSelect = document.getElementById('services');
            uniqueServices.forEach((service) => {
                const option = document.createElement('option');
                option.value = service;
                option.textContent = service;
                servicesSelect.appendChild(option);
            });

            // Populate the "sessions" select element with unique sessions
            const sessionsSelect = document.getElementById('sessions');
            uniqueSessions.forEach((session) => {
                const option = document.createElement('option');
                option.value = session;
                option.textContent = session;
                sessionsSelect.appendChild(option);
            });
            // const dateSelector = document.getElementById('find_date');
            // dateSelector.innerHTML = ""; // Clear previous options

            // const defaultOption = document.createElement("option");
            // defaultOption.value = "";
            // defaultOption.text = "🔍 Find by date";
            // dateSelector.appendChild(defaultOption);

            // // Add unique booking dates as options
            // uniqueDates.forEach((date) => {
            //     const option = document.createElement("option");
            //     option.value = date; // Set value to the date
            //     option.text = date; // Set text to the date
            //     dateSelector.appendChild(option);
            // });

            // Update pagination display
            const totalPages = Math.ceil(total / limit);
            document.getElementById('showing').textContent = bookings.length;
            document.getElementById('total').textContent = total;

            // Update previous/next button states
            const prevButton = document.querySelector('.prev-btn');
            const nextButton = document.querySelector('.next-btn');
            prevButton.disabled = page === 1;
            nextButton.disabled = page === totalPages;

            // Add event listeners for pagination
            prevButton.onclick = () => fetchBookings(page - 1, limit);
            nextButton.onclick = () => fetchBookings(page + 1, limit);
        } catch (error) {
            console.error('Error loading doctors:', error);
            tableBody.innerHTML = `<td colspan="5" class="px-4 py-3">Error fetching bookings</td>`;

        }
    }

    const exportData = async () => {
        const notyf = new Notyf();
        const export_button = document.getElementById("export_button");
        export_button.innerHTML = "Exporting...";

        const fromDate = document.getElementById("from").value;
        const toDate = document.getElementById("to").value;
        const services = document.getElementById("services").value;
        const sessions = document.getElementById("sessions").value;



        // Validate required fields
        if (!fromDate || !toDate) {
            notyf.error("Please provide both from and to dates.");
            export_button.innerHTML = "Export";
            return;
        }

        try {
            // Construct the URL with conditional query parameters
            let url = `/${"<?php echo $directoryName; ?>"}/api/Export.php?from=${fromDate}&to=${toDate}`;
            if (services) {
                url += `&services=${encodeURIComponent(services)}`;
            }
            if (sessions) {
                url += `&sessions=${encodeURIComponent(sessions)}`;
            }

            // Use fetch to validate the URL and response before redirecting
            const response = await fetch(url);

            if (!response.ok) {
                throw new Error('No data found');
            }

            // If the response is okay, initiate download by redirecting
            window.location.href = url;
        } catch (error) {
            // Handle errors
            notyf.error(`An error occurred: ${error.message}`);
            console.error(error);
        } finally {
            export_button.innerHTML = "Export";
        }
    };


    window.addEventListener("load", () => fetchCompleted(1, 10, ""))
</script>