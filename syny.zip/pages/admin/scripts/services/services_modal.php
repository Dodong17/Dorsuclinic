<script>
    function openAddServiceModal(){
        document.getElementById("add_service").style.display = "flex";
    }
    function closeAddServiceModal(){
        document.getElementById("add_service").style.display = "none";
    }

    function openEditServiceModal(item){
        // console.log(item.id)
        document.getElementById("service_id").value = item.id;
        document.getElementById("edit_service_name").value = item.service_name;
        document.getElementById("edit_faculty_cb").checked = item.available_to.includes("faculty");
        document.getElementById("edit_staff_cb").checked = item.available_to.includes("staff");
        document.getElementById("edit_student_cb").checked = item.available_to.includes("student");
        document.getElementById("edit_service").style.display = "flex";
    }

    function closeEditServiceModal(){
        document.getElementById("edit_service").style.display = "none";
    }


    
</script>