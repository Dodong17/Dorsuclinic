<script>
    const submitAddService = async (event) => {
    const notyf = new Notyf();
    const availToError = document.getElementById("available_to_error");
    event.preventDefault();
    try {
        // Hide the error message initially
        availToError.style.display = "none";

        // Collect checkbox states
        const studentChecked = document.getElementById('student_cb').checked;
        const facultyChecked = document.getElementById('faculty_cb').checked;
        const staffChecked = document.getElementById('staff_cb').checked;

        const selectedRoles = [];

        if (!studentChecked && !facultyChecked && !staffChecked) {
            notyf.error("At least 1 available option is required.");
            availToError.style.display = "block";
            return;
        }

        if (studentChecked) {
            selectedRoles.push('student');
        }
        if (facultyChecked) {
            selectedRoles.push('faculty');
        }
        if (staffChecked) {
            selectedRoles.push('staff');
        }

        const rolesString = selectedRoles.join(', ');

        // Collect and validate schedule fields
        const scheduleDate = document.getElementById('schedule_date').value;
        const morningSlot = parseInt(document.getElementById('morning_slot').value, 10) || 0;
        const afternoonSlot = parseInt(document.getElementById('afternoon_slot').value, 10) || 0;

        if (!scheduleDate) {
            notyf.error("Schedule date is required.");
            return;
        }

        if (morningSlot < 0 || afternoonSlot < 0) {
            notyf.error("Slot counts cannot be negative.");
            return;
        }

        // Prepare the form data
        const formData = new FormData(event.target);
        formData.append("available_to", selectedRoles);
        formData.append("schedule_date", scheduleDate);
        formData.append("morning_slot", morningSlot);
        formData.append("afternoon_slot", afternoonSlot);

        const dataObject = Object.fromEntries(formData.entries());

        // Send the data to the backend
        const response = await axios.post(`/<?php echo $directoryName; ?>/api/services.php`, dataObject, {
            headers: {
                "Content-Type": "application/json",
            },
        });

        // Handle the response
        if (response.data.status === "success") {
            notyf.success(response.data.message);
            event.target.reset();
            loadServices(1, 10, ""); // Reload the services
        } else if (response.data.status === "failed") {
            notyf.error(response.data.message);
        } else {
            notyf.error("Something went wrong.");
        }
    } catch (error) {
        console.error(error);
        notyf.error("An error occurred while adding the service.");
    }
};


    const updateService = async (event) => {
        event.preventDefault();
        const notyf = new Notyf();
        const service_id = document.getElementById("service_id").value;
        const service_name = document.getElementById("edit_service_name").value;
        const faculty_cb = document.getElementById("edit_faculty_cb").checked;
        const staff_cb = document.getElementById("edit_staff_cb").checked;
        const student_cb = document.getElementById("edit_student_cb").checked;

        const selectedRoles = [];

        if (!student_cb && !faculty_cb && !staff_cb) {
            notyf.error("At least 1 available option is required.");
            availToError.style.display = "block";
            return;
        }

        if (student_cb) {
            selectedRoles.push('student');
        }
        if (faculty_cb) {
            selectedRoles.push('faculty');
        }
        if (staff_cb) {
            selectedRoles.push('staff');
        }

        const rolesString = selectedRoles.join(', ');



        try {
            const response = await axios.put(
                `/<?php echo $directoryName; ?>/api/services.php`, {
                    service_id,
                    service_name,
                    available_to: rolesString
                }
            );

            if (response.data.status === "success") {
                notyf.success(response.data.message);
                closeEditServiceModal();
                loadServices(1, 10, "");

            } else if (response.data.status === "failed") {
                notyf.error(response.data.message);
            } else {
                notyf.error("Something went wrong.")
            }

        } catch (error) {
            notyf.error(error)
        }
    }

    const deleteService = async (id) => {
        const notyf = new Notyf();
        try {
            const response = await axios.delete(
                `/<?php echo $directoryName; ?>/api/services.php`, {
                    data: {
                        id
                    }
                } // Pass data in the request body
            );
            console.log("Service deleted:", response.data);
            loadServices(1, 10, "");
            notyf.success("Deleted successfully!")
        } catch (error) {
            console.error("Failed to delete service:", error);
        }
    };
    const loadServices = async (page = 1, limit = 10, query = "") => {

        axios.interceptors.request.use(
            config => {

                return config;
            },
            error => {
                return Promise.reject(error);
            }
        );

        axios.interceptors.response.use(
            response => {

                return response;
            },
            error => {

                return Promise.reject(error);
            }
        );

        try {
            const response = await axios.get(
                `/${"<?php echo $directoryName; ?>"}/api/services.php?page=${page}&limit=${limit}&query=${encodeURIComponent(query)}`
            );

            const {
                services,
                total
            } = response.data;

            // Update table body with fetched doctor data
            const tableBody = document.getElementById('tableBody');
            tableBody.innerHTML = "";
            if (services.length > 0) {
                services.forEach((item) => {
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-gray-50';
                    row.innerHTML = `
    <td class="px-4 py-3">${item.service_name}</td>
    <td class="px-4 py-3">${formatAvailableTo(item.available_to)}</td>
    <td class="px-4 py-3 space-x-3">
         <button onclick='openEditServiceModal(${JSON.stringify(item)})'><i class="fa fa-pencil text-blue" style="font-size: 1.5rem;" aria-hidden="true"></i></button>
        <button onclick='deleteService(${item.id})'><i class="fa fa-trash-o text-red" style="font-size: 1.5rem;" aria-hidden="true"></i></button>
    </td>

`;
                    tableBody.appendChild(row);
                });
            } else {
                tableBody.innerHTML = `
<tr>
    <td colspan="4" class="px-4 py-3 text-center text-gray-500">No data found.</td>
</tr>
`;
            }

            // Update pagination display
            const totalPages = Math.ceil(total / limit);
            document.getElementById('showing').textContent = services.length;
            document.getElementById('total').textContent = total;

            // Update previous/next button states
            const prevButton = document.querySelector('.prev-btn');
            const nextButton = document.querySelector('.next-btn');
            prevButton.disabled = page === 1;
            nextButton.disabled = page === totalPages;

            // Add event listeners for pagination
            prevButton.onclick = () => loadServices(page - 1, limit);
            nextButton.onclick = () => loadServices(page + 1, limit);
        } catch (error) {
            console.error('Error loading doctors:', error);
            tableBody.innerHTML = `<td colspan="4" class="px-4 py-3">Error fetching doctors</td>`;
        }
    };

    function handleInput(query) {


        loadServices(1, 10, query);

    }

    function formatAvailableTo(value) {
        // Split the string into an array, capitalize each part, and join it with commas
        let formattedValues = value.split(',').map(role =>
            role.trim().charAt(0).toUpperCase() + role.trim().slice(1)
        );

        // If there are two roles, join them with "and"; otherwise, use a comma
        if (formattedValues.length === 2) {
            return formattedValues.join(" and ");
        } else {
            return formattedValues.join(", ");
        }
    }
</script>