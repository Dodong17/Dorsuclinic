<script>
    function validateForm(input, errorId, fieldName) {

        if (input.value === "") {
            // Show the error message
            const errorElement = document.getElementById(errorId);
            errorElement.classList.remove("hidden");
            errorElement.innerHTML = `${fieldName} is required.`;
            return false;
        } else {
            // Hide the error message
            const errorElement = document.getElementById(errorId);
            errorElement.classList.add("hidden");
            errorElement.innerHTML = "";
            return true; // Return true if validation passes
        }
    }


    function checkNumberOnName(input) {
        // Replace all numeric characters with an empty string
        input.value = input.value.replace(/\d/g, '');
    }
</script>