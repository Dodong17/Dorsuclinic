<script>
    function closeAllowedIdModal() {
        document.getElementById('AllowedIdModal').style.display = 'none';
    }

    function openAllowedIdModal() {
        document.getElementById('AllowedIdModal').style.display = 'flex';
        getAllId();

    }

    const getAllId = async () => {
        const notyf = new Notyf();
        const tableBody = document.getElementById('allowed-id-table-body'); // Reference to the table body

        try {
            const response = await axios.get(`/syny/api/AllowedId.php`);
            const allowedIds = response.data; // Assuming the response is an array of allowed IDs


            // Clear the table body before populating
            tableBody.innerHTML = '';

            allowedIds.forEach((id) => {
                // Create a new row
                const row = document.createElement('tr');

                // Create ID cell
                const idCell = document.createElement('td');
                idCell.classList.add('p-2');
                idCell.textContent = id.valid_id; // Assuming each object has an 'allowed_id' field

                // Create Action cell
                const actionCell = document.createElement('td');
                actionCell.classList.add('p-2');

                // Create the Delete button
                const deleteButton = document.createElement('button');
                deleteButton.classList.add('bg-red', 'text-white', 'rounded', 'px-3', 'py-1', 'hover:bg-red');
                deleteButton.textContent = 'Delete';
                // Add event listener for delete action
                deleteButton.onclick = () => deleteId(id.id);

                // Append the Delete button to the Action cell
                actionCell.appendChild(deleteButton);

                // Append both cells to the row
                row.appendChild(idCell);
                row.appendChild(actionCell);

                // Append the row to the table body
                tableBody.appendChild(row);
            });
        } catch (error) {
            console.error('Error fetching allowed IDs:', error);
            notyf.error('An error occurred while fetching the allowed IDs.');
        }
    };

    const deleteId = async (id) => {
        const notyf = new Notyf();
        try {
            const response = await axios.delete(`/syny/api/AllowedId.php?id=${id}`);
            if (response.data.status === 'success') {
                notyf.success('Allowed ID deleted successfully!');
                getAllId();
            } else {
                notyf.error('Failed to delete allowed ID.');
            }
        } catch (error) {
            console.error('Error deleting allowed ID:', error);
            notyf.error('An error occurred while deleting the allowed ID.');
        }
    }

    const submitAddAllowedId = async (event) => {
        const notyf = new Notyf();
        event.preventDefault();
        const input_id = document.getElementById('allowed_id');
        if (input_id.value === '') {
            notyf.error('Please enter ID.');
            return;
        }


        try {
            const response = await axios.post(`/syny/api/AllowedId.php`, {
                allowed_id: input_id.value,
            });

            if (response.data.status === 'success') {
                notyf.success('Allowed ID added successfully!');
                input_id.value = '';
                getAllId();
                // closeAllowedIdModal();
            } else {
                alert('Failed to add allowed ID. Please try again.');
            }
        } catch (error) {
            console.error('Error adding allowed ID:', error);
            notyf.error('An error occurred while adding the allowed ID.');
        }
    };
</script>