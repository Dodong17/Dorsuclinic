<script>
    function openEventDetails(encodedData) {
        document.getElementById("event_details").style.display = "flex";
        const eventData = JSON.parse(decodeURIComponent(encodedData));
        const dateObj = new Date(eventData.date);

        // Get components of the date
        const options = {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            weekday: 'long'
        };
        const formattedDate = dateObj.toLocaleDateString(undefined, options);

        // Format the date as "Day Month Year (Day of Week)"
        const day = dateObj.getDate(); // Get the day of the month
        const month = dateObj.toLocaleString('default', {
            month: 'long'
        }); // Get the full month name
        const year = dateObj.getFullYear(); // Get the full year
        const weekday = dateObj.toLocaleString('default', {
            weekday: 'long'
        }); // Get the full weekday name

        const output = `${day} ${month} ${year} (${weekday})`;
      
        document.getElementById("selectedDateEvent").innerText = output;
        document.getElementById("sched_id").value = eventData.id;
        document.getElementById("morning_slot_event").value = eventData.morning_slot;
        document.getElementById("afternoon_slot_event").value = eventData.afternoon_slot;
        document.getElementById("delete_button").setAttribute("data-eventid", eventData.id);


    }

    function closeEventDetails(){
        document.getElementById("event_details").style.display = "none";
    }



    function openAddEvent(event) {
        document.getElementById("add_event").style.display = "flex";

        const dateString = event.target.getAttribute("data-date");

        // Convert dateString to a Date object
        const dateObj = new Date(dateString);

        // Get components of the date
        const options = {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            weekday: 'long'
        };
        const formattedDate = dateObj.toLocaleDateString(undefined, options);

        // Format the date as "Day Month Year (Day of Week)"
        const day = dateObj.getDate(); // Get the day of the month
        const month = dateObj.toLocaleString('default', {
            month: 'long'
        }); // Get the full month name
        const year = dateObj.getFullYear(); // Get the full year
        const weekday = dateObj.toLocaleString('default', {
            weekday: 'long'
        }); // Get the full weekday name

        const output = `${day} ${month} ${year} (${weekday})`;
        document.getElementById("selectedDate").innerText = output;
        document.getElementById("date").value = dateString;


    }

    function closeAddEventModal() {
        document.getElementById("add_event").style.display = "none";
    }
</script>