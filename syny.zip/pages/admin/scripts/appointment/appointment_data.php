<script>
    // Set up calendar variables
    const daysOfWeekFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const daysOfWeekShort = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();


    const saveEvent = async (event) => {
        event.preventDefault();
        const notyf = new Notyf();
        const saveButton = document.getElementById("save_button");
        saveButton.innerHTML = "Saving...";
        saveButton.disabled = true;
        try {
            const form = event.target;
            const formData = new FormData(form);

            const dataObject = Object.fromEntries(formData.entries());
            const response = await axios.post(`/<?php echo $directoryName; ?>/api/appointmentschedule.php`, dataObject, {
                headers: {
                    "Content-Type": "application/json",
                }
            });
            if (response.data.status === "success") {
                notyf.success(response.data.message);
                form.reset();
                document.getElementById("add_event").style.display = "none";
                loadCalendarWithAppointments();

            } else if (response.data.status === "failed") {
                notyf.error(response.data.message);

            } else {
                notyf.error("Something went wrong.")
            }

            saveButton.innerHTML = "Save";
            saveButton.disabled = false;

            console.log( 5 + 5);


        } catch (error) {
            console.error('Error saving event:', error); // Log the error for debugging
            notyf.error("An error occurred while saving the event.");
        }
    }

    const deleteEvent = async () => {
        const notyf = new Notyf();
        try {
            const deleteButton = document.getElementById("delete_button");
            const id = deleteButton.getAttribute("data-eventid");
            deleteButton.innerHTML = "Deleting...";

            const response = await axios.delete(`/<?php echo $directoryName; ?>/api/appointmentschedule.php?id=${id}`);
            if (response.data.status === "success") {
                notyf.success(response.data.message);
                loadCalendarWithAppointments();
                closeEventDetails();

            } else if (response.data.status === "failed") {
                notyf.error(response.data.message);
            } else {
                notyf.error("Something went wrong.")
            }
            deleteButton.innerHTML = "Delete";
        } catch (error) {
            console.error('Error saving event:', error); // Log the error for debugging
            notyf.error("An error occurred while saving the event.");
        }

    }


    const updateEvent = async (event) => {
        event.preventDefault();
        const notyf = new Notyf();
        const updateButton = document.getElementById("update_button");
        updateButton.innerHTML = "Updating...";
        updateButton.disabled = true;
        try {
            const form = event.target;
            const formData = new FormData(form);

            const dataObject = Object.fromEntries(formData.entries());
            const response = await axios.put(`/<?php echo $directoryName; ?>/api/appointmentschedule.php`, dataObject, {
                headers: {
                    "Content-Type": "application/json",
                }
            });
            if (response.data.status === "success") {
                notyf.success(response.data.message);
                document.getElementById("add_event").style.display = "none";
                loadCalendarWithAppointments();
                closeEventDetails();

            } else if (response.data.status === "failed") {
                notyf.error(response.data.message);

            } else {
                notyf.error("Something went wrong.")
            }

            updateButton.innerHTML = "Update";
            updateButton.disabled = false;
        } catch (error) {
            console.error('Error saving event:', error); // Log the error for debugging
            notyf.error("An error occurred while saving the event.");
        }
    }


    // Fetch scheduled dates from the API and update the calendar
    const loadCalendarWithAppointments = async () => {
        document.getElementById('calendarTitle').innerText = `${new Date().toLocaleString('default', { month: 'long' })} ${currentYear}`;
        try {
            const response = await axios.get(`/<?php echo $directoryName; ?>/api/appointmentschedule.php`);

            if (response.status !== 200) {
                throw new Error('Network response was not ok: ' + response.statusText);
            }

            const data = response.data;

            const results = data.results || [];

            createCalendar(results);
        } catch (error) {
            console.error('Error fetching scheduled dates:', error);
        }
    };

    function createCalendar(results) {
        const firstDay = new Date(currentYear, currentMonth - 1, 1).getDay();
        const daysInMonth = new Date(currentYear, currentMonth, 0).getDate();
        let calendarHTML = '<thead><tr>';

        // Create days of the week header
        daysOfWeekFull.forEach((day, i) => {
            calendarHTML += `<th class="px-2 py-2 text-center text-gray-600">
                            <span class="hidden sm:inline">${day}</span>
                            <span class="sm:hidden">${daysOfWeekShort[i]}</span>
                         </th>`;
        });
        calendarHTML += '</tr></thead><tbody><tr>';

        // Fill in blank days at the beginning of the month
        for (let i = 0; i < firstDay; i++) {
            calendarHTML += '<td></td>';
        }

        // Populate days with event details and checks for scheduled dates
        for (let day = 1; day <= daysInMonth; day++) {
            const formattedDate = `${currentYear}-${String(currentMonth).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

            // Find the corresponding event data by date
            const event = results.find(event => event.date === formattedDate);
            const isScheduled = !!event;
            const cellClass = isScheduled ? 'bg-green' : 'bg-white';
            let onClick;

            if (isScheduled) {
                // Prepare event data for openEventDetails
                const eventData = {
                    id: event.id,
                    date: event.date,
                    morning_slot: event.morning_slot,
                    afternoon_slot: event.afternoon_slot
                };
                // Encode event data and set onclick handler
                const encodedData = encodeURIComponent(JSON.stringify(eventData));
                onClick = `onclick="openEventDetails('${encodedData}')"`;
            } else {
                onClick = `onclick="openAddEvent(event)"`;
            }

            calendarHTML += `<td ${onClick} class="px-2 py-4 text-center border border-gray-300 cursor-pointer ${cellClass}" data-date="${formattedDate}">${day}</td>`;

            // Start a new row after each week
            if ((firstDay + day) % 7 === 0) calendarHTML += '</tr><tr>';
        }

        calendarHTML += '</tr></tbody>'; // Close the table body
        document.getElementById('calendarTable').innerHTML = calendarHTML;
    }

    // Load the calendar with appointments when the page loads
</script>