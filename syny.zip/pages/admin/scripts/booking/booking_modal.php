<script>
    

    function openBookingModal(details){
        console.log(details.id)
        document.getElementById("decline_button").setAttribute("data-bookingid", details.id);
        document.getElementById("approve_button").setAttribute("data-bookingid", details.id);

        fetchDoctors();
        document.getElementById("booking_modal").style.display = 'flex';
    }
    function closeBookingModal(){
        document.getElementById("booking_modal").style.display = 'none';
    }
</script>