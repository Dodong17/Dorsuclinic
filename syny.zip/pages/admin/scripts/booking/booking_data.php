<script>
    const fetchPending = async (page = 1, limit = 10, query = "") => {
        const notyf = new Notyf();
        axios.interceptors.request.use(
            config => {

                return config;
            },
            error => {
                return Promise.reject(error);
            }
        );

        axios.interceptors.response.use(
            response => {

                return response;
            },
            error => {

                return Promise.reject(error);
            }
        );

        try {
            const response = await axios.get(`/${"<?php echo $directoryName; ?>"}/api/booking.php?page=${page}&limit=${limit}&query=${encodeURIComponent(query)}&status=pending`);

            const {
                bookings,
                total
            } = response.data;
            // const uniqueDates = new Set();

            // Update table body with fetched doctor data
            const tableBody = document.getElementById('tableBody');
            tableBody.innerHTML = "";
            if (bookings.length > 0) {

                bookings.forEach((item) => {
                    // uniqueDates.add(item.booking_date);
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-gray-50';
                    row.innerHTML = `
                    <td class="px-4 py-3">${item.user_name}</td>
                    <td class="px-4 py-3">${item.booking_date}</td>
                    <td class="px-4 py-3">${item.session}</td>
                    <td class="px-4 py-3">${item.status}</td>
                      <td class="px-4 py-3">${item.doctor_name}</td>
                    <td class="px-4 py-3 space-x-3">
                        <button onclick='openBookingModal(${JSON.stringify(item)})'><i class="fa fa-eye text-blue" style="font-size: 1.5rem;" aria-hidden="true"></i></button>
                    </td>

                `;
                    tableBody.appendChild(row);
                });
            } else {
                tableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="px-4 py-3 text-center text-gray-500">No data found.</td>
                </tr>
            `;
            }
            // const dateSelector = document.getElementById('find_date');
            // dateSelector.innerHTML = ""; // Clear previous options

            // const defaultOption = document.createElement("option");
            // defaultOption.value = "";
            // defaultOption.text = "🔍 Find by date";
            // dateSelector.appendChild(defaultOption);

            // // Add unique booking dates as options
            // uniqueDates.forEach((date) => {
            //     const option = document.createElement("option");
            //     option.value = date; // Set value to the date
            //     option.text = date; // Set text to the date
            //     dateSelector.appendChild(option);
            // });

            // Update pagination display
            const totalPages = Math.ceil(total / limit);
            document.getElementById('showing').textContent = bookings.length;
            document.getElementById('total').textContent = total;

            // Update previous/next button states
            const prevButton = document.querySelector('.prev-btn');
            const nextButton = document.querySelector('.next-btn');
            prevButton.disabled = page === 1;
            nextButton.disabled = page === totalPages;

            // Add event listeners for pagination
            prevButton.onclick = () => fetchBookings(page - 1, limit);
            nextButton.onclick = () => fetchBookings(page + 1, limit);
        } catch (error) {
            console.error('Error loading doctors:', error);
            tableBody.innerHTML = `<td colspan="5" class="px-4 py-3">Error fetching bookings</td>`;

        }
    }

    const fetchApproved = async (page = 1, limit = 10, query = "") => {
        const notyf = new Notyf();
        axios.interceptors.request.use(
            config => {

                return config;
            },
            error => {
                return Promise.reject(error);
            }
        );

        axios.interceptors.response.use(
            response => {

                return response;
            },
            error => {

                return Promise.reject(error);
            }
        );

        try {
            const response = await axios.get(`/${"<?php echo $directoryName; ?>"}/api/booking.php?page=${page}&limit=${limit}&query=${encodeURIComponent(query)}&status=approved`);

            const {
                bookings,
                total
            } = response.data;
            // const uniqueDates = new Set();

            // Update table body with fetched doctor data
            const tableBody = document.getElementById('tableBody');
            tableBody.innerHTML = "";
            if (bookings.length > 0) {

                bookings.forEach((item) => {
                    // uniqueDates.add(item.booking_date);
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-gray-50';
                    row.innerHTML = `
                    <td class="px-4 py-3">${item.user_name}</td>
                    <td class="px-4 py-3">${item.booking_date}</td>
                    <td class="px-4 py-3">${item.session}</td>
                    <td class="px-4 py-3">${item.status}</td>
                      <td class="px-4 py-3">${item.doctor_name}</td>
                    <td class="px-4 py-3 space-x-3">
                    
                    </td>

                `;
                    tableBody.appendChild(row);
                });
            } else {
                tableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="px-4 py-3 text-center text-gray-500">No data found.</td>
                </tr>
            `;
            }
            // const dateSelector = document.getElementById('find_date');
            // dateSelector.innerHTML = ""; // Clear previous options

            // const defaultOption = document.createElement("option");
            // defaultOption.value = "";
            // defaultOption.text = "🔍 Find by date";
            // dateSelector.appendChild(defaultOption);

            // // Add unique booking dates as options
            // uniqueDates.forEach((date) => {
            //     const option = document.createElement("option");
            //     option.value = date; // Set value to the date
            //     option.text = date; // Set text to the date
            //     dateSelector.appendChild(option);
            // });

            // Update pagination display
            const totalPages = Math.ceil(total / limit);
            document.getElementById('showing').textContent = bookings.length;
            document.getElementById('total').textContent = total;

            // Update previous/next button states
            const prevButton = document.querySelector('.prev-btn');
            const nextButton = document.querySelector('.next-btn');
            prevButton.disabled = page === 1;
            nextButton.disabled = page === totalPages;

            // Add event listeners for pagination
            prevButton.onclick = () => fetchBookings(page - 1, limit);
            nextButton.onclick = () => fetchBookings(page + 1, limit);
        } catch (error) {
            console.error('Error loading doctors:', error);
            tableBody.innerHTML = `<td colspan="5" class="px-4 py-3">Error fetching bookings</td>`;

        }
    }

    const fetchDeclined = async (page = 1, limit = 10, query = "") => {
        const notyf = new Notyf();
        axios.interceptors.request.use(
            config => {

                return config;
            },
            error => {
                return Promise.reject(error);
            }
        );

        axios.interceptors.response.use(
            response => {

                return response;
            },
            error => {

                return Promise.reject(error);
            }
        );

        try {
            const response = await axios.get(`/${"<?php echo $directoryName; ?>"}/api/booking.php?page=${page}&limit=${limit}&query=${encodeURIComponent(query)}&status=declined`);

            const {
                bookings,
                total
            } = response.data;
            // const uniqueDates = new Set();

            // Update table body with fetched doctor data
            const tableBody = document.getElementById('tableBody');
            tableBody.innerHTML = "";
            if (bookings.length > 0) {

                bookings.forEach((item) => {
                    // uniqueDates.add(item.booking_date);
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-gray-50';
                    row.innerHTML = `
                    <td class="px-4 py-3">${item.user_name}</td>
                    <td class="px-4 py-3">${item.booking_date}</td>
                    <td class="px-4 py-3">${item.session}</td>
                    <td class="px-4 py-3">${item.status}</td>
                      <td class="px-4 py-3">${item.doctor_name}</td>
                    <td class="px-4 py-3 space-x-3">
                      
                    </td>

                `;
                    tableBody.appendChild(row);
                });
            } else {
                tableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="px-4 py-3 text-center text-gray-500">No data found.</td>
                </tr>
            `;
            }
            // const dateSelector = document.getElementById('find_date');
            // dateSelector.innerHTML = ""; // Clear previous options

            // const defaultOption = document.createElement("option");
            // defaultOption.value = "";
            // defaultOption.text = "🔍 Find by date";
            // dateSelector.appendChild(defaultOption);

            // // Add unique booking dates as options
            // uniqueDates.forEach((date) => {
            //     const option = document.createElement("option");
            //     option.value = date; // Set value to the date
            //     option.text = date; // Set text to the date
            //     dateSelector.appendChild(option);
            // });

            // Update pagination display
            const totalPages = Math.ceil(total / limit);
            document.getElementById('showing').textContent = bookings.length;
            document.getElementById('total').textContent = total;

            // Update previous/next button states
            const prevButton = document.querySelector('.prev-btn');
            const nextButton = document.querySelector('.next-btn');
            prevButton.disabled = page === 1;
            nextButton.disabled = page === totalPages;

            // Add event listeners for pagination
            prevButton.onclick = () => fetchBookings(page - 1, limit);
            nextButton.onclick = () => fetchBookings(page + 1, limit);
        } catch (error) {
            console.error('Error loading doctors:', error);
            tableBody.innerHTML = `<td colspan="5" class="px-4 py-3">Error fetching bookings</td>`;

        }
    }

    const fetchDoctors = async () => {
        const doctorSelector = document.getElementById("doctor_id");
        try {
            const notyf = new Notyf();
            const response = await axios.get(`/${"<?php echo $directoryName; ?>"}/api/doctors.php`);
            const doctors = response.data.doctors;

            // Clear any previous options
            doctorSelector.innerHTML = '';

            const placeholderOption = document.createElement('option');
            placeholderOption.value = '';
            placeholderOption.text = 'Select a Doctor';
            doctorSelector.appendChild(placeholderOption);

            doctors.forEach(doctor => {
                const option = document.createElement('option');
                option.value = doctor.id; // Set the doctor's ID as the value
                option.text = `${doctor.first_name} ${doctor.last_name}`; // Set the full name as the text
                doctorSelector.appendChild(option);
            });
        } catch (error) {
            notyf.error(error)
        }
    }


    const declineBooking = async () => {
        const notyf = new Notyf();
        const decline_button = document.getElementById("decline_button");
        const booking_id = decline_button.getAttribute("data-bookingid");
        document.getElementById("doctor-error").style.display = "none";
        decline_button.innerHTML = "Declining...";
        try {
            const response = await axios.patch(`/${"<?php echo $directoryName; ?>"}/api/booking.php`, {
                action: "declined",
                booking_id: booking_id,
                doctor_id: null
            });
            console.log(response);
            notyf.success(response.data.message);
            fetchPending(1, 10, "");
            closeBookingModal();
        } catch (error) {
            notyf.error(error);
        } finally {
            decline_button.innerHTML = "Decline";
            document.getElementById("doctor-error").style.display = "none";
        }
    }

    const approveBooking = async () => {
        const notyf = new Notyf();
        const approve_button = document.getElementById("approve_button");
        const booking_id = approve_button.getAttribute("data-bookingid");
        const doctor_id = document.getElementById("doctor_id").value;
        document.getElementById("doctor-error").style.display = "none";
        if (doctor_id === "") {
            document.getElementById("doctor-error").style.display = "block";
            return;
        }
        approve_button.innerHTML = "Approving...";
        try {
            const response = await axios.patch(`/${"<?php echo $directoryName; ?>"}/api/booking.php`, {
                action: "approved",
                booking_id: booking_id,
                doctor_id: doctor_id
            });
            console.log(response);
            notyf.success(response.data.message);
            fetchPending(1, 10, "");
            closeBookingModal();
        } catch (error) {
            notyf.error(error);
        } finally {
            approve_button.innerHTML = "Approve";
            document.getElementById("doctor-error").style.display = "none";
        }
    }

    window.addEventListener("load", () => fetchPending(1, 10, ""))
</script>