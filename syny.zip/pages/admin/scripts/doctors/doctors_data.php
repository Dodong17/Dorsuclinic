<script>
    const handleSubmitEdit = async (event) => {
        var notyf = new Notyf();
        event.preventDefault();
        document.getElementById("edit_submit_button").innerHTML = "Saving...";
        const form = event.target;
        const formData = new FormData(form);
        document.getElementById("edit_form_fieldset").disabled = true;
        const dataObject = Object.fromEntries(formData.entries());
        try {
            const response = await axios.patch(`/<?php echo $directoryName; ?>/api/users.php`, dataObject, {
                header: {
                    "Content-Type": "application/json"
                }
            });
            if(response.data.status === "success"){
                notyf.success(response.data.message);
                loadDoctorsData(1, 10, "");
                document.getElementById("edit_modal").style.display = "none";
            }else if(response.data.status === "failed"){
                const element = document.getElementById(`edit_${response.data.error}_error`);
                element.classList.remove("hidden");
                element.innerHTML = response.data.message;
                notyf.error(response.data.message);
                document.getElementById("edit_submit_button").innerHTML = "Save";
            }
        } catch (error) {
            notyf.error("Error: " + error);
        }finally {
            document.getElementById("edit_form_fieldset").disabled = false;
            document.getElementById("edit_submit_button").innerHTML = "Save";
        }
    }


    const handleSubmit = async (event) => {


        var notyf = new Notyf();
        event.preventDefault();
        document.getElementById("submit_button").innerHTML = "Adding...";
        const form = event.target;
        const formData = new FormData(form);
        formData.append("role", "doctor");
        formData.append("user_type", "doctor");
        formData.append("password", document.getElementById("last_name").value.toUpperCase());
        formData.append("confirm_password", document.getElementById("last_name").value.toUpperCase());
        document.getElementById("form_fieldset").disabled = true;



        const dataObject = Object.fromEntries(formData.entries());



        try {
            const response = await axios.post(`/<?php echo $directoryName; ?>/api/users.php`, dataObject, {
                header: {
                    "Content-Type": "application/json"
                }
            });
            if (response.data.status === "failed") {

                const element = document.getElementById(`${response.data.error}_error`);
                element.classList.remove("hidden");
                element.innerHTML = response.data.message;
                notyf.error(response.data.message);
                document.getElementById("submit_button").innerHTML = "Add";

            } else if (response.data.status === "success") {
                form.reset();
                const errorElements = form.querySelectorAll('.error-message');
                errorElements.forEach((element) => {
                    element.classList.add("hidden");
                    element.innerHTML = "";
                });
                notyf.success('Created successfully.');
                document.getElementById("submit_button").innerHTML = "Add";
                loadDoctorsData();

            }


        } catch (error) {
            console.log(error);
            notyf.error(error);
        } finally {
            document.getElementById("form_fieldset").disabled = false;
            document.getElementById("submit_button").innerHTML = "Add";
        }
    }

    function handleInput(query) {


        loadDoctorsData(1, 10, query);

    }




    const loadDoctorsData = async (page = 1, limit = 10, query = "") => {

        axios.interceptors.request.use(
            config => {

                return config;
            },
            error => {
                return Promise.reject(error);
            }
        );

        axios.interceptors.response.use(
            response => {

                return response;
            },
            error => {

                return Promise.reject(error);
            }
        );

        try {
            const response = await axios.get(`/${"<?php echo $directoryName; ?>"}/api/doctors.php?page=${page}&limit=${limit}&query=${encodeURIComponent(query)}`);

            const {
                doctors,
                total
            } = response.data;

            // Update table body with fetched doctor data
            const tableBody = document.getElementById('tableBody');
            tableBody.innerHTML = "";
            if (doctors.length > 0) {
                doctors.forEach((item) => {
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-gray-50';
                    row.innerHTML = `
                    <td class="px-4 py-3">${item.id_number}</td>
                    <td class="px-4 py-3">${item.first_name} ${item.last_name}</td>
                    <td class="px-4 py-3">${item.contact}</td>
                    <td class="px-4 py-3">${item.email}</td>
                    <td class="px-4 py-3 space-x-3">
                        <button onclick='openEditModal(${JSON.stringify(item)})'><i class="fa fa-pencil text-blue" style="font-size: 1.5rem;" aria-hidden="true"></i></button>
                        <button onclick='openDeleteModal(${item.id})'><i class="fa fa-trash-o text-red" style="font-size: 1.5rem;" aria-hidden="true"></i></button>
                    </td>

                `;
                    tableBody.appendChild(row);
                });
            } else {
                tableBody.innerHTML = `
                <tr>
                    <td colspan="5" class="px-4 py-3 text-center text-gray-500">No data found.</td>
                </tr>
            `;
            }

            // Update pagination display
            const totalPages = Math.ceil(total / limit);
            document.getElementById('showing').textContent = doctors.length;
            document.getElementById('total').textContent = total;

            // Update previous/next button states
            const prevButton = document.querySelector('.prev-btn');
            const nextButton = document.querySelector('.next-btn');
            prevButton.disabled = page === 1;
            nextButton.disabled = page === totalPages;

            // Add event listeners for pagination
            prevButton.onclick = () => loadDoctorsData(page - 1, limit);
            nextButton.onclick = () => loadDoctorsData(page + 1, limit);
        } catch (error) {
            console.error('Error loading doctors:', error);
            tableBody.innerHTML = `<td colspan="5" class="px-4 py-3">Error fetching doctors</td>`;
        }
    };

    const deleteDoctor = async () => {
        var notyf = new Notyf();
        const id = document.getElementById("delete_button").getAttribute("data-id");
        try {
            const response = await axios.delete(`/${"<?php echo $directoryName; ?>"}/api/users.php?id=${id}`);
            if (response.data.status == "success") {
                loadDoctorsData(1, 10, "");
                notyf.success(response.data.message);
                document.getElementById("delete_modal").style.display = "none";
            } else {
                notyf.error(response.data.message);
            }
        } catch (error) {
            notyf.error(error);
        }

    }



    // Corrected the function name in the event listener
    window.addEventListener('load', () => loadDoctorsData(1, 10, ""));
</script>