<script>
    function closeAddModal() {
    document.getElementById("add_modal").style.display = "none";
}

function openAddModal() {
    document.getElementById("add_modal").style.display = "flex";
}

function closeDeleteModal(){
    document.getElementById("delete_modal").style.display = "none";
}
function openDeleteModal(id){
    document.getElementById("delete_modal").style.display = "flex";
    const deleteButton = document.getElementById("delete_button");
    deleteButton.setAttribute("data-id", id);
}

function openEditModal(doctor){
    document.getElementById("edit_modal").style.display = "flex";
    document.getElementById("edit_id").value = doctor.id;
    document.getElementById("edit_id_number").value = doctor.id_number;
    document.getElementById("edit_first_name").value = doctor.first_name;
    document.getElementById("edit_last_name").value = doctor.last_name;
    document.getElementById("edit_contact").value = doctor.contact;
    document.getElementById("edit_email").value = doctor.email;
    document.getElementById("edit_birth_date").value = doctor.birth_date;
    document.getElementById("edit_gender").value = doctor.gender;

    

}

function closeEditModal() {
    document.getElementById("edit_modal").style.display = "none";

}
</script>