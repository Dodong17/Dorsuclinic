<?php
require "template/Validator.php";
include 'template/Sidebar.php';
include 'config/database.php';









function Content()
{
    ob_start();
?>

    <div class=" w-full h-screen max-h-[calc(100vh-100px)] overflow-y-scroll p-5 text-black">
      


    </div>


<?php
    return ob_get_clean();
}
?>



<?php
// Call the Sidebar function and pass the content
Sidebar(Content(), "");
?>

<script>
   



 
    

   
  
</script>


