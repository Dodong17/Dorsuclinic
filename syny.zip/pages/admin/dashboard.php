<?php
require "template/Validator.php";
include 'template/Sidebar.php';
include 'config/database.php';
include "scripts/dashboard/dashboard_data.php";
include "components/AllowedIdModal.php";

include "scripts/allowedid/handle_modal.php";

function Content()
{
    ob_start();
?>

    <div class="w-full h-screen max-h-[calc(100vh-100px)] flex flex-col">

            <div class="dashboard-title-wrapper mb-10" style="padding-top: 40px;">
            <div class="text-center">
                <h1 class="text-4xl font-bold text-gray-600">Dashboard</h1>
                <p class="text-gray-600 text-lg mt-3">Monitor key metrics, manage patient bookings, and track procedures. Stay informed with real-time data.</p>
            </div>
        </div>


        <div class="w-full px-10">
            <div class="mb-5 flex justify-end">
                <button style="background-color: #004B8D; color: white; border-radius: 20px; padding: 12px 25px; font-size: 1.1rem; cursor: pointer; transition: background-color 0.3s ease, box-shadow 0.3s ease;" 
                        onmouseover="this.style.backgroundColor='#006F9F'; this.style.boxShadow='0 4px 12px rgba(0, 0, 0, 0.2)';" 
                        onmouseout="this.style.backgroundColor='#004B8D'; this.style.boxShadow='none';" 
                        onclick="openAllowedIdModal()">Add Allowed ID</button>
            </div>

            <!-- Cards Section (Scrollable with gap) -->
            <div class="overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-8 mt-5 max-h-[calc(100vh-250px)]">
                <!-- Card for Patients -->
                <div style="background-color: white; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); border-radius: 10px; padding: 25px; border: 2px solid #004B8D; transition: transform 0.3s ease, box-shadow 0.3s ease;" 
                     onmouseover="this.style.transform='scale(1.05)'; this.style.boxShadow='0 8px 16px rgba(0, 0, 0, 0.2)';" 
                     onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 4px 12px rgba(0, 0, 0, 0.1)';">
                    <p id="patients-count" style="font-size: 2.5rem; font-weight: bold; color: #004B8D;">Loading...</p>
                    <p style="color: gray;">Patients</p>
                    <a href="patients" style="display: inline-block; margin-top: 15px; padding: 12px 25px; background-color: #004B8D; color: white; text-align: center; border-radius: 20px; text-decoration: none; transition: background-color 0.3s ease;" 
                       onmouseover="this.style.backgroundColor='#006F9F';" 
                       onmouseout="this.style.backgroundColor='#004B8D';">View</a>
                    <span style="display: inline-block; margin-top: 10px; background-color: #E0E0E0; color: #333; padding: 5px 10px; border-radius: 15px; font-size: 0.9rem;">Patients Overview</span>
                </div>

                <!-- Card for Pending Bookings -->
                <div style="background-color: white; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); border-radius: 10px; padding: 25px; border: 2px solid #004B8D; transition: transform 0.3s ease, box-shadow 0.3s ease;" 
                     onmouseover="this.style.transform='scale(1.05)'; this.style.boxShadow='0 8px 16px rgba(0, 0, 0, 0.2)';" 
                     onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 4px 12px rgba(0, 0, 0, 0.1)';">
                    <p id="pending-bookings-count" style="font-size: 2.5rem; font-weight: bold; color: #004B8D;">Loading...</p>
                    <p style="color: gray;">Pending Bookings</p>
                    <a href="appointments" style="display: inline-block; margin-top: 15px; padding: 12px 25px; background-color: #004B8D; color: white; text-align: center; border-radius: 20px; text-decoration: none; transition: background-color 0.3s ease;" 
                       onmouseover="this.style.backgroundColor='#006F9F';" 
                       onmouseout="this.style.backgroundColor='#004B8D';">View</a>
                    <span style="display: inline-block; margin-top: 10px; background-color: #E0E0E0; color: #333; padding: 5px 10px; border-radius: 15px; font-size: 0.9rem;">Pending Appointments</span>
                </div>

                <!-- Card for Scalings -->
                <div style="background-color: white; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); border-radius: 10px; padding: 25px; border: 2px solid #004B8D; transition: transform 0.3s ease, box-shadow 0.3s ease;" 
                     onmouseover="this.style.transform='scale(1.05)'; this.style.boxShadow='0 8px 16px rgba(0, 0, 0, 0.2)';" 
                     onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 4px 12px rgba(0, 0, 0, 0.1)';">
                    <p id="scalings-count" style="font-size: 2.5rem; font-weight: bold; color: #004B8D;">Loading...</p>
                    <p style="color: gray;">Scaling</p>
                    <a href="appointments" style="display: inline-block; margin-top: 15px; padding: 12px 25px; background-color: #004B8D; color: white; text-align: center; border-radius: 20px; text-decoration: none; transition: background-color 0.3s ease;" 
                       onmouseover="this.style.backgroundColor='#006F9F';" 
                       onmouseout="this.style.backgroundColor='#004B8D';">View</a>
                    <span style="display: inline-block; margin-top: 10px; background-color: #E0E0E0; color: #333; padding: 5px 10px; border-radius: 15px; font-size: 0.9rem;">Dental Procedures</span>
                </div>

                <!-- Card for Extractions -->
                <div style="background-color: white; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); border-radius: 10px; padding: 25px; border: 2px solid #004B8D; transition: transform 0.3s ease, box-shadow 0.3s ease;" 
                     onmouseover="this.style.transform='scale(1.05)'; this.style.boxShadow='0 8px 16px rgba(0, 0, 0, 0.2)';" 
                     onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 4px 12px rgba(0, 0, 0, 0.1)';">
                    <p id="extractions-count" style="font-size: 2.5rem; font-weight: bold; color: #004B8D;">Loading...</p>
                    <p style="color: gray;">Extractions</p>
                    <a href="appointments" style="display: inline-block; margin-top: 15px; padding: 12px 25px; background-color: #004B8D; color: white; text-align: center; border-radius: 20px; text-decoration: none; transition: background-color 0.3s ease;" 
                       onmouseover="this.style.backgroundColor='#006F9F';" 
                       onmouseout="this.style.backgroundColor='#004B8D';">View</a>
                    <span style="display: inline-block; margin-top: 10px; background-color: #E0E0E0; color: #333; padding: 5px 10px; border-radius: 15px; font-size: 0.9rem;">Surgical Procedures</span>
                </div>
            </div>

          <!-- Statistical Graph Section Wrapper -->
<div class="statistical-overview-wrapper w-full mt-10" style="padding-top: 40px;">
    <div class="text-center mb-6">
        <h2 class="text-3xl font-bold text-gray-600">Statistical Overview</h2>
        <p class="text-gray-600 text-lg mt-3">Review the graphical trends for patient visits, bookings, and more.</p>
    </div>

    <!-- Graph Container -->
    <div style="background-color: white; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); border-radius: 10px; padding: 25px; border: 2px solid #004B8D; height: 30vh; overflow: hidden;">
        <canvas id="dashboardChart" style="max-height: 100%;"></canvas>
    </div>
</div>



    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        
        const ctx = document.getElementById('dashboardChart').getContext('2d');
const dashboardChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
        datasets: [{
            label: 'Patient Visits',
            data: [50, 75, 120, 180, 90, 160, 200],
            borderColor: '#004B8D',
            backgroundColor: 'rgba(0, 75, 141, 0.2)',
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false, // Ensures chart fits the container's height
        scales: {
            x: {
                beginAtZero: true
            },
            y: {
                beginAtZero: true
            }
        },
        plugins: {
            legend: {
                position: 'top'
            },
            tooltip: {
                mode: 'index',
                intersect: false
            }
        }
    }
});

    </script>

<?php
    return ob_get_clean();
}
?>

<?php

Sidebar(Content(), Modals());
?>
