<?php
require "template/Validator.php";
include 'template/Sidebar.php';
include 'config/database.php';

include 'components/PatientsModal.php';


include 'scripts/patients/patient_data.php';
include 'scripts/patients/patients_modal.php';
include 'scripts/input_validator.php';







function Content()
{
    ob_start();
?>

    <div class=" w-full h-screen max-h-[calc(100vh-100px)] overflow-y-scroll">
        <div class="flex justify-end items-center p-5 md:px-10 gap-3">
            <input oninput="handleInput(this.value)" type="text" class="py-3 px-5 rounded-2xl text-black" style="color: black;" placeholder="🔍 Search by name">
            <!-- <button class="bg-blue py-3 px-5 text-white rounded-2xl hover:bg-blue/90" onclick="openAddModal()">Add doctor</button> -->
        </div>
        <div class="w-full px-10 flex flex-col">

            <table id="dataTable" class="w-full text-left text-gray-700 bg-white shadow-md rounded-2xl overflow-hidden">
                <thead class="bg-blue text-white">
                    <tr>
                        <th class="p-4 font-semibold">ID Number</th>
                        <th class="p-4 font-semibold">Name</th>
                        <th class="p-4 font-semibold">Contact</th>
                        <th class="p-4 font-semibold">Email Address</th>
                        <th class="p-4 font-semibold">Actions</th>
                    </tr>
                </thead>
                <tbody id="tableBody">
                </tbody>
            </table>
            <div class="text-black py-5 flex justify-between items-center">
                <p>Showing <span id="showing">10</span> of <span id="total">20</span> patients</p>
                <div>
                    <button class="prev-btn bg-blue text-white rounded-2xl px-5 py-2">Previous</button>
                    <button class="next-btn bg-blue text-white rounded-2xl px-5 py-2">Next</button>
                </div>
            </div>


        </div>


    </div>


<?php
    return ob_get_clean();
}
?>



<?php
// Call the Sidebar function and pass the content
Sidebar(Content(), Modals());
?>

<script>
   



 
    

   
  
</script>


