<?php
// getUnreadMessagesCount.php
require 'config/database.php';

session_start();

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['count' => 0]); // Return 0 if no user is logged in
    exit();
}

$user_id = $_SESSION['user_id']; // Get the logged-in user's ID

// Query to get unread messages count for the logged-in user
$query = "
    SELECT COUNT(*) AS count
    FROM messages m
    JOIN conversations c ON c.id = m.conversation_id
    WHERE (c.user1_id = :user_id OR c.user2_id = :user_id)
      AND m.status = 'unread' 
      AND m.receiver_id = :user_id  -- Ensure it's for the logged-in user
";

$stmt = $pdo->prepare($query);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT); // Bind the logged-in user ID
$stmt->execute();

$result = $stmt->fetch(PDO::FETCH_ASSOC);

// Return the unread count
echo json_encode(['count' => $result['count']]);
?>
