<?php
function Modals()
{
    ob_start(); ?>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.6.9/flatpickr.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<!-- Add Service Modal -->
<div id="add_service" class="modal" style="display: none;">
    <div class="modal-content" style="
        display: flex;
        gap: 30px;
        width: 80%; /* Increased the width */
        max-width: 1200px; /* Increased max-width */
        max-height: 95vh; /* Increased max-height */
        background: #f9f9f9; /* Light background color */
        border-radius: 16px;
        padding: 40px;
        overflow-y: auto;
        box-shadow: 0px 20px 80px rgba(0, 0, 0, 0.1); /* Reduced box shadow opacity */
        position: relative;
        transition: all 0.3s ease-in-out;
        opacity: 1; /* Increased opacity for a brighter appearance */
    ">

        <!-- Left Column: Form -->
        <div style="flex: 2; position: relative;">
            <!-- Close button -->
            <div class="close-btn" onclick="closeAddServiceModal()" style="
                position: absolute;
                top: 20px;
                right: 20px;
                font-size: 2rem;
                font-weight: bold;
                color: #333;
                cursor: pointer;
                transition: color 0.3s ease;
            ">&times;</div>

            <!-- Round Logo -->
            <div style="text-align: center; margin-bottom: 20px;">
                <div style=" 
                    width: 60px; 
                    height: 60px; 
                    border-radius: 50%; 
                    background-color: #3498db; 
                    display: flex; 
                    justify-content: center; 
                    align-items: center; 
                    margin: 0 auto;">
                    <i class="fas fa-cogs" style="font-size: 1.5rem; color: #fff;"></i>
                </div>
            </div>

            <!-- Title -->
            <h1 style="
                font-size: 2rem;
                font-weight: 700;
                color: #333;
                text-align: center;
                margin-bottom: 30px;
                font-family: 'Poppins', sans-serif;
                letter-spacing: 1px;
            ">Add Service and Schedule</h1>

            <!-- Form -->
            <form onsubmit="submitAddService(event)">
                <!-- Service Name -->
                <div style="margin-bottom: 20px;">
                    <label for="service_name" style="font-size: 1.1rem; font-weight: 600; color: #333; margin-bottom: 8px;">Service Name</label>
                    <input type="text" id="service_name" name="service_name" class="glow-input" placeholder="Service name" required style="width: 100%; padding: 14px; border-radius: 12px; border: 1px solid #ccc; background: #fff; color: #333; font-size: 1rem; margin-top: 5px; box-sizing: border-box; transition: all 0.3s ease-in-out;" oninput="updatePreview('service_name', this.value)">
                </div>

                <!-- Available To -->
                <div style="margin-bottom: 20px;">
                    <label for="available_to" style="font-size: 1.1rem; font-weight: 600; color: #333; margin-bottom: 8px;">Available To</label>
                    <div class="flex gap-5" style="gap: 15px;">
                        <div class="flex items-center">
                            <input type="checkbox" class="checkbox" id="faculty_cb" value="faculty" onchange="updatePreview('available_to', getAvailableTo())">
                            <label for="faculty" style="font-size: 1rem; color: #333;">Faculty</label>
                        </div>
                        <div class="flex items-center">
                            <input type="checkbox" class="checkbox" id="staff_cb" value="staff" onchange="updatePreview('available_to', getAvailableTo())">
                            <label for="staff" style="font-size: 1rem; color: #333;">Staff</label>
                        </div>
                        <div class="flex items-center">
                            <input type="checkbox" class="checkbox" id="student_cb" value="student" onchange="updatePreview('available_to', getAvailableTo())">
                            <label for="student" style="font-size: 1rem; color: #333;">Student</label>
                        </div>
                    </div>
                </div>

                <!-- Schedule Date -->
                <div style="margin-bottom: 20px;">
                    <label for="schedule_date" style="font-size: 1.1rem; font-weight: 600; color: #333; margin-bottom: 8px;">Schedule Date</label>
                    <input type="date" id="schedule_date" name="schedule_date" class="glow-input" required style="width: 100%; padding: 14px; border-radius: 12px; border: 1px solid #ccc; background: #fff; color: #333; font-size: 1rem; margin-top: 5px; box-sizing: border-box; transition: all 0.3s ease-in-out;" onchange="updatePreview('schedule_date', this.value)">
                </div>

                <!-- Slots -->
                <div style="margin-bottom: 20px;">
                    <label for="morning_slot" style="font-size: 1.1rem; font-weight: 600; color: #333; margin-bottom: 8px;">Morning Slots</label>
                    <input type="number" id="morning_slot" name="morning_slot" class="glow-input" placeholder="Number of morning slots" min="0" required style="width: 100%; padding: 14px; border-radius: 12px; border: 1px solid #ccc; background: #fff; color: #333; font-size: 1rem; margin-top: 5px; box-sizing: border-box; transition: all 0.3s ease-in-out;" oninput="updatePreview('morning_slot', this.value)">
                </div>

                <div style="margin-bottom: 20px;">
                    <label for="afternoon_slot" style="font-size: 1.1rem; font-weight: 600; color: #333; margin-bottom: 8px;">Afternoon Slots</label>
                    <input type="number" id="afternoon_slot" name="afternoon_slot" class="glow-input" placeholder="Number of afternoon slots" min="0" required style="width: 100%; padding: 14px; border-radius: 12px; border: 1px solid #ccc; background: #fff; color: #333; font-size: 1rem; margin-top: 5px; box-sizing: border-box; transition: all 0.3s ease-in-out;" oninput="updatePreview('afternoon_slot', this.value)">
                </div>

                <!-- Action Buttons -->
                <div style="display: flex; justify-content: flex-end; gap: 15px; margin-top: 20px;">
                    <!-- Cancel -->
                    <div onclick="closeAddServiceModal()" style="padding: 12px 20px; border-radius: 12px; background-color: rgba(231, 76, 60, 0.8); color: #fff; font-weight: 600; font-size: 1rem; cursor: pointer; text-align: center; transition: all 0.3s ease-in-out;">Cancel</div>
                    <!-- Save -->
                    <button type="submit" id="add_service_button" style="padding: 12px 20px; border-radius: 12px; background-color: rgba(52, 152, 219, 0.8); color: #fff; font-weight: 600; font-size: 1rem; border: none; cursor: pointer; transition: all 0.3s ease-in-out;">Save</button>
                </div>
            </form>
        </div>

        <!-- Right Column: Preview -->
        <div style="flex: 1; background: rgba(245, 245, 245, 0.95); border-radius: 16px; padding: 20px; box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1); border: 1px solid #ccc;">
            <h2 style="font-size: 1.5rem; font-weight: 600; color: #333; margin-bottom: 15px; text-align: center;">Your Service Preview</h2>
            <form id="preview_form" style="font-size: 1rem; color: #333; line-height: 1.8;">
                <div style="margin-bottom: 15px;">
                    <label for="preview_service_name" style="font-size: 1rem; font-weight: 600; color: #333;">Service Name</label>
                    <input type="text" id="preview_service_name" name="service_name" readonly style="width: 100%; padding: 12px; border-radius: 12px; background: #f1f1f1; color: #333; border: 1px solid #ccc;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label for="preview_schedule_date" style="font-size: 1rem; font-weight: 600; color: #333;">Schedule Date</label>
                    <input type="text" id="preview_schedule_date" name="schedule_date" readonly style="width: 100%; padding: 12px; border-radius: 12px; background: #f1f1f1; color: #333; border: 1px solid #ccc;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label for="preview_morning_slot" style="font-size: 1rem; font-weight: 600; color: #333;">Morning Slots</label>
                    <input type="text" id="preview_morning_slot" name="morning_slot" readonly style="width: 100%; padding: 12px; border-radius: 12px; background: #f1f1f1; color: #333; border: 1px solid #ccc;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label for="preview_afternoon_slot" style="font-size: 1rem; font-weight: 600; color: #333;">Afternoon Slots</label>
                    <input type="text" id="preview_afternoon_slot" name="afternoon_slot" readonly style="width: 100%; padding: 12px; border-radius: 12px; background: #f1f1f1; color: #333; border: 1px solid #ccc;">
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.6.9/flatpickr.min.js"></script>
<script>
    // Modal open/close functionality
    function closeAddServiceModal() {
        document.getElementById('add_service').style.display = 'none';
    }

    // Initialize date picker
    flatpickr("#schedule_date", {
        dateFormat: "Y-m-d", 
    });

    // Update preview data
    function updatePreview(field, value) {
        const previewElement = document.getElementById(preview_${field});
        if (previewElement) {
            previewElement.value = value || "Not selected";
        }
    }

    // Get selected "Available To" values
    function getAvailableTo() {
        let availableTo = [];
        if (document.getElementById('faculty_cb').checked) availableTo.push('Faculty');
        if (document.getElementById('staff_cb').checked) availableTo.push('Staff');
        if (document.getElementById('student_cb').checked) availableTo.push('Student');
        return availableTo.join(', ') || 'Not selected';
    }

    // Handle form submission (Save)
    function submitAddService(event) {
        event.preventDefault();

        const serviceName = document.getElementById('service_name').value;
        const scheduleDate = document.getElementById('schedule_date').value;
        const morningSlot = document.getElementById('morning_slot').value;
        const afternoonSlot = document.getElementById('afternoon_slot').value;

        if (!serviceName || !scheduleDate || !morningSlot || !afternoonSlot) {
            alert("Please fill in all fields");
            return;
        }

        alert(Service Added:\nService Name: ${serviceName}\nSchedule Date: ${scheduleDate}\nMorning Slots: ${morningSlot}\nAfternoon Slots: ${afternoonSlot});
    }
</script>

<style>
    @keyframes border-glow {
        0% {
            border-color: rgba(52, 152, 219, 0.8);
        }
        100% {
            border-color: rgba(120, 11, 126, 0.8);
        }
    }

    .glow-input {
        animation: border-glow 1.5s ease-in-out infinite alternate;
    }
</style>






    <div id="edit_service" class="modal" style="display: none;">
        <div class="w-[90%] md:w-[30%] max-h-[80vh] bg-white rounded-2xl p-5 overflow-y-scroll ">
            <h1 class="text-2xl font-bold">Edit service</h1>
            <form class="space-y-3" onsubmit="updateService(event)" autocomplete="off">
                <div class="flex flex-col">
                    <input type="hidden" id="service_id" name="service_id" required>
                    <label for="service_name">Service name</label>
                    <input type="text" id="edit_service_name" name="service_name" class="input" onblur="validateForm(this, 'service_name_error', 'Service name')" placeholder="Service name" required>
                    <p class="error-message text-red" id="service_name_error"></p>
                </div>
                <div class="flex flex-col">
                    <label class="" for="">Available to</label>
                    <div class="flex gap-5">
                        <div class="flex items-center">
                            <input type="checkbox" class="h-5 w-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500" id="edit_faculty_cb" value="faculty">
                            <label for="faculty" class="ml-2 text-gray-700">Faculty</label>
                        </div>
                        <div class="flex items-center">
                            <input type="checkbox" class="h-5 w-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500" id="edit_staff_cb" value="staff">
                            <label for="staff" class="ml-2 text-gray-700">Staff</label>
                        </div>
                        <div class="flex items-center">
                            <input type="checkbox" class="h-5 w-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500" id="edit_student_cb" value="student">
                            <label for="student" class="ml-2 text-gray-700">Student</label>
                        </div>
                    </div>
                    <p class="text-red error-message" id="available_to_error" style="display: none;">At least 1 is required</p>
                </div>
                <div class="flex justify-end items-center gap-3">
                    <div class="cursor-pointer px-4 py-2 bg-red hover:bg-red/90 rounded-2xl text-white" onclick="closeEditServiceModal()">Cancel</div>
                    <button id="add_service_button" class="px-4 py-2 bg-blue hover:bg-blue/90 rounded-2xl text-white">Save</button>
                </div>
            </form>
        </div>
    </div>


    <div class="modal" id="add_event" style="display: none;">
        <div class="w-[90%] md:w-[30%] max-h-[80vh] bg-white rounded-2xl p-5 overflow-y-scroll ">
            <h1 class="font-bold text-xl text-center" id="selectedDate">12 October 2024 (Saturday)</h1>
            <form class="space-y-3 mt-4" onsubmit="saveEvent(event)">
                <input type="hidden" name="date" id="date">
                <div class="flex flex-col">
                    <label for="morning_slot">Morning slot</label>
                    <input type="text" class="input" id="morning_slot" name="morning_slot" value="0" placeholder="Morning slot" required>
                    <p class="error-message text-red" id="morning_slot_error"></p>
                </div>
                <div class="flex flex-col">
                    <label for="afternoon_slot">Afternoon slot</label>
                    <input type="text" class="input" id="afternoon_slot" name="afternoon_slot" value="0" placeholder="Afternoon slot" required>
                    <p class="error-message text-red" id="afternoon_slot_error"></p>
                </div>
                <div class="flex justify-end items-center gap-4">
                    <div class="cursor-pointer px-4 py-2 bg-red text-white hover:bg-red/80 rounded-2xl" onclick="closeAddEventModal()">Cancel</div>
                    <button type="submit" id="save_button" class="px-4 py-2 bg-blue text-white hover:bg-blue/80 rounded-2xl">Save</button>
                </div>

            </form>
        </div>
    </div>

    <div class="modal" id="event_details" style="display: none;">
        <div class="w-[90%] md:w-[30%] max-h-[80vh] bg-white rounded-2xl p-5 overflow-y-scroll ">
            <h1 class="font-bold text-xl text-center" id="selectedDateEvent">12 October 2024 (Saturday)</h1>
            <form class="space-y-3 mt-4" onsubmit="updateEvent(event)">
                <input type="hidden" name="sched_id" id="sched_id">
                <div class="flex flex-col">
                    <label for="morning_slot_event">Available morning slot</label>
                    <input type="text" class="input" id="morning_slot_event" name="morning_slot" value="0" placeholder="Available morning slot" required>
                    <p class="error-message text-red" id="morning_slot_event_error"></p>
                </div>
                <div class="flex flex-col">
                    <label for="afternoon_slot_event">Available afternoon slot</label>
                    <input type="text" class="input" id="afternoon_slot_event" name="afternoon_slot" value="0" placeholder="Available afternoon slot" required>
                    <p class="error-message text-red" id="afternoon_slot_event_error"></p>
                </div>
                <div class="flex justify-end items-center gap-4">
                    <div class="cursor-pointer px-4 py-2 bg-gray-500 text-white hover:bg-gray-500/80 rounded-2xl" onclick="closeEventDetails()">Cancel</div>
                    <div id="delete_button" data-eventid="" class="cursor-pointer px-4 py-2  bg-red text-white hover:bg-red/80 rounded-2xl" onclick="deleteEvent()">Delete</div>
                    <button type="submit" id="update_button" class="px-4 py-2 bg-blue text-white hover:bg-blue/80 rounded-2xl">Update</button>
                </div>

            </form>
        </div>
    </div>

    

<?php
    return ob_get_clean();
}
?>

<style>
    
</style>