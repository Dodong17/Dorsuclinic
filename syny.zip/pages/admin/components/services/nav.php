
    <div class="">
        <button id="servicesButton" class="px-5 py-2 rounded-2xl bg-blue text-white" onclick="setActiveButton('services')">Services</button>
        <button id="appointmentButton" class="px-5 py-2 rounded-2xl" onclick="setActiveButton('appointment')">Appointment Schedule</button>
    </div>






<script>
    // Default active button
    let activeButton = 'services';


    function setActiveButton(button) {
        activeButton = button;

        // Update the button styles
        document.getElementById('servicesButton').classList.toggle('bg-blue', activeButton === 'services');
        document.getElementById('servicesButton').classList.toggle('text-white', activeButton === 'services');
        document.getElementById('servicesButton').classList.toggle('underline', activeButton !== 'services');

        document.getElementById('appointmentButton').classList.toggle('bg-blue', activeButton === 'appointment');
        document.getElementById('appointmentButton').classList.toggle('text-white', activeButton === 'appointment');
        document.getElementById('appointmentButton').classList.toggle('underline', activeButton !== 'appointment');

        if(activeButton === 'services'){
            document.getElementById('services_component').style.display = 'block';
            document.getElementById('appointment_component').style.display = 'none';
            loadServices(1, 10, "");
        }else{
            document.getElementById('services_component').style.display = 'none';
            document.getElementById('appointment_component').style.display = 'block';
            loadCalendarWithAppointments();
        }
    }

    

    // Initialize by setting the default active button
    
    window.addEventListener('load', () => {
    setActiveButton(activeButton);
});

   
</script>