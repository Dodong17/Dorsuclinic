<div id="services_component" class=" mt-5" style="display: block;">

    <div class="flex justify-end items-center gap-4">
        <input oninput="handleInput(this.value)" type="text" id="search_input" class="input" placeholder="🔍 Search">
        <button class="px-5 py-2 bg-blue text-white rounded-2xl" onclick="openAddServiceModal()">Add service</button>
    </div>

    <div class=" flex flex-col mt-5">

        <table id="dataTable" class="w-full text-left text-gray-700 bg-white shadow-md rounded-2xl overflow-hidden">
            <thead class="bg-blue text-white">
                <tr>
                    <th class="p-4 font-semibold">Service name</th>
                    <th class="p-4 font-semibold">Available to</th>
                    <th class="p-4 font-semibold">Actions</th>
                </tr>
            </thead>
            <tbody id="tableBody">
            </tbody>
        </table>
        <div class="text-black py-5 flex justify-between items-center">
            <p>Showing <span id="showing">10</span> of <span id="total">20</span> services</p>
            <div>
                <button class="prev-btn bg-blue text-white rounded-2xl px-5 py-2">Previous</button>
                <button class="next-btn bg-blue text-white rounded-2xl px-5 py-2">Next</button>
            </div>
        </div>


    </div>

</div>




