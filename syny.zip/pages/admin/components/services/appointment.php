<div id="appointment_component" class="" style="display: none;">
    <div class="mt-5">
        <h2 class="text-center text-2xl font-semibold mb-6" id="calendarTitle"></h2>

        <!-- Calendar Table -->
        <table class="w-full table-fixed" id="calendarTable">
            <!-- The table header and days will be populated here -->
        </table>
    </div>
</div>
