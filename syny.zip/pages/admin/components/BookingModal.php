<?php
function Modals()
{
    ob_start();
?>

    <div id="booking_modal" class="modal" style="display: none;">
        <div class="w-[90%] md:w-[30%] max-h-[80vh] bg-white rounded-2xl p-5 overflow-y-scroll flex justify-center items-center flex-col gap-4">
            <div class="w-full">
                <h1 class="text-2xl font-bold text-center">Confirmation</h1>
                <div class="space-y-2">
                    <p>You can assign a doctor and approve or decline this booking.</p>
                    <select name="doctor_id" id="doctor_id" class="input w-full" required>
                        <option value=""></option>
                    </select>
                    <p class="text-red text-sm" id="doctor-error" style="display:none;">Doctor is required before approving the booking.</p>
                    <div class="flex justify-end items-center gap-3">
                        <div class="px-6 py-2 text-white bg-gray-500 rounded-2xl cursor-pointer hover:bg-gray-500/80" onclick="closeBookingModal()">Cancel</div>
                        <button id="decline_button" onclick="declineBooking()" data-bookingid="" class="px-6 py-2 text-white bg-red rounded-2xl hover:bg-red/80 cursor-pointer">Decline</button>
                        <button id="approve_button" data-bookingid="" onclick="approveBooking()" type="submit" class="px-6 py-2 text-white bg-blue rounded-2xl hover:bg-blue/80">Approve</button>

                    </div>
                </div>


            </div>


        </div>
    </div>



<?php
    return ob_get_clean();
}
?>