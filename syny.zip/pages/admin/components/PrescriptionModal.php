<?php
function Modals()
{
    ob_start();
?>


    <div id="prescription_details" class="modal" style="display: none;">
        <div class="w-[90%] md:w-[30%] max-h-[80vh] bg-white rounded-2xl p-5 overflow-y-scroll flex flex-col gap-4">
            <h2 class="text-2xl font-bold text-center">Prescription Details</h2>

            <div class="w-full space-y-2">
                <p><strong>Booking ID:</strong> <span id="prescription-booking-id"></span></p>
                <p><strong>User Name:</strong> <span id="prescription-user-name"></span></p>
                <p><strong>Doctor Name:</strong> <span id="prescription-doctor-name"></span></p>
                <p><strong>Date Generated:</strong> <span id="prescription-created-at"></span></p>

                <div>
                    <p class="font-semibold">Medicine</p>
                    <p id="prescription-medicine" class="p-2 bg-gray-100 rounded-md"></p>
                </div>

                <div>
                    <p class="font-semibold">Notes</p>
                    <p id="prescription-notes" class="p-2 bg-gray-100 rounded-md"></p>
                </div>
            </div>

            <div class="flex justify-end mt-4">
                <button onclick="closePrescriptionDetails()" class="px-6 py-2 text-white bg-gray-500 rounded-2xl hover:bg-gray-500/80">Close</button>
            </div>
        </div>
    </div>





<?php
    return ob_get_clean();
}
?>