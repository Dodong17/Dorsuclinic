<?php
function Modals()
{
    ob_start(); ?>




    <div class="modal" id="AllowedIdModal" style="display: none;">
        <div class="w-[75%] max-h-[80vh] bg-white rounded-2xl p-5 overflow-y-scroll space-y-3">
            <div class="flex justify-between items-center">
                <h1 class="text-2xl font-bold">Add Allowed ID</h1>
                <button class="bg-red text-white rounded-2xl px-5 py-2 hover:bg-red-600 transition text-center" onclick="closeAllowedIdModal()">X</button>
            </div>
            <form class="flex justify-between items-center gap-3" onsubmit="submitAddAllowedId(event)" autocomplete="off">
                <div class="flex flex-col flex-1">
                    <input type="text" id="allowed_id" name="allowed_id" class="input" onblur="validateForm(this, 'allowed_id_error', 'Allowed ID')" placeholder="Allowed ID">
                    <p class="error-message text-red" id="allowed_id_error"></p>
                </div>
                <button id="add_allowed_id_button" class="px-4 py-2 bg-blue hover:bg-blue/90 rounded-2xl text-white">Add</button>
            </form>

            <table class="table-auto w-full">
                <thead>
                    <tr>
                        <th class="text-left p-2">Id</th>
                        <th class="text-left p-2">Action</th>
                    </tr>
                </thead>
                <tbody id="allowed-id-table-body">

                </tbody>
            </table>


        </div>
    </div>


<?php
    return ob_get_clean();
}
?>