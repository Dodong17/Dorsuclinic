<?php
require "template/Validator.php";
include 'template/Sidebar.php';
include 'config/database.php';
include 'components/ServicesModal.php';

include 'scripts/services/services_data.php';
include 'scripts/services/services_modal.php';

include 'scripts/appointment/appointment_data.php';
include 'scripts/appointment/appointment_modal.php';



include 'scripts/input_validator.php';




function Content()
{
    ob_start();
?>
    <div class="w-full h-screen max-h-[calc(100vh-100px)] overflow-y-scroll p-5 text-black">
        <?php

        include 'components/services/nav.php';
        include 'components/services/service.php';
        include 'components/services/appointment.php';
        ?>

        





    </div>

<?php
    return ob_get_clean();
}
?>

<?php
// Call the Sidebar function and pass the content
Sidebar(Content(), Modals());
?>

