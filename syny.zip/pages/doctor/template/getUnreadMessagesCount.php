<?php
require_once '../config/database.php'; // Ensure PDO connection is established

// Get the user ID from the session or request (e.g., logged-in user)
$userId = isset($_GET['id']) ? $_GET['id'] : null; // You can replace this with a session or authentication method

if ($userId !== null) {
    // Query to count unread messages for the logged-in user
    $stmt = $pdo->prepare("
        SELECT COUNT(m.id) AS count
        FROM messages m
        WHERE m.receiver_id = :user_id AND m.status = 'unread'
    ");
    $stmt->execute(['user_id' => $userId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode(['count' => $result['count']]); // Return the unread message count
} else {
    echo json_encode(['count' => 0]); // If no user is found, return 0
}
?>
