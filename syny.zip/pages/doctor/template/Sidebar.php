<?php

function Sidebar($bodyContent, $modal)
{
    $currentPath = $_SERVER['REQUEST_URI'];
    // Use basename to extract the last segment
    $lastSegment = basename($currentPath);
    $navLinks = [
        [
            "name" => "Dashboard",
            "url" => "dashboard",
            "icon" => "fa-th-large"
        ],

        [
            "name" => "Patients",
            "url" => "patients",
            "icon" => "fa-user"
        ],

        [
            "name" => "Prescriptions",
            "url" => "prescriptions",
            "icon" => "fa-file-text-o"
        ],
        [
            "name" => "Appointments",
            "url" => "appointments",
            "icon" => "fa-calendar"
        ],
        [
            "name" => "Messages",
            "url" => "messages",
            "icon" => "fa-envelope"
        ],

    ]
?>
    <style>
        #sidebar {
            transition: all 0.3s ease;
        }

        #image-placeholder,
        #user-type,
        #navigation {
            transition: all 0.3s ease;
        }

        @media (max-width: 1024px) {
            #sidebar:hover {
                width: 300px;
                position: absolute;
            }

            #sidebar:hover #image-placeholder {
                width: 100px;
                height: 100px;
            }

            #sidebar:hover #user-type,
            #sidebar:hover #navigation {
                display: block;
            }
        }
    </style>

<script>
        const getProfilePhoto = async () => {
            try {
                const response = await axios.get(`/syny/api/UploadProfilePhoto.php?id=${localStorage.getItem("id")}`);
                const image = document.getElementById("profile_picture");
                if (response.data.profile_photo !== "") {
                    image.src = response.data.profile_photo;
                }
                // image.src = response.data.profile_photo;
            } catch (error) {
                console.error('Error fetching profile photo:', error);
            }
        };

        function openFileExplorer() {
            document.getElementById('fileInput').click();
        }

        // Update the profile picture
        const updateProfilePicture = async (input) => {
            if (input.files && input.files[0]) {
                const file = input.files[0];

                // Ensure the file is a PNG or JPEG image
                if (file.type === "image/png" || file.type === "image/jpeg") {
                    try {
                        // Create an image element
                        const img = new Image();
                        const reader = new FileReader();

                        reader.onload = function(e) {
                            img.src = e.target.result;
                        };

                        img.onload = async function() {
                            // Create a canvas element to resize the image
                            const canvas = document.createElement("canvas");
                            const ctx = canvas.getContext("2d");

                            // Define the maximum width or height
                            const maxDimension = 500;
                            let width = img.width;
                            let height = img.height;

                            // Calculate new dimensions while maintaining aspect ratio
                            if (width > height) {
                                if (width > maxDimension) {
                                    height *= maxDimension / width;
                                    width = maxDimension;
                                }
                            } else {
                                if (height > maxDimension) {
                                    width *= maxDimension / height;
                                    height = maxDimension;
                                }
                            }

                            canvas.width = width;
                            canvas.height = height;

                            // Draw the image onto the canvas
                            ctx.drawImage(img, 0, 0, width, height);

                            // Convert the canvas to a compressed base64 string (JPEG with quality 0.8)
                            const base64String = canvas.toDataURL("image/jpeg", 0.8);

                            try {
                                // Send the base64 string to the server
                                const res = await axios.post(`/syny/api/UploadProfilePhoto.php`, {
                                    id: localStorage.getItem("id"),
                                    profile_photo: base64String,
                                });

                                // console.log(res.data);

                                if (res.data.status === "success") {
                                    // Update the image source
                                    document.getElementById('profile_picture').src = base64String;
                                    alert("Profile photo updated successfully!");
                                } else {
                                    alert("Failed to update profile photo. Please try again.");
                                }
                            } catch (error) {
                                console.error("Error uploading profile photo:", error);
                                alert("An error occurred while uploading the profile photo.");
                            }
                        };

                        reader.readAsDataURL(file); // Read the file as a Data URL
                    } catch (error) {
                        console.error("Error processing the image:", error);
                        alert("An error occurred while processing the image.");
                    }
                } else {
                    alert("Please upload a valid image file (PNG or JPEG).");
                }
            } else {
                alert("No file selected. Please choose a file to upload.");
            }
        };




        window.addEventListener("load", () => getProfilePhoto());
    </script>


    <div class="h-screen w-screen" id="page-id" style="display: none;">
        <!-- Sidebar -->
        <div id="sidebar" class="h-screen max-h-screen overflow-y-auto bg-blue lg:w-[300px] w-[75px]">
            <div class="flex flex-col items-center justify-center gap-2 p-5 mt-4">
                <div class="w-[60px] h-[60px] lg:h-[100px] lg:w-[100px] rounded-full bg-[#fff] overflow-hidden" id="image-placeholder">
                    <img
                        src="../assets/image/school_logo.png"
                        id="profile_picture"
                        alt="Davao Oriental State University Logo"
                        loading="lazy"
                        class="h-full w-full object-fill"
                        onclick="openFileExplorer()" />
                    <input
                        type="file"
                        id="fileInput"
                        accept="image/png, image/jpeg"
                        style="display: none;"
                        onchange="updateProfilePicture(this)" />
                </div>
                <p class="hidden lg:block text-white text-2xl font-bold" id="user-type">Doctor</p>
            </div>
            <div class="flex flex-col gap-2 text-white text-xl">
                <?php foreach ($navLinks as $link): ?>
                    <a href="<?php echo $link['url']; ?>" class="flex gap-3 py-3 px-7 items-center">
                        <i class="fa <?php echo $link['icon']; ?>" aria-hidden="true"></i>
                        <p class="hidden lg:block" id="navigation"><?php echo $link['name']; ?></p>
                    </a>
                <?php endforeach; ?>
                <a href="#" onclick="confirmLogout(event)" class="flex gap-3 py-3 px-7 items-center">
                    <i class="fa fa-sign-out" aria-hidden="true"></i>
                    <p class="hidden lg:block" id="navigation">Logout</p>
                </a>


            </div>
        </div>

        <!-- Dashboard -->
        <div class="h-screen max-h-screen overflow-y-auto bg-white flex-1">
            <div class=" nav w-full py-5 px-5 md:px-10 shadow-md  ">
                <p class="font-bold text-2xl text-black"><?php echo ucwords($lastSegment); ?> </p>
            </div>
            <?php echo $bodyContent; ?>

        </div>

        <?php echo $modal; ?>

    </div>
<?php
}
?>

<script>
    function confirmLogout(event) {
        event.preventDefault();
        const confirmation = confirm("Are you sure you want to log out?");

        if (confirmation) {
            // Remove the token from localStorage
            localStorage.removeItem('token');
            localStorage.removeItem("id");
            localStorage.removeItem("role");

            // Redirect to the root page
            window.location.href = '/<?php echo $directoryName; ?>';
        }
    }
</script>