<?php
require "template/Validator.php";
include 'template/Sidebar.php';
include 'config/database.php';
include 'scripts/PasswordCheck.php';
include 'scripts/ChangePasswordModal.php';
include 'scripts/InputValidator.php';
include "scripts/dashboard/dashboard_data.php";
include 'components/ChangePassswordModal.php';

function Content()
{
    ob_start();
?>

    <style>
        /* Custom CSS for Dashboard */
        .dashboard-title-wrapper {
            padding-top: 40px;
            margin-bottom: 30px;
            text-align: center;
        }

        .dashboard-title-wrapper h1 {
            font-size: 2.5rem;
            font-weight: bold;
            color: #333;
        }

        .dashboard-title-wrapper p {
            color: #555;
            font-size: 1.1rem;
            margin-top: 10px;
        }

        /* Custom Card Styles */
        .card {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border: 2px solid #004B8D;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
        }

        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .card .card-title {
            font-size: 2rem;
            font-weight: bold;
            color: #004B8D;
        }

        .card .card-subtitle {
            color: gray;
            margin-top: 5px;
        }

        .card .card-button {
            background-color: #004B8D;
            color: white;
            padding: 12px 25px;
            border-radius: 20px;
            text-align: center;
            margin-top: 15px;
            text-decoration: none;
            display: inline-block;
        }

        .card .card-button:hover {
            background-color: #006F9F;
        }

        .card .card-tag {
            background-color: #E0E0E0;
            color: #333;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9rem;
            margin-top: 10px;
            display: inline-block;
        }

        .alert-box {
            background-color: rgba(255, 0, 0, 0.1);
            color: red;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .alert-box button {
            text-decoration: underline;
            cursor: pointer;
        }

        .grid-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 30px;
        }
    </style>

    <div class="w-full h-screen max-h-[calc(100vh-100px)] overflow-y-auto p-5 text-black">
        <!-- Dashboard Title Wrapper -->
        <div class="dashboard-title-wrapper">
            <h1>Dashboard</h1>
            <p>Monitor key metrics, manage patient bookings, and track procedures. Stay informed with real-time data.</p>
        </div>

        <!-- Password Check Alert -->
        <div id="password_check" class="alert-box">
            <p>Looks like your password has not been changed since your account was created. Please change your password. <button onclick="openChangePasswordModal()">Click here to change your password.</button></p>
        </div>

        <!-- Cards Section -->
        <div class="grid-container">
            <!-- Card for Patients -->
            <div id="patients-card" class="card">
                <p id="patients-count" class="card-title">Loading...</p>
                <p class="card-subtitle">Patients</p>
                <a href="patients" class="card-button">View</a>
                <span class="card-tag">Patients Overview</span>
            </div>

            <!-- Card for Pending Bookings -->
            <div id="pending-bookings-card" class="card">
                <p id="pending-bookings-count" class="card-title">Loading...</p>
                <p class="card-subtitle">New Bookings</p>
                <a href="appointments" class="card-button">View</a>
                <span class="card-tag">Pending Appointments</span>
            </div>

            <!-- Card for Scalings -->
            <div id="scalings-card" class="card">
                <p id="scalings-count" class="card-title">Loading...</p>
                <p class="card-subtitle">Scaling</p>
                <a href="appointments" class="card-button">View</a>
                <span class="card-tag">Dental Procedures</span>
            </div>

            <!-- Card for Extractions -->
            <div id="extractions-card" class="card">
                <p id="extractions-count" class="card-title">Loading...</p>
                <p class="card-subtitle">Extractions</p>
                <a href="appointments" class="card-button">View</a>
                <span class="card-tag">Surgical Procedures</span>
            </div>
        </div>
    </div>

<?php
    return ob_get_clean();
}
?>

<?php
// Call the Sidebar function and pass the content
Sidebar(Content(), Modals());
?>
