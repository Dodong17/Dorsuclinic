<script>
    const fetchApproved = async (page = 1, limit = 10, query = "") => {
        const notyf = new Notyf();
        axios.interceptors.request.use(
            config => {

                return config;
            },
            error => {
                return Promise.reject(error);
            }
        );

        axios.interceptors.response.use(
            response => {

                return response;
            },
            error => {

                return Promise.reject(error);
            }
        );

        try {
            const response = await axios.get(`/${"<?php echo $directoryName; ?>"}/api/booking.php?page=${page}&limit=${limit}&query=${encodeURIComponent(query)}&status=approved`);

            const {
                bookings,
                total
            } = response.data;
            // const uniqueDates = new Set();

            // Update table body with fetched doctor data
            const tableBody = document.getElementById('tableBody');
            tableBody.innerHTML = "";
            if (bookings.length > 0) {

                bookings.forEach((item) => {
                    // uniqueDates.add(item.booking_date);
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-gray-50';
                    row.innerHTML = `
                    <td class="px-4 py-3">${item.user_name}</td>
                    <td class="px-4 py-3">${item.booking_date}</td>
                    <td class="px-4 py-3">${item.session}</td>
                    <td class="px-4 py-3">${item.status}</td>
                      <td class="px-4 py-3">${item.doctor_name}</td>
                    <td class="px-4 py-3 space-x-3">
                        <button onclick='add_prescription_modal(${JSON.stringify(item)})'><i class="fa fa-eye text-blue" style="font-size: 1.5rem;" aria-hidden="true"></i></button>
                    </td>

                `;
                    tableBody.appendChild(row);
                });
            } else {
                tableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="px-4 py-3 text-center text-gray-500">No data found.</td>
                </tr>
            `;
            }

            // Update pagination display
            const totalPages = Math.ceil(total / limit);
            document.getElementById('showing').textContent = bookings.length;
            document.getElementById('total').textContent = total;

            // Update previous/next button states
            const prevButton = document.querySelector('.prev-btn');
            const nextButton = document.querySelector('.next-btn');
            prevButton.disabled = page === 1;
            nextButton.disabled = page === totalPages;

            // Add event listeners for pagination
            prevButton.onclick = () => fetchBookings(page - 1, limit);
            nextButton.onclick = () => fetchBookings(page + 1, limit);
        } catch (error) {
            console.error('Error loading doctors:', error);
            tableBody.innerHTML = `<td colspan="5" class="px-4 py-3">Error fetching bookings</td>`;

        }
    }

    const createPrescription = async (event) => {
        event.preventDefault();
        const notyf = new Notyf();
        const form = event.target;
        const formData = new FormData(form);
        const objectForm = Object.fromEntries(formData);
        const bookingData = JSON.parse(document.getElementById("create_prescription_button").getAttribute("data-bookingdata"));

        // Set the button to loading state
        const button = document.getElementById("create_prescription_button");
        button.disabled = true;
        button.textContent = "Adding...";





        try {
            if (objectForm.teeth_no || objectForm.teeth_no === '') {
                const res = await axios.post(`/${"<?php echo $directoryName; ?>"}/api/ExtractedTeeth.php`, {
                    user_id: bookingData.user_id,
                    teeth_no: objectForm.teeth_no,
                    description: objectForm.description
                });
            }
            const res = await axios.post(`/${"<?php echo $directoryName; ?>"}/api/Prescriptions.php`, {
                booking_id: bookingData.id,
                user_id: bookingData.user_id,
                doctor_id: localStorage.getItem("id"),
                "medicine": objectForm.medicine,
                "notes": objectForm.notes
            });

            if (res.status === 200) {
                notyf.success("Prescription created successfully.");
                fetchApproved(1, 10, "");
                close_add_prescription_modal()
            } else {
                notyf.error("Something went wrong.");
            }
        } catch (error) {
            notyf.error("An error occurred. Please try again.");
        } finally {
            // Reset the button to its original state
            button.disabled = false;
            button.textContent = "Add";
        }
    };





    window.addEventListener("load", () => fetchApproved(1, 10, ""))
</script>