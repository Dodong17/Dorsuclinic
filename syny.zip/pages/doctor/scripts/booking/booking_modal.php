<script>
    

    function add_prescription_modal(details){


        document.getElementById("add_prescription_modal").style.display = 'flex';
        document.getElementById("create_prescription_button").setAttribute("data-bookingdata", JSON.stringify(details));
    }
    function close_add_prescription_modal(){
        document.getElementById("add_prescription_modal").style.display = 'none';
    }
</script>