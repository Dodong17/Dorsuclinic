<script>
    const handleSubmitEdit = async (event) => {
        var notyf = new Notyf();
        event.preventDefault();
        document.getElementById("edit_submit_button").innerHTML = "Saving...";
        const form = event.target;
        const formData = new FormData(form);
        document.getElementById("edit_form_fieldset").disabled = true;
        const dataObject = Object.fromEntries(formData.entries());
        try {
            const response = await axios.patch(`/<?php echo $directoryName; ?>/api/users.php`, dataObject, {
                header: {
                    "Content-Type": "application/json"
                }
            });
            if (response.data.status === "success") {
                notyf.success(response.data.message);
                loadUsersData(1, 10, "");
                document.getElementById("edit_modal").style.display = "none";
            } else if (response.data.status === "failed") {
                const element = document.getElementById(`edit_${response.data.error}_error`);
                element.classList.remove("hidden");
                element.innerHTML = response.data.message;
                notyf.error(response.data.message);
                document.getElementById("edit_submit_button").innerHTML = "Save";
            }
        } catch (error) {
            notyf.error("Error: " + error);
        } finally {
            document.getElementById("edit_form_fieldset").disabled = false;
            document.getElementById("edit_submit_button").innerHTML = "Save";
        }
    }
    const loadUsersData = async (page = 1, limit = 10, query = "") => {

        axios.interceptors.request.use(
            config => {

                return config;
            },
            error => {
                return Promise.reject(error);
            }
        );

        axios.interceptors.response.use(
            response => {

                return response;
            },
            error => {

                return Promise.reject(error);
            }
        );

        try {
            const response = await axios.get(`/${"<?php echo $directoryName; ?>"}/api/patients.php?page=${page}&limit=${limit}&query=${encodeURIComponent(query)}`);

            const {
                users,
                total
            } = response.data;

            // Update table body with fetched doctor data
            const tableBody = document.getElementById('tableBody');
            tableBody.innerHTML = "";
            if (users.length > 0) {
                users.forEach((item) => {
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-gray-50';
                    row.innerHTML = `
            <td class="px-4 py-3">${item.id_number}</td>
            <td class="px-4 py-3">${item.first_name} ${item.last_name}</td>
            <td class="px-4 py-3">${item.contact}</td>
            <td class="px-4 py-3">${item.email}</td>
            <td class="px-4 py-3 space-x-3">
                <button onclick='openEditModal(${JSON.stringify(item)})'><i class="fa fa-eye text-blue" style="font-size: 1.5rem;" aria-hidden="true"></i>
            </td>

        `;
                    tableBody.appendChild(row);
                });
            } else {
                tableBody.innerHTML = `
        <tr>
            <td colspan="5" class="px-4 py-3 text-center text-gray-500">No data found.</td>
        </tr>
    `;
            }

            // Update pagination display
            const totalPages = Math.ceil(total / limit);
            document.getElementById('showing').textContent = users.length;
            document.getElementById('total').textContent = total;

            // Update previous/next button states
            const prevButton = document.querySelector('.prev-btn');
            const nextButton = document.querySelector('.next-btn');
            prevButton.disabled = page === 1;
            nextButton.disabled = page === totalPages;

            // Add event listeners for pagination
            prevButton.onclick = () => loadUsersData(page - 1, limit);
            nextButton.onclick = () => loadUsersData(page + 1, limit);
        } catch (error) {
            console.error('Error loading doctors:', error);
            tableBody.innerHTML = `<td colspan="5" class="px-4 py-3">Error fetching doctors</td>`;
        }
    };

    const get_patient_history = async (data) => {
        const notyf = new Notyf();
        try {
            const responseTooth = await axios.get(`/<?php echo $directoryName; ?>/api/ExtractedTeeth.php?id=${data.id}`);
            const responsePrescriptions = await axios.get(`/<?php echo $directoryName; ?>/api/FetchPresciptions.php?id=${data.id}`);

            console.log(responsePrescriptions);



            // document.getElementById("patient_name").innerHTML = data.first_name + " " + data.last_name;

            const container = document.getElementById("tooth-container");

            // Clear the container before rendering
            container.innerHTML = "";

            // Loop to create 32 teeth
            for (let i = 1; i <= 32; i++) {
                const toothItem = document.createElement("div");
                // Check if the current tooth number is in the response data
                const tooth = responseTooth.data.find(item => item.teeth_no === i);
                toothItem.className = `flex flex-col items-center justify-center tooth-item ${tooth ? "cursor-pointer" : "cursor-default"}`;
                toothItem.onclick = () => {
                    if (tooth) {
                        openToothDetails(tooth);
                    }
                };
                // Default SVG for tooth not found in database
                let svg = `
                <svg width="50px" height="50px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.19807 4.45825C8.55418 4.22291 7.94427 4 7 4C5 4 4 6 4 8.5C4 10.0985 4.40885 11.0838 4.83441 12.1093C5.0744 12.6877 5.31971 13.2788 5.5 14C5.649 14.596 5.7092 15.4584 5.77321 16.3755C5.92401 18.536 6.096 21 7.5 21C8.39898 21 8.79286 19.5857 9.22652 18.0286C9.75765 16.1214 10.3485 14 12 14C13.6515 14 14.2423 16.1214 14.7735 18.0286C15.2071 19.5857 15.601 21 16.5 21C17.904 21 18.076 18.536 18.2268 16.3755C18.2908 15.4584 18.351 14.596 18.5 14C18.6803 13.2788 18.9256 12.6877 19.1656 12.1093C19.5912 11.0838 20 10.0985 20 8.5C20 6 19 4 17 4C16.0557 4 15.4458 4.22291 14.8019 4.45825C14.082 4.72136 13.3197 5 12 5C10.6803 5 9.91796 4.72136 9.19807 4.45825Z" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            `;



                // If the tooth is found, use the first SVG
                if (tooth) {
                    svg = `
                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                        width="50px" height="50px" viewBox="0 0 512 512" xml:space="preserve">
                        <g>
                            <path class="st0" d="M363.4,1.995c-53.797-8.078-84.828,10.813-107.406,13.5c-22.563-2.688-53.594-21.578-107.391-13.5
                                C86.931,11.276,46.322,70.323,55.541,169.292c9.547,102.531,68.984,178.078,76.141,272.5c6.938,91.453,53.813,78.25,65.734,45.875
                                c11.938-32.375,32.328-121.406,58.578-121.406s46.656,89.031,58.578,121.406c11.938,32.375,58.813,45.578,65.75-45.875
                                c7.156-94.422,66.594-169.969,76.141-272.5C465.666,70.323,425.072,11.276,363.4,1.995z" />
                        </g>
                    </svg>
                `;
                }

                // Add SVG to the tooth item
                toothItem.innerHTML = svg;

                // Add label (tooth number)
                const label = document.createElement("p");
                label.textContent = i;
                toothItem.appendChild(label);

                // Append the tooth item to the container
                container.appendChild(toothItem);
            }

            // Creating the table for Medicine and Notes
            const tableContainer = document.getElementById("table-container");

            // Clear the table before rendering
            tableContainer.innerHTML = "";

            // Check if there are any prescriptions data
            if (responsePrescriptions.data && responsePrescriptions.data.length > 0) {
                const table = document.createElement("table");
                table.className = "table-auto w-full border-collapse"; // Tailwind CSS classes for table style

                // Create table header
                const thead = document.createElement("thead");
                const trHeader = document.createElement("tr");
                const thMedicine = document.createElement("th");
                thMedicine.className = "border p-2 text-left font-semibold"; // Styling
                thMedicine.textContent = "Medicine";
                const thNotes = document.createElement("th");
                thNotes.className = "border p-2 text-left font-semibold"; // Styling
                thNotes.textContent = "Notes";
                trHeader.appendChild(thMedicine);
                trHeader.appendChild(thNotes);
                thead.appendChild(trHeader);
                table.appendChild(thead);

                // Create table body
                const tbody = document.createElement("tbody");
                responsePrescriptions.data.forEach(prescription => {
                    const tr = document.createElement("tr");

                    // Create medicine cell
                    const tdMedicine = document.createElement("td");
                    tdMedicine.className = "border p-2"; // Styling
                    tdMedicine.textContent = prescription.medicine || "N/A"; // Assuming 'medicine' is the key in your response

                    // Create notes cell
                    const tdNotes = document.createElement("td");
                    tdNotes.className = "border p-2"; // Styling
                    tdNotes.textContent = prescription.notes || "N/A"; // Assuming 'notes' is the key in your response

                    tr.appendChild(tdMedicine);
                    tr.appendChild(tdNotes);
                    tbody.appendChild(tr);
                });
                table.appendChild(tbody);

                // Append the table to the table container
                tableContainer.appendChild(table);
            } else {
                tableContainer.innerHTML = "<p class='text-center'>No prescriptions available.</p>";
            }

        } catch (error) {
            console.error('Error fetching patient history:', error);
        }
    };

    function handleInput(query) {


        loadUsersData(1, 10, query);

    }

    const deletePatient = async () => {
        var notyf = new Notyf();
        const id = document.getElementById("delete_button").getAttribute("data-id");
        try {
            const response = await axios.delete(`/${"<?php echo $directoryName; ?>"}/api/users.php?id=${id}`);
            if (response.data.status == "success") {
                loadUsersData(1, 10, "");
                notyf.success(response.data.message);
                document.getElementById("delete_modal").style.display = "none";
            } else {
                notyf.error(response.data.message);
            }
        } catch (error) {
            notyf.error(error);
        }

    }

    window.addEventListener('load', () => loadUsersData(1, 10, ""));
</script>