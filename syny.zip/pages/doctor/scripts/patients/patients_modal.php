<script>
    function closeAddModal() {
    document.getElementById("add_modal").style.display = "none";
}

function openAddModal() {
    document.getElementById("add_modal").style.display = "flex";
}

function closeDeleteModal(){
    document.getElementById("delete_modal").style.display = "none";
}
function openDeleteModal(id){
    document.getElementById("delete_modal").style.display = "flex";
    const deleteButton = document.getElementById("delete_button");
    deleteButton.setAttribute("data-id", id);
}

function openEditModal(patient){
    document.getElementById("edit_modal").style.display = "flex";
    document.getElementById("edit_id").value = patient.id;
    document.getElementById("edit_id_number").value = patient.id_number;
    document.getElementById("edit_first_name").value = patient.first_name;
    document.getElementById("edit_last_name").value = patient.last_name;
    document.getElementById("edit_contact").value = patient.contact;
    document.getElementById("edit_email").value = patient.email;
    document.getElementById("edit_birth_date").value = patient.birth_date;
    document.getElementById("edit_gender").value = patient.gender;
    get_patient_history(patient);

    

}

  
function formatDate(dateString) {
        const date = new Date(dateString);
        const options = {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
            hour12: true
        };
        return date.toLocaleString('en-US', options);
    }

    function openToothDetails(data) {

        document.getElementById("tooth_details_modal").style.display = "flex";
        document.getElementById("formatted-date").textContent = formatDate(data.date);
        document.getElementById("description").textContent = data.description;
        document.getElementById("teeth-no").textContent = data.teeth_no;

    }

    function closeToothDetailsModal() {
        document.getElementById("tooth_details_modal").style.display = "none";
    }

function closeEditModal() {
    document.getElementById("edit_modal").style.display = "none";

}
</script>