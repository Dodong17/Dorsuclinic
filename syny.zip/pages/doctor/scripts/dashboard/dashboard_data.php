<script>
    const fetchDashboard = async () => {
        const notyf = new Notyf();
        axios.interceptors.request.use(
            config => {

                return config;
            },
            error => {
                return Promise.reject(error);
            }
        );

        axios.interceptors.response.use(
            response => {

                return response;
            },
            error => {

                return Promise.reject(error);
            }
        );

        try {
            const response = await axios.get(`/${"<?php echo $directoryName; ?>"}/api/DoctorDashboard.php`);

            const {
                patients,
                pending_bookings,
                extractions,
                scalings
            } = response.data;

            // Update the UI with fetched data
            document.getElementById('patients-count').textContent = patients;
            document.getElementById('pending-bookings-count').textContent = pending_bookings;
            document.getElementById('scalings-count').textContent = scalings;
            document.getElementById('extractions-count').textContent = extractions;

        } catch (error) {
            console.error('Error loading counts:', error);
        }
    }

    window.addEventListener("load", () => fetchDashboard())
</script>