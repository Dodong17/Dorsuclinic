<script>

    const checkPassword = async () => {
        
        const formData = new FormData();
        formData.append("id", localStorage.getItem("id"));
        try {
            const response = await axios.post(`/<?php echo $directoryName; ?>/api/doctors.php`, formData, {
                headers: {
                    "Content-Type": "application/json"
                }
            });
            if (response.data.status === "success") {
                if(!response.data.password_changed){
                    document.getElementById("password_check").style.display = "block";
                }else{
                    document.getElementById("password_check").style.display = "none";
                }
            }else{
                console.log("something went wrong")
            }
        } catch (error) {
            console.log(error)
        }
    }

   
    

    window.addEventListener("load", checkPassword);


</script>