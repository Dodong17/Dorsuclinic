<script>
    function closeChangePasswordModal() {
        document.getElementById("change_password_modal").style.display = "none";
    }

    function openChangePasswordModal() {
        document.getElementById("change_password_modal").style.display = "flex";
    }

    const handleSubmit = async (event) => {
        const notyf = new Notyf();
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);
        formData.append("id", localStorage.getItem("id"));

        const formDataObject = Object.fromEntries(formData.entries());

        try {
            const response = await axios.patch(`/<?php echo $directoryName; ?>/api/doctors.php`, formDataObject, {
                headers: {
                    "Content-Type": "application/json"
                }
            });
            if (response.data.status === "success") {
                notyf.success(response.data.message);
                document.getElementById("change_password_modal").style.display = "none";
                checkPassword();
            } else {
                notyf.error(response.data.message);
            }
        } catch (error) {
            notyf.error(error);
        }
    }


    function validatePassword(input, passwordId, errorId) {
        const password = document.getElementById(passwordId).value;
        const confirmPassword = input.value;

        if (password !== confirmPassword) {
            const errorElement = document.getElementById(errorId);
            errorElement.classList.remove("hidden");
            errorElement.innerHTML = "Password and confirm password do not match";
            return false;
        } else {
            const errorElement = document.getElementById(errorId);
            errorElement.classList.add("hidden");
            errorElement.innerHTML = "";
            return true;
        }

    }
</script>