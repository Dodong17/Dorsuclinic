<script>
    let currentConversationId = null;

const fetchContacts = async (search = "") => {
    const notyf = new Notyf();

    try {
        const response = await axios.get('/<?php echo $directoryName; ?>/api/messages.php?id=' + localStorage.getItem("id") + '&search=' + encodeURIComponent(search));
        const contacts = response.data;

        const contactList = document.getElementById("contact-list");
        contactList.innerHTML = "";

        contacts.forEach(contact => {
            const li = document.createElement("li");
            li.className = "p-2 rounded hover:bg-gray-200 cursor-pointer";
            li.dataset.id = contact.id;

            const contactName = document.createElement("span");
            contactName.textContent = `${contact.first_name} ${contact.last_name}`;

            if (contact.unread_count > 0) {
                contactName.classList.add("font-bold", "text-blue-600");
            } else {
                contactName.classList.add("text-gray-800");
            }

            const unreadIndicator = document.createElement("span");
            unreadIndicator.className = "unread-indicator";

            if (contact.unread_count > 0) {
                unreadIndicator.style.display = 'inline-block';
            } else {
                unreadIndicator.style.display = 'none';
            }

            li.appendChild(contactName);
            li.appendChild(unreadIndicator);

            li.addEventListener("click", async () => {
                const userId = contact.id;
                const conversationId = await getOrCreateConversation(userId);
                if (conversationId) {
                    document.getElementById("conversation-view").style.display = "flex";
                    document.getElementById("no-conversation-view").style.display = "none";
                    currentConversationId = conversationId;
                    fetchMessages(conversationId);
                    initializeSendMessage();

                    await markMessagesAsRead(conversationId, userId);

                    contact.unread_count = 0;
                    unreadIndicator.style.display = 'none';
                    contactName.classList.remove("font-bold", "text-blue-600");
                    contactName.classList.add("text-gray-800");
                }
            });

            contactList.appendChild(li);
        });
    } catch (error) {
        console.error('Error loading contacts:', error);
    }
};

const markMessagesAsRead = async (conversationId, userId) => {
    try {
        const res = await axios.post('/<?php echo $directoryName; ?>/api/markRead.php', {
            conversationId,
            receiverId: userId,
        });
        console.log('Messages marked as read:', res.data);
    } catch (error) {
        console.error('Error marking messages as read', error);
    }
};




    function handleSearch(search) {


        fetchContacts(search);

    }

    const getOrCreateConversation = async (userId) => {

        const currentUserId = localStorage.getItem("id");
        try {
            const response = await axios.get(`/<?php echo $directoryName; ?>/api/getOrCreateConversation.php?user1_id=${currentUserId}&user2_id=${userId}`);
            return response.data.conversation_id; // This will be used for fetching messages and sending new messages.
        } catch (error) {
            console.error('Error fetching or creating conversation:', error);
        }
    };

    const fetchMessages = async (conversationId) => {
        try {
            const response = await axios.get(`/<?php echo $directoryName; ?>/api/fetchMessages.php?conversation_id=${conversationId}`);
            displayMessages(response.data);
        } catch (error) {
            console.error('Error loading messages:', error);
        }
    };

    const sendMessage = async (conversationId, senderId, message) => {
        try {
            await axios.post(`/<?php echo $directoryName; ?>/api/sendMessage.php`, {
                conversationId,
                senderId,
                message,
            });
            // Optionally refresh messages after sending
            fetchMessages(conversationId);
        } catch (error) {
            console.error('Error sending message:', error);
        }
    };


    const sendMessageHandler = async () => {
        const messageInput = document.getElementById('message-input');
        const message = messageInput.value.trim();

        if (message && currentConversationId) { // Ensure there is a message and conversation ID
            await sendMessage(currentConversationId, localStorage.getItem("id"), message);
            messageInput.value = ''; // Clear input after sending
        }
    };

    // Function to initialize sending message logic
    const initializeSendMessage = () => {
        const sendButton = document.getElementById('send-button'); // Reference to the send button

        if (sendButton) {
            // Remove previous event listener if it exists
            sendButton.removeEventListener('click', sendMessageHandler);

            // Add the event listener for sending a message
            sendButton.addEventListener('click', sendMessageHandler);
        } else {
            console.error("Send button not found.");
        }
    };


    const displayMessages = (data) => {

        const messageContainer = document.getElementById('message-container'); // Select the message container
        messageContainer.innerHTML = ''; // Clear existing messages

        // Check if there are no messages
        if (data.length === 0) {
            const noMessagesDiv = document.createElement("div");
            noMessagesDiv.className = "text-gray-500 text-center p-4"; // Style for no messages
            noMessagesDiv.textContent = "Start a conversation"; // Set the message text
            messageContainer.appendChild(noMessagesDiv); // Append the message to the container
            return; // Exit the function
        }

        // Iterate through the messages and display them
        data.forEach(d => {
            const {
                sender_id,
                message,
                created_at
            } = d; 
            const currentUserId = Number(localStorage.getItem("id"));


            const isSender = sender_id === currentUserId;


            console.log(d)
       

            const messageDiv = document.createElement("div");
            messageDiv.className = `flex items-start ${isSender ? 'justify-end' : ''}`;

            const messageContentDiv = document.createElement("div");
            messageContentDiv.className = "ml-3";

            const messageBubble = document.createElement("div");
            messageBubble.className = `bg-${isSender ? 'gray-500' : 'blue'} text-white p-3 rounded-lg ${isSender ? 'rounded-br-none' : 'rounded-bl-none'}`;
            messageBubble.textContent = message; // Set message content

            const timestampSpan = document.createElement("span");
            timestampSpan.className = "text-xs text-gray-400";
            timestampSpan.textContent = new Date(created_at).toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit'
            }); // Format the timestamp

            messageContentDiv.appendChild(messageBubble);
            messageContentDiv.appendChild(timestampSpan);
            messageDiv.appendChild(messageContentDiv);
            messageContainer.appendChild(messageDiv);
        });

        messageContainer.scrollTop = messageContainer.scrollHeight;
    };


    window.addEventListener('load', () => fetchContacts(search = ""));
</script>