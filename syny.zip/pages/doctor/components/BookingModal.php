<?php
function Modals()
{
    ob_start();
?>

    <div id="add_prescription_modal" class="modal" style="display: none;">
        <div class="w-[90%] md:w-[30%] max-h-[80vh] bg-white rounded-2xl p-5 overflow-y-scroll flex justify-center items-center flex-col gap-4">
            <div class="w-full">
                <h1 class="text-2xl font-bold text-center">Prescription</h1>
                <form onsubmit="createPrescription(event)" class="space-y-2">

                    <label for="medicine" class="block text-sm font-medium">Medicine</label>
                    <input type="text" id="medicine" name="medicine" class="input w-full" placeholder="Enter medicine" required>

                    <label for="notes" class="block text-sm font-medium">Additional Notes</label>
                    <textarea id="notes" name="notes" class="input w-full h-24" placeholder="Enter any additional notes..."></textarea>

                    <p>Extraction Details</p>
                    <p class="block text-sm font-medium text-red">Leave this field blank if you are not extracting any teeth</p>

                    <label for="teeth_no" class="block text-sm font-medium">Teeth Number</label>
                    <select name="teeth_no" id="teeth_no" class="input w-full">
                        <option value="">Select teeth number</option>
                       
                        <script>
                            for (let i = 1; i <= 32; i++) {
                                document.write(`<option value="${i}">${i}</option>`);
                            }
                        </script>
                    </select>

                    <label for="description" class="block text-sm font-medium">Additional Notes</label>
                    <textarea id="description" name="description" class="input w-full h-24" placeholder="Enter any additional notes..."></textarea>


                    <div class="flex justify-end items-center gap-3 mt-4">
                        <div class="px-6 py-2 text-white bg-gray-500 rounded-2xl cursor-pointer hover:bg-gray-500/80" onclick="close_add_prescription_modal()">Cancel</div>
                        <button id="create_prescription_button" type="submit" data-bookingdata="" type="submit" class="px-6 py-2 text-white bg-blue rounded-2xl hover:bg-blue/80">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>




<?php
    return ob_get_clean();
}
?>