<?php
function Modals()
{
    ob_start();
?>
    <style>
        #tooth-container {
            display: grid;
            grid-template-columns: repeat(16, 1fr);
            gap: 12px;
            width: 100%;
            margin: 0 auto;
        }

        @media (max-width: 768px) {
            #tooth-container {
                grid-template-columns: repeat(6, 1fr);
                /* On smaller screens: 6 columns */
            }
        }
    </style>
    <div id="add_modal" class="modal" style="display: none;">
        <div class="w-[90%] md:w-[60%] max-h-[80vh] bg-white rounded-2xl p-5 overflow-y-scroll">
            <h1 class="font-bold text-2xl mb-3">Add doctor</h1>
            <fieldset id="form_fieldset">
                <form class="space-y-5" onsubmit="handleSubmit(event)">
                    <div class="flex md:flex-row flex-col gap-5">
                        <div class="w-full flex flex-col">
                            <label for="id_number">ID number</label>
                            <input type="text" id="id_number" name="id_number" onblur="validateForm(this, 'id_number_error', 'ID number')" class="input" placeholder="ID number">
                            <p class="error-message text-sm text-red hidden" id="id_number_error"></p>
                        </div>
                        <div class="w-full flex flex-col">
                            <label for="first_name">First name</label>
                            <input type="text" id="first_name" name="first_name" oninput="checkNumberOnName(this)" onblur="validateForm(this, 'first_name_error', 'First name')" class="input" placeholder="First name">
                            <p class="error-message text-sm text-red hidden" id="first_name_error"></p>
                        </div>
                        <div class="w-full flex flex-col">
                            <label for="last_name">Last name</label>
                            <input type="text" id="last_name" name="last_name" oninput="checkNumberOnName(this)" onblur="validateForm(this, 'last_name_error', 'Last name')" class="input" placeholder="Last name">
                            <p class="error-message text-sm text-red hidden" id="last_name_error"></p>
                        </div>
                    </div>
                    <div class="flex md:flex-row flex-col gap-5">
                        <div class="w-full flex flex-col">
                            <label for="contact">Contact number</label>
                            <input type="text" id="contact" name="contact" onblur="validateForm(this, 'contact_error', 'Contact number')" class="input" placeholder="Contact number">
                            <p class="error-message text-sm text-red hidden" id="contact_error"></p>
                        </div>
                        <div class="w-full flex flex-col">
                            <label for="email">Email address</label>
                            <input type="text" id="email" name="email" onblur="validateForm(this, 'email_error', 'Email address')" class="input" placeholder="Email address">
                            <p class="error-message text-sm text-red hidden" id="email_error"></p>
                        </div>
                    </div>
                    <div class="flex md:flex-row flex-col gap-5">
                        <div class="w-full flex flex-col">
                            <label for="birth_date">Birthdate</label>
                            <input type="date" id="birth_date" name="birth_date" onblur="validateForm(this, 'birth_date_error', 'Birthdate')" class="input" placeholder="Birthdate">
                            <p class="error-message text-sm text-red hidden" id="birth_date_error"></p>
                        </div>
                        <div class="w-full flex flex-col">
                            <label for="gender">Gender</label>
                            <select name="gender" id="gender" onblur="validateForm(this, 'gender_error', 'Gender')" class="input" required>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                            <p id="gender_error" class="error-message text-sm text-red hidden"></p>
                        </div>
                    </div>
                    <div class="flex justify-end items-center gap-3">
                        <div class="px-6 py-2 text-white bg-red rounded-2xl cursor-pointer hover:bg-red/80" onclick="closeAddModal()">Cancel</div>
                        <button id="submit_button" type="submit" class="px-6 py-2 text-white bg-blue rounded-2xl hover:bg-blue/80">Add</button>
                    </div>
                </form>
            </fieldset>

        </div>
    </div>

    <div id="delete_modal" class="modal" style="display: none;">
        <div class="w-[90%] md:w-[30%] max-h-[80vh] bg-white rounded-2xl p-5 overflow-y-scroll flex justify-center items-center flex-col gap-4">
            <i class="fa fa-question text-gray-500" style="font-size: 5rem;" aria-hidden="true"></i>
            <p class="text-black text-center">Are you sure you want to delete this information? This action cannot be undone.</p>
            <div class="flex justify-center items-center gap-3">
                <div class="px-6 py-2 text-white bg-red rounded-2xl cursor-pointer hover:bg-red/80" onclick="closeDeleteModal()">No</div>
                <button id="delete_button" onclick="deletePatient()" data-id="" class="px-6 py-2 text-white bg-blue rounded-2xl hover:bg-blue/80">Yes</button>
            </div>
        </div>
    </div>

    <div id="tooth_details_modal" class="modal z-50" style="display: none;">
        <div class="w-[90%] md:w-[30%] max-h-[80vh] bg-white rounded-2xl p-5 overflow-y-scroll flex justify-center items-center flex-col gap-4">
            <!-- Modal Content -->
            <div class="flex justify-center items-center gap-3">
                <div class="text-xl font-semibold">Details</div>
            </div>

            <!-- Date -->
            <div class="flex justify-start w-full gap-2">
                <div class="font-medium text-gray-700">Date:</div>
                <div id="formatted-date" class="text-gray-900"></div>
            </div>

            <!-- Description -->
            <div class="flex justify-start w-full gap-2">
                <div class="font-medium text-gray-700">Description:</div>
                <div id="description" class="text-gray-900">11</div>
            </div>

            <!-- Teeth Number -->
            <div class="flex justify-start w-full gap-2">
                <div class="font-medium text-gray-700">Teeth No:</div>
                <div id="teeth-no" class="text-gray-900">32</div>
            </div>

            <!-- Close Button -->
            <div class="flex justify-center items-center gap-3">
                <div class="px-6 py-2 text-white bg-red rounded-2xl cursor-pointer hover:bg-red/80" onclick="closeToothDetailsModal()">Close</div>
            </div>
        </div>
    </div>


    <div id="edit_modal" class="modal" style="display: none;">
        <div class="w-[90%]  max-h-[80vh] bg-white rounded-2xl p-5 overflow-y-scroll">
            <h1 class="font-bold text-2xl mb-3">Patient information</h1>
            <fieldset id="edit_form_fieldset">
                <form class="space-y-5" onsubmit="handleSubmitEdit(event)">
                    <div class="flex md:flex-row flex-col gap-5">
                        <input type="hidden" id="edit_id" name="id">
                        <div class="w-full flex flex-col">
                            <label for="id_number">ID number</label>
                            <input type="text" id="edit_id_number" name="id_number" onblur="validateForm(this, 'edit_id_number_error', 'ID number')" class="input" placeholder="ID number" readonly>
                            <p class="error-message text-sm text-red hidden" id="edit_id_number_error"></p>
                        </div>
                        <div class="w-full flex flex-col">
                            <label for="first_name">First name</label>
                            <input type="text" id="edit_first_name" name="first_name" oninput="checkNumberOnName(this)" onblur="validateForm(this, 'edit_first_name_error', 'First name')" class="input" placeholder="First name" readonly>
                            <p class="error-message text-sm text-red hidden" id="edit_first_name_error"></p>
                        </div>
                        <div class="w-full flex flex-col">
                            <label for="last_name">Last name</label>
                            <input type="text" id="edit_last_name" name="last_name" oninput="checkNumberOnName(this)" onblur="validateForm(this, 'edit_last_name_error', 'Last name')" class="input" placeholder="Last name" readonly>
                            <p class="error-message text-sm text-red hidden" id="edit_last_name_error"></p>
                        </div>
                    </div>
                    <div class="flex md:flex-row flex-col gap-5">
                        <div class="w-full flex flex-col">
                            <label for="contact">Contact number</label>
                            <input type="text" id="edit_contact" name="contact" onblur="validateForm(this, 'edit_contact_error', 'Contact number')" class="input" placeholder="Contact number" readonly>
                            <p class="error-message text-sm text-red hidden" id="edit_contact_error"></p>
                        </div>
                        <div class="w-full flex flex-col">
                            <label for="email">Email address</label>
                            <input type="text" id="edit_email" name="email" onblur="validateForm(this, 'edit_email_error', 'Email address')" class="input" placeholder="Email address" readonly>
                            <p class="error-message text-sm text-red hidden" id="edit_email_error"></p>
                        </div>
                    </div>
                    <div class="flex md:flex-row flex-col gap-5">
                        <div class="w-full flex flex-col">
                            <label for="birth_date">Birthdate</label>
                            <input type="date" id="edit_birth_date" name="birth_date" onblur="validateForm(this, 'edit_birth_date_error', 'Birthdate')" class="input" placeholder="Birthdate" readonly>
                            <p class="error-message text-sm text-red hidden" id="edit_birth_date_error"></p>
                        </div>
                        <div class="w-full flex flex-col">
                            <label for="gender">Gender</label>
                            <input type="text" id="edit_gender" name="gender" onblur="validateForm(this, 'edit_gender_error', 'Gender')" class="input" placeholder="Gender" readonly>

                            <p id="edit_gender_error" class="error-message text-sm text-red hidden"></p>
                        </div>
                    </div>
                    <div>
                        <p class="text-lg">Tooth Extraction History</p>
                        <div class="" id="tooth-container">
                        </div>
                        <div id="table-container"></div>
                    </div>
                    <div class="flex justify-end items-center gap-3">
                        <div class="px-6 py-2 text-white bg-red rounded-2xl cursor-pointer hover:bg-red/80" onclick="closeEditModal()">Close</div>
                        <!-- <button id="edit_submit_button" type="submit" class="px-6 py-2 text-white bg-blue rounded-2xl hover:bg-blue/80">Save</button> -->
                    </div>
                </form>
            </fieldset>

        </div>
    </div>

<?php
    return ob_get_clean();
}
?>