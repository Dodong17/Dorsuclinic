<?php
function Modals()
{
    ob_start();
?>
    <div id="change_password_modal" class="modal" style="display: none;">
        <div class="w-[90%] md:w-[30%] max-h-[80vh] bg-white rounded-2xl p-5 overflow-y-scroll">
            <h1 class="font-bold text-2xl mb-3">Change Password</h1>
            <fieldset id="password_fieldset">
                <form class="space-y-5" onsubmit="handleSubmit(event)">
                    <div class="flex flex-col gap-5">
                    <div class="w-full flex flex-col">
                            <label for="password">Current password</label>
                            <input type="password" id="current_password" name="current_password" onblur="validateForm(this, 'current_password_error', 'Current password')" class="input" placeholder="Current password" required>
                            <p class="error-message text-sm text-red hidden" id="current_password_error"></p>
                        </div>
                        <div class="w-full flex flex-col">
                            <label for="password">New password</label>
                            <input type="password" id="password" name="password" onblur="validateForm(this, 'password_error', 'Password')" class="input" placeholder="New password" required>
                            <p class="error-message text-sm text-red hidden" id="password_error"></p>
                        </div>
                        <div class="w-full flex flex-col">
                            <label for="confirm_password">Confirm password</label>
                            <input type="password" id="confirm_password" name="confirm_password" oninput="validatePassword(this, 'password', 'confirm_password_error')" class="input" placeholder="Confirm password" required>
                            <p class="error-message text-sm text-red hidden" id="confirm_password_error"></p>
                        </div>
                    </div>
                    <div class="flex justify-end items-center gap-3">
                        <div class="px-6 py-2 text-white bg-red rounded-2xl cursor-pointer hover:bg-red/80" onclick="closeChangePasswordModal()">Cancel</div>
                        <button id="change_password_button" type="submit" class="px-6 py-2 text-white bg-blue rounded-2xl hover:bg-blue/80">Change</button>
                    </div>
                </form>
            </fieldset>

        </div>
    </div>



<?php
    return ob_get_clean();
}
?>