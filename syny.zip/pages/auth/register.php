<?php
include 'config/database.php';

?>

<div class="h-screen w-screen bg-white  ">
    <div class="absolute top-0 left-0 w-full h-full flex justify-center items-center lg:px-40 z-10">

        <div class="w-full flex flex-col  lg:flex-row  h-full lg:h-[85vh] text-white  shadow-2xl rounded-3xl overflow-hidden overflow-y-scroll">
            <div class="w-full lg:w-1/3 bg-blue order-2  h-full flex-col flex justify-center items-center px-10 p-5  gap-4">
                <div class="relative h-[150px] w-[150px] rounded-full bg-[#fff] flex justify-center items-center">
                    <img src="./assets/image/school_logo.png" alt="Davao Oriental State University Logo" loading="lazy" class="h-full w-full object-fill" />
                </div>
                <h1 class="text-3xl text-center font-bold">Clinic Management System</h1>
                <p class="text-center text-sm">The Clinic Management System at Davao Oriental State University is here to make healthcare services more accessible and efficient for students and staff. It keeps track of patient records, treatment history, and appointments, so everything runs smoothly and care feels seamless. By simplifying processes, the system helps the clinic focus more on what really matters—taking care of people.!</p>
            </div>
            <div class="w-full lg:w-2/3 bg-white order-1  h-auto  text-blue flex justify-center items-center py-5 px-5 lg:px-20 ">
                <div class=" h-[80%] w-full p-10 lg:px-20 flex flex-col justify-center gap-5 py-5">
                    <h1 class="text-center font-bold text-4xl">Create an Account</h1>
                    <fieldset id="form_fieldset">
                        <form class="" autocomplete="off" onsubmit="handleSubmit(event)">
                            <div class="flex lg:flex-row flex-col gap-3">
                                <div class="w-full flex flex-col gap-1 mb-3 ">
                                    <label for="first_name" class="text-base">First name</label>
                                    <input oninput="checkNumberOnName(this)" onblur="validateForm(this, 'first_name_error', 'First name')" type="text" id="first_name" name="first_name" placeholder="First name" class="input" required>
                                    <p id="first_name_error" class="error-message text-sm text-red hidden"></p>
                                </div>
                                <div class="w-full flex flex-col gap-1 mb-3 ">
                                    <label for="last_name" class="text-base">Last name</label>
                                    <input type="text" oninput="checkNumberOnName(this)" onblur="validateForm(this, 'last_name_error', 'Last name')" id="last_name" name="last_name" placeholder="Last name" class="input" required>
                                    <p id="last_name_error" class="error-message text-sm text-red hidden"></p>
                                </div>
                            </div>

                            <div class="flex lg:flex-row flex-col gap-3">

                                <div class="w-full flex flex-col gap-1 mb-3 ">
                                    <label for="contact" class="text-base">Contact number</label>
                                    <input type="text" id="contact" onblur="validateForm(this, 'contact_error', 'Contact number')" name="contact" placeholder="Contact number" class="input" required>
                                    <p id="contact_error" class="error-message text-sm text-red hidden"></p>
                                </div>

                                <div class="w-full flex flex-col gap-1 mb-3 ">
                                    <label for="email" class="text-base">Email address</label>
                                    <input type="text" id="email" onblur="validateForm(this, 'email_error', 'Email address')" name="email" placeholder="Email address" class="input" required>
                                    <p id="email_error" class="error-message text-sm text-red hidden"></p>
                                </div>
                            </div>

                            <div class="flex lg:flex-row flex-col gap-3">
                                <div class="w-full flex flex-col gap-1 mb-3 ">
                                    <label for="birth_date" class="text-base">Birth date</label>
                                    <input type="date" id="birth_date" onblur="validateForm(this, 'birth_date_error', 'Birth date')" name="birth_date" placeholder="Birth date" class="input" required>
                                    <p id="birth_date_error" class="error-message text-sm text-red hidden"></p>
                                </div>
                                <div class="w-full flex flex-col gap-1 mb-3 ">
                                    <label for="gender" class="text-base">Gender</label>
                                    <select name="gender" id="gender" onblur="validateForm(this, 'gender_error', 'Gender')" class="input" required>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                    </select>
                                    <p id="gender_error" class="error-message text-sm text-red hidden"></p>
                                </div>
                            </div>

                            <div class="flex lg:flex-row flex-col gap-3">
                                <div class="w-full flex flex-col gap-1 mb-3 ">
                                    <label for="user_type" class="text-base">User type</label>
                                    <select name="user_type" onblur="validateForm(this, 'user_type_error', 'User type')" id="user_type" class="input" required>
                                        <option value="faculty">Faculty</option>
                                        <option value="staff">Staff</option>
                                        <option value="student">Student</option>

                                    </select>
                                    <p id="user_type_error" class="error-message text-sm text-red hidden"></p>
                                </div>
                                <div class="w-full flex flex-col gap-1 mb-3 ">
                                    <label for="id_number" class="text-base">ID Number</label>
                                    <input type="text" onblur="validateForm(this, 'id_number_error', 'ID Number')" id="id_number" name="id_number" placeholder="ID Number" class="input" required>
                                    <p id="id_number_error" class="error-message text-sm text-red hidden"></p>

                                </div>
                            </div>

                            <div class="flex lg:flex-row flex-col gap-3">
                                <div class="w-full flex flex-col gap-1 mb-3 ">
                                    <label for="password" class="text-base">Password</label>
                                    <input type="password" onblur="validateForm(this, 'password_error', 'Password')" id="password" name="password" placeholder="Password" class="input" required>
                                    <p id="password_error" class="error-message text-sm text-red hidden"></p>
                                </div>
                                <div class="w-full flex flex-col gap-1 mb-3 ">
                                    <label for="confirm_password" class="text-base">Confirm password</label>
                                    <input type="password" id="confirm_password" oninput="validatePassword(this, 'password', 'confirm_password_error')" name="confirm_password" placeholder="Confirm password" class="input" required>
                                    <p id="confirm_password_error" class="error-message text-sm text-red hidden"></p>
                                </div>
                            </div>





                            <div class="flex justify-center items-center">
                                <button id="submit_button" type="submit" class="bg-blue text-white px-8 py-2 text-lg rounded-2xl mt-4 text-center transition-all duration-300 hover:brightness-110">Create account</button>

                            </div>

                        </form>
                    </fieldset>

                    <div class="flex flex-col gap-5 mt-2 items-center justify-center">
                        <a href="/<?php echo $directoryName; ?>" class="text-sm">Already have an account? Click here</a>


                    </div>

                </div>
            </div>
        </div>

    </div>

    <div class="absolute bottom-0 left-0 w-full ">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill="#003399" fill-opacity="1" d="M0,288L180,192L360,320L540,32L720,64L900,32L1080,192L1260,160L1440,0L1440,320L1260,320L1080,320L900,320L720,320L540,320L360,320L180,320L0,320Z"></path>
        </svg>
        <div class="bg-blue h-[30vh] w-full"></div>
    </div>


</div>
</div>


<script>
    let isValid = false;
    let isValidateForm = false;

    const handleSubmit = async (event) => {
        var notyf = new Notyf();
        event.preventDefault();

        if (!isValid || !isValidateForm) {
            console.log("not valid");
            return;

        }

        document.getElementById("submit_button").innerHTML = "Creating...";
        const form = event.target;
        const formData = new FormData(form);
        formData.append("role", "user");
        document.getElementById("form_fieldset").disabled = true;



        const dataObject = Object.fromEntries(formData.entries());



        try {
            const response = await axios.post(`/<?php echo $directoryName; ?>/api/users.php`, dataObject, {
                header: {
                    "Content-Type": "application/json"
                }
            });
            if (response.data.status === "failed") {

                const element = document.getElementById(`${response.data.error}_error`);
                element.classList.remove("hidden");
                element.innerHTML = response.data.message;
                notyf.error(response.data.message);
                document.getElementById("submit_button").innerHTML = "Create account";

            } else if (response.data.status === "success") {
                form.reset();
                const errorElements = form.querySelectorAll('.error-message');
                errorElements.forEach((element) => {
                    element.classList.add("hidden");
                    element.innerHTML = "";
                });
                notyf.success('Created successfully.');
                const submitButton = document.getElementById("submit_button");
                submitButton.innerHTML = "Created successfully";
                submitButton.disabled = true;
                window.location.href = "./";

                // Start a 3-second countdown
                setTimeout(() => {
                    submitButton.innerHTML = "Create account";
                    submitButton.disabled = false;
                }, 3000); // 3000 milliseconds = 3 seconds

            }


        } catch (error) {
            console.log(error);
            notyf.error(error);
        } finally {
            document.getElementById("form_fieldset").disabled = false;
        }
    }


    function validatePassword(input, passwordId, errorId) {
        const password = document.getElementById(passwordId).value;
        const confirmPassword = input.value;

        if (password !== confirmPassword) {
            const errorElement = document.getElementById(errorId);
            errorElement.classList.remove("hidden");
            errorElement.innerHTML = "Password and confirm password do not match";
            isValid = false;
            return false;
        } else {
            const errorElement = document.getElementById(errorId);
            errorElement.classList.add("hidden");
            errorElement.innerHTML = "";
            isValid = true;

            return true;
        }
    }

    function checkNumberOnName(input) {
        // Replace all numeric characters with an empty string
        input.value = input.value.replace(/\d/g, '');
    }

    function validateForm(input, errorId, fieldName) {
        const errorElement = document.getElementById(errorId);

        // If input is empty
        if (input.value === "") {
            errorElement.classList.remove("hidden");
            errorElement.innerHTML = `${fieldName} is required.`;
            isValidateForm = false;
            return false;

        }

        // Additional validation for password field
        if (input.name === "password") {
            // Regex for password validation
            const passwordRegex =
                /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

            if (!passwordRegex.test(input.value)) {
                errorElement.classList.remove("hidden");
                errorElement.innerHTML =
                    `${fieldName} must have at least 8 characters, including one uppercase letter, one lowercase letter, one number, and one special character.`;
                isValidateForm = false;
                return false;
            }
        }

        if (input.name === "contact") {
            // Regex for contact validation: starts with 9 and has exactly 10 digits
            const contactRegex = /^9\d{9}$/;

            if (!contactRegex.test(input.value)) {
                errorElement.classList.remove("hidden");
                errorElement.innerHTML = `${fieldName} must start with 9 and have exactly 10 digits.`;
                isValidateForm = false;
                return false;
            }
        }

        if (input.name === "id_number") {
            const userType = document.getElementById("user_type").value; // Get selected user type

            let idRegex;
            if (userType === "student") {
                idRegex = /^\d{4}-\d{4}$/; // Format: XXXX-XXXX
            } else if (userType === "faculty" || userType === "staff") {
                idRegex = /^\d{6}-\d{3}$/; // Format: XXXXXX-XXX
            }

            if (!idRegex.test(input.value)) {
                errorElement.classList.remove("hidden");
                errorElement.innerHTML = `${fieldName} must follow the format ${
                userType === "student" ? "1234-1234" : "123456-123"
            }.`;
                isValidateForm = false;
                return false;
            }
        }

        // If no errors, hide the error message
        errorElement.classList.add("hidden");
        errorElement.innerHTML = "";
        isValidateForm = true;
        return true; // Validation passed
    }


    window.onload = document.getElementById("loading-screen").style.display = "none";
</script>