<?php
include 'config/database.php';

?>

<div class="h-screen w-screen bg-white  ">
    <div class="absolute top-0 left-0 w-full h-full flex justify-center items-center lg:px-40 z-10">

        <div class="w-full flex flex-col lg:flex-row  h-full lg:h-[80vh] text-white  shadow-2xl rounded-3xl overflow-hidden overflow-y-scroll">
            <div class="w-full lg:w-1/3 bg-blue order-2 lg:order-1 h-full flex-col flex justify-center items-center px-10 p-5 gap-4">
                <div class="relative h-[150px] w-[150px] rounded-full bg-[#fff] flex justify-center items-center">
                    <img src="./assets/image/school_logo.png" alt="Davao Oriental State University Logo" loading="lazy" class="h-full w-full object-fill" />
                </div>
                <h1 class="text-3xl text-center font-bold">Clinic Management System</h1>
                <p class="text-center text-sm">The Clinic Management System at Davao Oriental State University is here to make healthcare services more accessible and efficient for students and staff. It keeps track of patient records, treatment history, and appointments, so everything runs smoothly and care feels seamless. By simplifying processes, the system helps the clinic focus more on what really matters—taking care of people!></p>
            </div>
            <div class="w-full lg:w-2/3 bg-white order-1 lg:order-2 h-full  text-blue flex justify-center items-center px-5 lg:px-20 ">
                <div class=" h-[80%] w-[80%] p-10 lg:px-20 flex flex-col justify-center gap-5">
                    <h1 class="text-center font-bold text-4xl mb-4">Log In with Your Account</h1>
                    <form autocomplete="off" onsubmit="handleSubmit(event)">

                        <div class="flex flex-col gap-1 mb-3 ">
                            <label for="id_number" class="text-base">ID Number</label>
                            <input type="text" id="id_number" name="id_number" placeholder="ID Number" class="input" required>
                            <p class="text-red hidden error-message" id="id_number_error">ID number not found.</p>
                        </div>

                        <div class="flex flex-col gap-1 mb-3">
                            <label for="password" class="text-base">Password</label>
                            <input type="password" id="password" name="password" placeholder="Password" class="input" required>
                            <p class="text-red hidden error-message" id="password_error">Invalid password.</p>
                        </div>
                        <div class="flex justify-center items-center">
                            <button type="submit" class="bg-blue text-white px-8 py-2 text-lg rounded-2xl mt-4 text-center transition-all duration-300 hover:brightness-110">Login</button>
                        </div>

                    </form>

                    <div class="flex flex-col gap-5 mt-4 items-center justify-center">
                        <a href="register" class="">Don't have an account? Click here</a>
                        <a href="#" class="text-sm">Forgot password?</a>

                    </div>

                </div>
            </div>
        </div>

    </div>

    <div class="absolute bottom-0 left-0 w-full ">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill="#003399" fill-opacity="1" d="M0,288L180,192L360,320L540,32L720,64L900,32L1080,192L1260,160L1440,0L1440,320L1260,320L1080,320L900,320L720,320L540,320L360,320L180,320L0,320Z"></path>
        </svg>
        <div class="bg-blue h-[30vh] w-full"></div>
    </div>


</div>
</div>


<script>
    const handleSubmit = async (event) => {

        event.preventDefault();

        const form = event.target;
        const errorElements = form.querySelectorAll('.error-message');
        errorElements.forEach((element) => {
            element.classList.add("hidden");
            element.innerHTML = "";
        });
        const formData = new FormData(form);

        const dataObject = Object.fromEntries(formData.entries());

        try {
            const response = await axios.post(`/<?php echo $directoryName; ?>/api/login.php`, dataObject, {
                header: {
                    "Content-Type": "application/json"
                }
            });
            if (response.data.status === "failed") {
                const element = document.getElementById(`${response.data.error}_error`);
                element.classList.remove("hidden");
                element.innerHTML = response.data.message;
            } else if (response.data.status === "success") {
                localStorage.setItem("full_name", response.data.first_name + " " + response.data.last_name);
                localStorage.setItem("id", response.data.id);
                localStorage.setItem("token", response.data.token);
                localStorage.setItem("role", response.data.user_type);
                if (response.data.role === "admin") {
                    window.location.href = "/<?php echo $directoryName ?>/admin/dashboard";
                } else if (response.data.role === "doctor") {
                    window.location.href = "/<?php echo $directoryName ?>/doctor/dashboard";
                } else if (response.data.role === "user") {
                    window.location.href = "/<?php echo $directoryName ?>/user/dashboard";
                } else {
                    window.location.href = "/<?php echo $directoryName ?>/";
                    localStorage.removeItem("token");
                    localStorage.removeItem("id");
                    localStorage.removeItem("role");
                }
                // console.log(response.data.token);
            }
        } catch (error) {
            console.log(error);
        }

    }

    const checkToken = async () => {
        document.getElementById("loading-screen").style.display = "flex";
        const token = localStorage.getItem("token");
        if (token) {
            try {
                const response = await axios.post(`/<?php echo $directoryName; ?>/api/VerifyToken.php`, {}, {
                    headers: {
                        "Authorization": "Bearer " + localStorage.getItem("token")
                    }
                });


                if (response.data.status === "success") {
                    const user = response.data.data.data;
                    
                    if (user.role === "admin") {
                        window.location.href = "/<?php echo $directoryName ?>/admin/dashboard";
                        return;
                    } else if (user.role === "doctor") {
                        window.location.href = "/<?php echo $directoryName ?>/doctor/dashboard";
                        return;

                    } else if (user.role === "user") {
                        window.location.href = "/<?php echo $directoryName ?>/user/dashboard";
                        return;

                    } else {
                        window.location.href = "/<?php echo $directoryName ?>/";
                        
                        localStorage.removeItem("token");
                        localStorage.removeItem("id");
                        localStorage.removeItem("role");
                    }
                } else {
                    window.location.href = "/<?php echo $directoryName; ?>/";
                    localStorage.removeItem("token");
                    localStorage.removeItem("id");
                    localStorage.removeItem("role");
                }
            } catch (error) {
                localStorage.removeItem("token");
                localStorage.removeItem("id");
                localStorage.removeItem("role");
                window.location.href = "/<?php echo $directoryName; ?>/";
            }
        }
        document.getElementById("loading-screen").style.display = "none";

    }


    window.onload = checkToken;
</script>