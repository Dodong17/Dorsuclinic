<?php
include 'layout/MainLayout.php';


// echo $hostName;

// Get the project root directory and directory name
$projectRoot = dirname(__FILE__, 1);
$directoryName = basename($projectRoot);

// Get the requested URL and sanitize it
$requestUri = trim($_SERVER['REQUEST_URI'], '/');

$requestUri = preg_replace('#^' . preg_quote($directoryName, '#') . '#', '', $requestUri);
$requestUri = trim($requestUri, '/');


// Set the path to the pages directory
$pagesDir = 'pages/';

// Define the route mappings
$routes = [


    //testing
    'test' => 'sidebar.php',

    '' => 'auth/login.php', // root
    'login' => 'auth/login.php',
    'register' => 'auth/register.php',
    // Admin pages
    'admin/dashboard' => 'admin/dashboard.php',
    'admin/doctors' => 'admin/doctors.php',
    'admin/patients' => 'admin/patients.php',
    'admin/services' => 'admin/services.php',
    'admin/appointments' => 'admin/appointments.php',
    'admin/prescriptions' => 'admin/prescriptions.php',
    'admin/reports' => 'admin/reports.php',
    'admin/messages' => 'admin/messages.php',


    




    // Doctor pages
    'doctor/dashboard' => 'doctor/dashboard.php',
    'doctor/patients' => 'doctor/patients.php',
    'doctor/appointments' => 'doctor/appointments.php',
    'doctor/prescriptions' => 'doctor/prescriptions.php',
    'doctor/messages' => 'doctor/messages.php',






    // User pages
    'user/dashboard' => 'user/dashboard.php',
    'user/my-bookings' => 'user/my-booking.php',

];



// Determine the content file based on the request URI
$contentFile = isset($routes[$requestUri])
    ? $pagesDir . $routes[$requestUri]
    : $pagesDir . '404.php';

// Check if the content file exists, otherwise load 404
if (!file_exists($contentFile)) {
    $contentFile = $pagesDir . '404.php';
}

// Render the layout with the selected content file

MainLayout($contentFile, $directoryName);



?>

