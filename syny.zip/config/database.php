<?php

$projectRoot = dirname(__FILE__, 2);
$directoryName = basename($projectRoot);


date_default_timezone_set('Asia/Manila');


$current_date_time = date('Y-m-d H:i:s');

$host = 'localhost';
$db   = 'syny_db'; 
$user = 'root';     
$pass = '';        
$charset = 'utf8mb4'; 

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => true,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
    // echo "Connected to MySQL database successfully.";
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}


?>
