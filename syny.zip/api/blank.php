<?php 
require_once '../config/database.php'; // Ensure PDO connection is established

// Set header for JSON response
header('Content-Type: application/json');






const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        // $users = getAllUsers($pdo, $input);
        // http_response_code(HTTP_OK);
        // echo json_encode($users);
        break;

    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}

?>