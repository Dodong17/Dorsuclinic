<?php

// fetchMessages.php
require_once '../config/database.php';
header('Content-Type: application/json');

$conversationId = $_GET['conversation_id']; // Get conversation ID
$stmt = $pdo->prepare("SELECT m.message, m.created_at, m.sender_id, u.first_name 
                       FROM messages m 
                       JOIN users u ON m.sender_id = u.id 
                       WHERE m.conversation_id = :conversationId 
                       ORDER BY m.created_at ASC");
$stmt->execute(['conversationId' => $conversationId]);
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Optionally, format the timestamps to a more readable format if needed
foreach ($messages as &$message) {
    $message['created_at'] = date('Y-m-d H:i:s', strtotime($message['created_at'])); // Format timestamp
}

echo json_encode($messages);
