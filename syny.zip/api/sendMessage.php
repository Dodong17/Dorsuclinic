<?php 

// sendMessage.php
require_once '../config/database.php';
header('Content-Type: application/json');

$requestMethod = $_SERVER['REQUEST_METHOD'];

if ($requestMethod === 'POST') {
    $input = json_decode(file_get_contents("php://input"), true);
    $conversationId = $input['conversationId'];
    $senderId = $input['senderId'];
    $message = $input['message'];

    $stmt = $pdo->prepare("INSERT INTO messages (conversation_id, sender_id, message) VALUES (:conversation_id, :sender_id, :message)");
    $stmt->execute(['conversation_id' => $conversationId, 'sender_id' => $senderId, 'message' => $message]);

    http_response_code(201);
    echo json_encode(['message' => 'Message sent successfully']);
} else {
    http_response_code(405);
    echo json_encode(['message' => 'Method not allowed']);
}


?>