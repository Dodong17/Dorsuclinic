<?php
require_once '../config/database.php'; // Ensure PDO connection is established

// Set header for JSON response
header('Content-Type: application/json');



function getSlots($pdo, $date)
{
    $sql = "SELECT * FROM appointment_schedule WHERE date = :date";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['date' => $date]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'GET':
        parse_str($_SERVER['QUERY_STRING'], $queryParams);
        $date = $queryParams['date'] ?? null;
        if ($date) {
            $slots = getSlots($pdo, $date);
            http_response_code(HTTP_OK);
            echo json_encode($slots);
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'Invalid input']);
        }

        break;

    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}
