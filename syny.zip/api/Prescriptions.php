<?php
require_once '../config/database.php'; // Ensure PDO connection is established

// Set header for JSON response
header('Content-Type: application/json');

function getPrescription($pdo, $page = 1, $limit = 10, $query = "")
{
    // Calculate the offset based on the page number and limit
    $offset = ($page - 1) * $limit;

    // Prepare the SQL query
    $sql = "
        SELECT prescriptions.*, 
               CONCAT(users.first_name, ' ', users.last_name) AS user_name,
               CONCAT(doctors.first_name, ' ', doctors.last_name) AS doctor_name
        FROM prescriptions
        LEFT JOIN users ON prescriptions.user_id = users.id
        LEFT JOIN users AS doctors ON prescriptions.doctor_id = doctors.id
        WHERE prescriptions.medicine LIKE :query OR prescriptions.notes LIKE :query
        LIMIT :limit OFFSET :offset
    ";

    $stmt = $pdo->prepare($sql);

    // Prepare the query parameter for LIKE search
    $likeQuery = '%' . $query . '%';

    // Bind the parameters
    $stmt->bindValue(':query', $likeQuery, PDO::PARAM_STR);
    $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);

    // Execute the query
    $stmt->execute();

    // Fetch all the matching prescriptions
    $prescriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Query to count the total number of matching prescriptions
    $countSql = "
        SELECT COUNT(*) as total 
        FROM prescriptions
        WHERE medicine LIKE :query OR notes LIKE :query
    ";

    $countStmt = $pdo->prepare($countSql);

    // Bind the parameter for the count query
    $countStmt->bindValue(':query', $likeQuery, PDO::PARAM_STR);
    $countStmt->execute();

    // Fetch the total count
    $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];

    // Return the prescriptions and the total count
    return [
        'prescriptions' => $prescriptions,
        'total' => $total
    ];
}


function createPrescription($pdo, $input)
{
    try {
        // Begin transaction
        $pdo->beginTransaction();

        // Insert into prescriptions table
        $sql = "INSERT INTO prescriptions (booking_id, user_id, doctor_id, medicine, notes) VALUES (:booking_id, :user_id, :doctor_id, :medicine, :notes)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':booking_id' => $input['booking_id'],
            ':user_id' => $input['user_id'],
            ':doctor_id' => $input['doctor_id'],
            ':medicine' => $input['medicine'],
            ':notes' => $input['notes']
        ]);

        // Check if the prescription was created successfully
        if ($stmt->rowCount() === 0) {
            // Rollback if insertion failed
            $pdo->rollBack();
            return [
                "status" => "failed",
                "message" => "Failed to create prescription."
            ];
        }

        // Update booking status to 'completed'
        $updateSql = "UPDATE bookings SET status = 'completed' WHERE id = :booking_id";
        $updateStmt = $pdo->prepare($updateSql);
        $updateStmt->execute([':booking_id' => $input['booking_id']]);

        // Check if the booking status was updated
        if ($updateStmt->rowCount() === 0) {
            // Rollback if update failed
            $pdo->rollBack();
            return [
                "status" => "failed",
                "message" => "Failed to update booking status."
            ];
        }

        // Commit transaction
        $pdo->commit();
        return [
            "status" => "success",
            "message" => "Prescription created and booking status updated to completed."
        ];
    } catch (Exception $e) {
        // Rollback on error
        $pdo->rollBack();
        return [
            "status" => "failed",
            "message" => "An error occurred: " . $e->getMessage()
        ];
    }
}



const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'GET':
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
        $query = isset($_GET['query']) ? $_GET['query'] : ""; // Get query from request

        $data = getPrescription($pdo, $page, $limit, $query); // Pass the query parameter
        http_response_code(HTTP_OK);
        echo json_encode($data);
        break;
        break;
    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        $response = createPrescription($pdo, $input);
        http_response_code(HTTP_OK);
        echo json_encode($response);
        break;

    

    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}
