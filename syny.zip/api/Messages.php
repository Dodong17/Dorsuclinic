<?php 
require_once '../config/database.php';

header('Content-Type: application/json');

const HTTP_OK = 200;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'GET':
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        $search = isset($_GET['search']) ? $_GET['search'] : null;

        $users = getUsers($pdo, $id, $search);
        http_response_code(HTTP_OK);
        echo json_encode($users);
        break;

    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}

function getUsers($pdo, $id, $search) {
    
    $sql = "
        SELECT 
            u.id, u.first_name, u.last_name, 
            COUNT(m.id) AS unread_count
        FROM users u
        LEFT JOIN conversations c ON (c.user1_id = u.id OR c.user2_id = u.id)
        LEFT JOIN messages m ON m.conversation_id = c.id AND m.status = 'unread' 
        WHERE u.role IN ('admin', 'doctor') 
        AND (:id IS NULL OR u.id != :id)
        AND (:search IS NULL OR u.first_name LIKE :search OR u.last_name LIKE :search)
        GROUP BY u.id
    ";

    $stmt = $pdo->prepare($sql);

    if ($id !== null) {
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    }

    if ($search !== null) {
        $likeSearch = "%" . $search . "%";
        $stmt->bindParam(':search', $likeSearch, PDO::PARAM_STR);
    }

    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

?>
