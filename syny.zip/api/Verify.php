<?php
require_once '../config/database.php'; // Ensure PDO connection is established

// Set header for JSON response
header('Content-Type: application/json');






const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

function verify($pdo, $id)
{
    $sql = "SELECT * FROM users WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        return ["message" => "User not found.", "status" => "failed", "error" => "id"];
    }

    if ($user['verified_at']) {
        return ["message" => "User already verified.", "status" => "failed", "error" => "id"];
    }

    $sql = "UPDATE users SET verified_at = NOW() WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $id]);
    return ["message" => "User verified successfully.", "status" => "success", "error" => "id"];
}

switch ($requestMethod) {
    case 'GET':
        // Call the verify function and pass the ID from the query parameter
        $response = verify($pdo, $_GET['id']);

        // If the verification is successful, redirect to the root directory
        if ($response['status']) { // Adjust based on your verification function's return structure
            header("Location: /syny/"); // Redirect to the root directory
            exit; // Always call exit() after a header redirect
        }

        // If verification fails, send an error response
        http_response_code(HTTP_OK); // Adjust HTTP status as needed
        echo json_encode($response);
        break;


    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}
