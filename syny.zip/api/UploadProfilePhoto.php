<?php
require_once '../config/database.php'; // Ensure PDO connection is established

// Set header for JSON response
header('Content-Type: application/json');


function getProfilePhoto($pdo, $id)
{
    try {
        $stmt = $pdo->prepare("SELECT profile_photo FROM users WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (\Throwable $th) {
        return ["status" => "error", "message" => "An error occurred: " . $th->getMessage()];
    }
}

function updateProfilePhoto($pdo, $input)
{
    try {
        // Validate input
        if (empty($input['profile_photo']) || empty($input['id'])) {
            throw new Exception("Missing required fields.");
        }

        
        $pdo->beginTransaction();
        $sql = "UPDATE users SET profile_photo = :profile_photo WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':profile_photo' => $input['profile_photo'],
            ':id' => $input['id']
        ]);
        $pdo->commit();
        return [
            "status" => "success",
            "message" => "Profile photo updated successfully"
        ];
    } catch (Exception $e) {
        $pdo->rollBack();
        return [
            "status" => "failed",
            "message" => "An error occurred: " . $e->getMessage()
        ];
    }
}


const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'GET':
        $id = $_GET['id'];
        $profile_photo = getProfilePhoto($pdo, $id);
        http_response_code(HTTP_OK);
        echo json_encode($profile_photo);
        break;
    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        $response = updateProfilePhoto($pdo, $input);
        if ($response) {
            http_response_code(HTTP_OK);
            echo json_encode($response);
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'Invalid input']);
        }
        break;
        // $users = getAllUsers($pdo, $input);
        // http_response_code(HTTP_OK);
        // echo json_encode($users);


    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}
