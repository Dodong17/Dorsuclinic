<?php
require_once '../config/database.php'; // Ensure PDO connection is established

// Set header for JSON response
header('Content-Type: application/json');

function addService($pdo, $input)
{
    [
        "service_name" => $service_name,
        "available_to" => $available_to,
        "schedule_date" => $schedule_date,
        "morning_slot" => $morning_slot,
        "afternoon_slot" => $afternoon_slot
    ] = $input;

    try {
        // Begin a transaction
        $pdo->beginTransaction();

        // Check if the service name already exists
        $checkServiceSql = "SELECT COUNT(*) as count FROM services WHERE service_name = :service_name";
        $checkServiceStmt = $pdo->prepare($checkServiceSql);
        $checkServiceStmt->execute(['service_name' => $service_name]);
        $result = $checkServiceStmt->fetch(PDO::FETCH_ASSOC);

        if ($result['count'] > 0) {
            $pdo->rollBack();
            return [
                "status" => "failed",
                "message" => "Service name already exists."
            ];
        }

        // Insert into the services table
        $insertServiceSql = "INSERT INTO services (service_name, available_to) VALUES (:service_name, :available_to)";
        $insertServiceStmt = $pdo->prepare($insertServiceSql);
        $insertServiceStmt->execute([
            'service_name' => $service_name,
            'available_to' => $available_to
        ]);

        // Get the last inserted service ID
        $serviceId = $pdo->lastInsertId();

        $insertScheduleSql = "INSERT INTO appointment_schedule (date, morning_slot, afternoon_slot) VALUES (:date, :morning_slot, :afternoon_slot)";
        $insertScheduleStmt = $pdo->prepare($insertScheduleSql);
        $insertScheduleStmt->execute([
            'date' => $schedule_date,
            'morning_slot' => $morning_slot,
            'afternoon_slot' => $afternoon_slot
        ]);
        

        // Commit the transaction
        $pdo->commit();

        return [
            "status" => "success",
            "message" => "Service and schedule added successfully."
        ];
    } catch (Exception $e) {
        // Rollback the transaction in case of an error
        $pdo->rollBack();
        return [
            "status" => "failed",
            "message" => "An error occurred: " . $e->getMessage()
        ];
    }
}


function updateService($pdo, $input)
{
    [
        "service_id" => $service_id,
        "service_name" => $service_name,
        "available_to" => $available_to
    ] = $input;

    // Validate the input
    if (empty($service_id) || empty($service_name) || empty($available_to)) {
        return [
            "status" => "failed",
            "message" => "Invalid input. All fields are required."
        ];
    }

    // Check if the service exists
    $checkServiceSql = "SELECT COUNT(*) as count FROM services WHERE id = :id";
    $checkServiceStmt = $pdo->prepare($checkServiceSql);
    $checkServiceStmt->execute(['id' => $service_id]);
    $result = $checkServiceStmt->fetch(PDO::FETCH_ASSOC);

    if ($result['count'] === 0) {
        return [
            "status" => "failed",
            "message" => "Service not found."
        ];
    }

    // Update the service details
    $updateSql = "UPDATE services 
                  SET service_name = :service_name, available_to = :available_to 
                  WHERE id = :id";
    $updateStmt = $pdo->prepare($updateSql);
    $updateStmt->execute([
        'service_name' => $service_name,
        'available_to' => $available_to,
        'id' => $service_id
    ]);

    return [
        "status" => "success",
        "message" => "Service updated successfully."
    ];
}


function deleteService($pdo, $id)
{
    // Check if the service exists
    $checkServiceSql = "SELECT COUNT(*) as count FROM services WHERE id = :id";
    $checkServiceStmt = $pdo->prepare($checkServiceSql);
    $checkServiceStmt->execute(['id' => $id]);
    $result = $checkServiceStmt->fetch(PDO::FETCH_ASSOC);

    if ($result['count'] === 0) {
        return [
            "status" => "failed",
            "message" => "Service not found."
        ];
    }

    // Delete the service
    $deleteSql = "DELETE FROM services WHERE id = :id";
    $deleteStmt = $pdo->prepare($deleteSql);
    $deleteStmt->execute(['id' => $id]);

    return [
        "status" => "success",
        "message" => "Service deleted successfully."
    ];
}


function getServices($pdo, $page, $limit, $query)
{
    $offset = ($page - 1) * $limit;
    $sql = "SELECT * FROM services WHERE service_name LIKE :query ORDER BY service_name ASC LIMIT :offset, :limit";
    $stmt = $pdo->prepare($sql);

    // Bind the query parameter as a value
    $stmt->bindValue(':query', '%' . $query . '%', PDO::PARAM_STR);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);

    // Execute the query
    $stmt->execute();
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return ['services' => $services, 'total' => count($services)];
}

// const updateService = async ($pdo, $input) => {
//     [
//         "service_id" => $service_id,
//         "service_name" => $service_name,
//         "available_to" => $available_to
//     ] = $input;
//     $available_to = explode(",", $available_to);
//     $available_to = array_filter($available_to);
//     $available_to = implode(",", $available_to);
//     // Check if the service name already exists




const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        $response = addService($pdo, $input);
        if ($response) {
            http_response_code(HTTP_CREATED);
            echo json_encode($response);
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'Invalid input']);
        }
        break;
    case 'GET':
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
        $query = isset($_GET['query']) ? $_GET['query'] : ""; // Get query from request
        $response = getServices($pdo, $page, $limit, $query);
        http_response_code(HTTP_OK);
        echo json_encode($response);
        break;
    case 'DELETE':
        $input = json_decode(file_get_contents("php://input"), true);
        if (isset($input['id'])) {
            $response = deleteService($pdo, $input['id']);
            if ($response['status'] === 'success') {
                http_response_code(HTTP_NO_CONTENT);
                echo json_encode($response);
            } else {
                http_response_code(HTTP_NOT_FOUND);
                echo json_encode($response);
            }
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'Invalid input']);
        }
        break;
    case 'PUT':
        $input = json_decode(file_get_contents("php://input"), true);
        $response = updateService($pdo, $input);
        if ($response['status'] === 'success') {
            http_response_code(HTTP_OK);
            echo json_encode($response);
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode($response);
        }
        break;

    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}
