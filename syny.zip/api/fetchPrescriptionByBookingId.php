<?php
require_once '../config/database.php'; // Include your database connection file
header('Content-Type: application/json'); // Set the response content type

// Get the raw POST data
$data = json_decode(file_get_contents("php://input"));

// Check if booking_id is provided
if (isset($data->booking_id)) {
    $booking_id = $data->booking_id;

    // Prepare the SQL statement
    $query = "
        SELECT prescriptions.*, 
               CONCAT(users.first_name, ' ', users.last_name) AS user_name,
               CONCAT(doctors.first_name, ' ', doctors.last_name) AS doctor_name
        FROM prescriptions
        LEFT JOIN users ON prescriptions.user_id = users.id
        LEFT JOIN users AS doctors ON prescriptions.doctor_id = doctors.id
        WHERE prescriptions.booking_id = :booking_id 
    ";
    // $query = "SELECT * FROM prescriptions WHERE booking_id = :booking_id";
    $stmt = $pdo->prepare($query); // Assuming $pdo is your PDO connection

    // Bind the booking_id parameter
    $stmt->bindParam(':booking_id', $booking_id, PDO::PARAM_INT);

    // Execute the statement
    if ($stmt->execute()) {
        $prescriptions = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetch all matching records

        // Check if any records were found
        if ($prescriptions) {
            echo json_encode($prescriptions); // Return the records as JSON
        } else {
            echo json_encode(['message' => 'No prescriptions found for this booking ID.']);
        }
    } else {
        echo json_encode(['error' => 'Failed to execute query.']);
    }
} else {
    echo json_encode(['error' => 'Booking ID is required.']);
}
