<?php 
require_once '../config/database.php'; // Ensure PDO connection is established

// Set header for JSON response
header('Content-Type: application/json');

const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'GET':
        $counts = getCounts($pdo);
        http_response_code(HTTP_OK);
        echo json_encode($counts);
        break;

    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}

/**
 * Get counts from the database
 *
 * @param PDO $pdo
 * @return array
 */
function getCounts($pdo) {
    $counts = [];

    // Count of patients
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = :role");
    $stmt->execute([':role' => 'user']);
    $counts['patients'] = $stmt->fetchColumn();

    // Count of pending bookings
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE status = :status");
    $stmt->execute([':status' => 'pending']);
    $counts['pending_bookings'] = $stmt->fetchColumn();

    // Count of extractions
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE service IN (:service1, :service2)");
    $stmt->execute([':service1' => 'Extraction', ':service2' => 'extraction']);
    $counts['extractions'] = $stmt->fetchColumn();

    // Count of scalings
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE service IN (:service1, :service2)");
    $stmt->execute([':service1' => 'Scaling', ':service2' => 'scaling']);
    $counts['scalings'] = $stmt->fetchColumn();

    return $counts;
}
?>
