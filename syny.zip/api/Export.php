<?php
require_once '../config/database.php'; // Ensure PDO connection is established
require '../vendor/autoload.php'; // Load PhpSpreadsheet library

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Set header for JSON response
header('Content-Type: application/json');

const HTTP_BAD_REQUEST = 400;
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'GET':
        // Get date parameters from the query string
        $fromDate = isset($_GET['from']) ? $_GET['from'] : null;
        $toDate = isset($_GET['to']) ? $_GET['to'] : null;
        $service = isset($_GET['services']) ? $_GET['services'] : null;
        $session = isset($_GET['sessions']) ? $_GET['sessions'] : null;

        // Validate date range inputs
        if (!$fromDate || !$toDate) {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['status' => 'error', 'message' => 'Please provide both from and to dates']);
            exit;
        }

        try {
            // Fetch all bookings within the date range
            // Start building the SQL query
            $sql = "SELECT * FROM bookings WHERE created_at BETWEEN :fromDate AND :toDate";

            // Add conditions for services and sessions if they are provided
            if ($service) {
                $sql .= " AND service = :service";
            }
            if ($session) {
                $sql .= " AND session = :session";
            }

            // Prepare the SQL statement
            $stmt = $pdo->prepare($sql);

            // Bind the common parameters (from and to dates)
            $stmt->bindParam(':fromDate', $fromDate);
            $stmt->bindParam(':toDate', $toDate);

            // Bind the optional parameters (services and sessions) if they are set
            if ($service) {
                $stmt->bindParam(':service', $service);
            }
            if ($session) {
                $stmt->bindParam(':session', $session);
            }

            // Execute the query
            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (empty($rows)) {
                http_response_code(HTTP_BAD_REQUEST);
                echo json_encode(['status' => 'error', 'message' => 'No data found for the specified date range']);
                exit;
            }

            // Collect user IDs and doctor IDs to fetch names later
            $userIds = array_column($rows, 'user_id');
            $doctorIds = array_column($rows, 'doctors_id');

            // Fetch user names
            $userNames = [];
            if (!empty($userIds)) {
                $userIdsPlaceholder = implode(',', array_fill(0, count($userIds), '?'));
                $userSql = "SELECT id, CONCAT(first_name, ' ', last_name) AS full_name FROM users WHERE id IN ($userIdsPlaceholder)";
                $userStmt = $pdo->prepare($userSql);
                $userStmt->execute($userIds);
                $userNames = $userStmt->fetchAll(PDO::FETCH_KEY_PAIR); // Fetch as associative array (id => full_name)
            }

            // Fetch doctor names
            $doctorNames = [];
            if (!empty($doctorIds)) {
                $doctorIdsPlaceholder = implode(',', array_fill(0, count($doctorIds), '?'));
                $doctorSql = "SELECT id, CONCAT(first_name, ' ', last_name) AS full_name FROM users WHERE id IN ($doctorIdsPlaceholder)";
                $doctorStmt = $pdo->prepare($doctorSql);
                $doctorStmt->execute($doctorIds);
                $doctorNames = $doctorStmt->fetchAll(PDO::FETCH_KEY_PAIR); // Fetch as associative array (id => full_name)
            }

            // Combine fetched data with names and modify keys
            $formattedRows = [];
            foreach ($rows as $row) {
                $formattedRow = [
                    'booking_id' => $row['id'], // Change 'id' to 'booking_id'
                    'booking_date' => $row['booking_date'],
                    'service' => $row['service'],
                    'session' => $row['session'],
                    'status' => $row['status'],
                    'patient_name' => $userNames[$row['user_id']] ?? 'No assigned patient yet', // Change 'user_name' to 'patient_name'
                    'doctor_name' => $doctorNames[$row['doctors_id']] ?? 'No assigned doctor yet', // Keep 'doctor_name'
                ];
                $formattedRows[] = $formattedRow; // Append formatted row to the new array
            }

            // Create a new spreadsheet and populate it with data
            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();

            // Set column headers
            $headers = array_keys($formattedRows[0]);
            $columnIndex = 'A';
            foreach ($headers as $header) {
                $sheet->setCellValue($columnIndex . '1', $header);
                $columnIndex++;
            }

            // Fill data rows
            $rowIndex = 2;
            foreach ($formattedRows as $row) {
                $columnIndex = 'A';
                foreach ($row as $cellValue) {
                    $sheet->setCellValue($columnIndex . $rowIndex, $cellValue);
                    $columnIndex++;
                }
                $rowIndex++;
            }

            // Output Excel file for download
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="data.xlsx"');
            header('Cache-Control: max-age=0');

            $writer = new Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
        } catch (Exception $e) {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['status' => 'error', 'message' => 'Error: ' . $e->getMessage()]);
            exit;
        }
        break;

    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
        break;
}
