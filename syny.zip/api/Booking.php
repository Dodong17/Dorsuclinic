<?php
require_once '../config/database.php'; // Ensure PDO connection is established

// Set header for JSON response
header('Content-Type: application/json');


function getBooking($pdo, $page = 1, $limit = 10, $query = "", $user_id = null, $status = null)
{
    // Calculate the offset based on the page number and limit
    $offset = ($page - 1) * $limit;

    // Prepare the SQL query
    $sql = "
        SELECT bookings.*, 
               IFNULL(CONCAT(doctors.first_name, ' ', doctors.last_name), 'No assigned doctor yet') AS doctor_name,
               IFNULL(CONCAT(users.first_name, ' ', users.last_name), 'No assigned user yet') AS user_name
        FROM bookings
        LEFT JOIN users AS doctors ON bookings.doctors_id = doctors.id
        LEFT JOIN users ON bookings.user_id = users.id
        WHERE (:user_id IS NULL OR bookings.user_id = :user_id)
          AND bookings.booking_date LIKE :booking_date
          AND (:status IS NULL OR bookings.status = :status)
        LIMIT :limit OFFSET :offset
    ";

    $stmt = $pdo->prepare($sql);

    // Prepare the query parameter for LIKE search
    $likeQuery = '%' . $query . '%';  // Assign the expression to a variable

    // Bind the parameters
    $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindValue(':status', $status, PDO::PARAM_STR);
    $stmt->bindValue(':booking_date', $likeQuery, PDO::PARAM_STR);
    $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);

    // Execute the query
    $stmt->execute();

    // Fetch all the matching bookings
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Query to count the total number of matching bookings
    $countSql = "
        SELECT COUNT(*) as total 
        FROM bookings 
        WHERE (:user_id IS NULL OR user_id = :user_id) 
          AND booking_date LIKE :booking_date
          AND (:status IS NULL OR status = :status)
    ";

    $countStmt = $pdo->prepare($countSql);

    // Bind the parameters for the count query
    $countStmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $countStmt->bindValue(':status', $status, PDO::PARAM_STR);
    $countStmt->bindValue(':booking_date', $likeQuery, PDO::PARAM_STR);
    $countStmt->execute();

    // Fetch the total count
    $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];

    // Return the bookings and the total count
    return [
        'bookings' => $bookings,
        'total' => $total
    ];
}




function createBooking($pdo, $input)
{
    // Destructure the input array
    [
        "user_id" => $user_id,
        "booking_date" => $booking_date,
        "session" => $session,
        "service" => $service
    ] = $input;

    // Validate required fields
    if (!$user_id || !$booking_date || !$session || !$service) {
        return [
            "status" => "failed",
            "message" => "All fields are required."
        ];
    }

    try {
        // Start a transaction to ensure data consistency
        $pdo->beginTransaction();

        $fetchAdmin = $pdo->prepare("SELECT email from users where role = 'admin'");
        $fetchAdmin->execute();
        $adminEmail = $fetchAdmin->fetch(PDO::FETCH_ASSOC)['email'];


        // Insert into the bookings table
        $stmt = $pdo->prepare("
            INSERT INTO bookings (user_id, booking_date, session, service, status) 
            VALUES (:user_id, :booking_date, :session, :service, 'pending')
        ");
        $stmt->execute([
            ":user_id" => $user_id,
            ":booking_date" => $booking_date,
            ":session" => $session,
            ":service" => $service
        ]);

        // Determine if it's a morning or afternoon session, and decrement the corresponding slot
        if ($session === "Morning Session") {
            // Decrement the morning_slot
            $updateStmt = $pdo->prepare("
                UPDATE appointment_schedule 
                SET morning_slot = morning_slot - 1 
                WHERE date = :booking_date AND morning_slot > 0
            ");
        } elseif ($session === "Afternoon Session") {
            // Decrement the afternoon_slot
            $updateStmt = $pdo->prepare("
                UPDATE appointment_schedule 
                SET afternoon_slot = afternoon_slot - 1 
                WHERE date = :booking_date AND afternoon_slot > 0
            ");
        }

        // Execute the update statement to decrement the slot
        $updateStmt->execute([
            ":booking_date" => $booking_date
        ]);

        // Check if the slot was decremented (affected rows > 0)
        if ($updateStmt->rowCount() === 0) {
            // Rollback if no slot was decremented (slots are full)
            $pdo->rollBack();
            return [
                "status" => "failed",
                "message" => "No available slots for the selected session."
            ];
        }

        // Commit the transaction
        $pdo->commit();

        $escapedEmail = escapeshellarg($adminEmail);

        $command = "start /B php ../lib/mailer/NewAppointment.php $escapedEmail  >> ../logfile.log 2>&1";
        pclose(popen("cmd.exe /c $command", "r"));

        return [
            "status" => "success",
            "message" => "Booking created successfully."
        ];
    } catch (Exception $e) {
        // Rollback the transaction in case of error
        $pdo->rollBack();
        return [
            "status" => "failed",
            "message" => "Error creating booking: " . $e->getMessage()
        ];
    }
}


function deleteBooking($pdo, $id)
{
    try {
        // Start the transaction
        $pdo->beginTransaction();

        // Fetch the booking by ID to get the booking_date and session
        $stmt = $pdo->prepare("SELECT booking_date, session FROM bookings WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $booking = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$booking) {
            return [
                "status" => "failed",
                "message" => "Booking not found."
            ];
        }

        $bookingDate = $booking['booking_date'];
        $session = $booking['session'];

        // Delete the booking
        $stmt = $pdo->prepare("DELETE FROM bookings WHERE id = :id");
        $stmt->execute([':id' => $id]);

        // Increment the slot count in appointment_schedule based on session
        if ($session === 'Morning Session') {
            $updateSlot = "UPDATE appointment_schedule SET morning_slot = morning_slot + 1 WHERE date = :booking_date";
        } elseif ($session === 'Afternoon Session') {
            $updateSlot = "UPDATE appointment_schedule SET afternoon_slot = afternoon_slot + 1 WHERE date = :booking_date";
        } else {
            // If the session is invalid, roll back and return an error
            $pdo->rollBack();
            return [
                "status" => "failed",
                "message" => "Invalid session type."
            ];
        }

        // Execute the update for the slot
        $stmt = $pdo->prepare($updateSlot);
        $stmt->execute([':booking_date' => $bookingDate]);

        // Commit the transaction
        $pdo->commit();

        return [
            "status" => "success",
            "message" => "Booking deleted and slot updated successfully."
        ];
    } catch (Exception $e) {
        // Roll back if there's an error
        $pdo->rollBack();
        return [
            "status" => "failed",
            "message" => "Error deleting booking: " . $e->getMessage()
        ];
    }
}

function sendSms($mobile, $message)
{
    try {
        $ch = curl_init();
        $parameters = array(
            'apikey' => '96200abeb2a535b6d13b3cc0839e2dc5', // Your API KEY
            'number' => $mobile, // Use the full international number format
            'message' => $message,
            'sendername' => 'DORSUCLINIC'
        );
        curl_setopt($ch, CURLOPT_URL, 'https://semaphore.co/api/v4/messages');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Send the request
        $output = curl_exec($ch);

        // Check for errors
        if (curl_errno($ch)) {
            $error = 'Curl error: ' . curl_error($ch);
            error_log($error); // Log the error for debugging
            curl_close($ch);
            return false;
        }

        // Decode the JSON response from Semaphore API
        $response = json_decode($output, true);

        // Log the response for debugging
        if (isset($response['status']) && $response['status'] === 'success') {
            error_log("Message sent successfully to {$mobile}");
        } else {
            error_log("Failed to send message to {$mobile}. Response: " . json_encode($response));
        }

        curl_close($ch);

        return isset($response['status']) && $response['status'] === 'success';
    } catch (\Throwable $th) {
        echo $th;
    }
}


function updateBookingStatus($pdo, $input)
{
    try {
        // Start a transaction
        $pdo->beginTransaction();

        [
            "action" => $action,
            "doctor_id" => $doctor_id,
            "booking_id" => $booking_id
        ] = $input;

        $stmtUpdateBooking = "";

        if ($action === "declined") {
            $stmtUpdateBooking = "UPDATE bookings 
                                  SET status = 'declined', updated_at = NOW() 
                                  WHERE id = :booking_id";
        } else {
            $stmtUpdateBooking = "UPDATE bookings 
                                  SET status = 'approved', doctors_id = :doctor_id, updated_at = NOW() 
                                  WHERE id = :booking_id";
        }

        // Prepare and execute the update statement
        $stmt = $pdo->prepare($stmtUpdateBooking);

        if ($action === "declined") {
            $stmt->bindParam(':booking_id', $booking_id, PDO::PARAM_INT);
        } else {
            $stmt->bindParam(':booking_id', $booking_id, PDO::PARAM_INT);
            $stmt->bindParam(':doctor_id', $doctor_id, PDO::PARAM_INT);
        }

        $stmt->execute();

        $doctorEmail = null;
        $doctorName = null;
        $doctorPhone = null;
        if (!empty($doctor_id)) {
            // Modify the query to fetch first_name, last_name, and email
            $stmtFetchDoctorDetails = $pdo->prepare("SELECT first_name, last_name, email, contact FROM users WHERE id = :doctor_id");
            $stmtFetchDoctorDetails->bindParam(':doctor_id', $doctor_id, PDO::PARAM_INT);
            $stmtFetchDoctorDetails->execute();

            // Fetch the doctor's details
            $doctorDetails = $stmtFetchDoctorDetails->fetch(PDO::FETCH_ASSOC);

            if ($doctorDetails) {
                $doctorEmail = $doctorDetails['email'];  // Fetch the email
                $doctorName = $doctorDetails['first_name'] . ' ' . $doctorDetails['last_name'];  // Concatenate first name and last name
                $doctorPhone = $doctorDetails['contact'];  // Fetch the phone number
            }
        }
        // Fetch user_id from the bookings table using the booking_id
        $stmtFetchUserId = $pdo->prepare("SELECT user_id FROM bookings WHERE id = :booking_id");
        $stmtFetchUserId->bindParam(':booking_id', $booking_id, PDO::PARAM_INT);
        $stmtFetchUserId->execute();
        $user_id = $stmtFetchUserId->fetchColumn();

        // Fetch the user's email using the fetched user_id
        $userEmail = null;
        $userPhone = null;

        if ($user_id) {
            // Prepare the query
            $stmtFetchUserEmail = $pdo->prepare("SELECT email, contact FROM users WHERE id = :user_id");
            $stmtFetchUserEmail->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmtFetchUserEmail->execute();

            // Fetch both email and contact
            $result = $stmtFetchUserEmail->fetch(PDO::FETCH_ASSOC);
            if ($result) {
                $userEmail = $result['email']; // Retrieve the email
                $userPhone = $result['contact']; // Retrieve the phone number
            }
        }

        // Commit the transaction only if all queries were successful
        $pdo->commit();
        if ($action === "declined") {

            $escapedEmailUser = escapeshellarg($userEmail);
     
            $userMessage = "We regret to inform you that your appointment request has been declined.";


            $command = "start /B php ../lib/mailer/DeclineAppointment.php $escapedEmailUser >> ../logfile.log 2>&1";

            pclose(popen("cmd.exe /c $command", "r"));

            sendSms($userPhone, $userMessage);
        } else {

            $escapedEmailUser = escapeshellarg($userEmail);
            $escapedEmailDoctor = escapeshellarg($doctorEmail);
            $escapedDoctorName = escapeshellarg($doctorName);
           
     
            $userMessage = 'We are pleased to inform you that your appointment has been approved.';
            $doctorMessage = 'There is a new appointment assigned to you.';

            $command = "start /B php ../lib/mailer/ApproveAppointment.php $escapedEmailUser $escapedEmailDoctor $escapedDoctorName >> ../logfile.log 2>&1";

            pclose(popen("cmd.exe /c $command", "r"));

            sendSms($userPhone, $userMessage);
            sendSms($doctorPhone, $doctorMessage);
        }


        return [
            "status" => "success",
            "message" => "Booking updated successfully.",
        ];
    } catch (Exception $e) {
        // Roll back the transaction if something goes wrong
        $pdo->rollBack();

        return [
            "status" => "failed",
            "message" => "Error updating booking: " . $e->getMessage()
        ];
    }
}



const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'GET':
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
        $query = isset($_GET['query']) ? $_GET['query'] : ""; // Get query from request
        $user_id = $_GET['user_id'] ?? null;
        $status = $_GET['status'] ?? null;
        $data = getBooking($pdo, $page, $limit, $query, $user_id, $status); // Pass the query parameter
        http_response_code(HTTP_OK);
        echo json_encode($data);
        break;
    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        $response = createBooking($pdo, $input);
        break;
    case 'PATCH':
        $input = json_decode(file_get_contents("php://input"), true);
        $response = updateBookingStatus($pdo, $input);
        http_response_code(HTTP_OK);
        echo json_encode($response);
        break;
    case 'DELETE':
        $id = $_GET['id'] ?? null;
        $response = deleteBooking($pdo, $id);
        http_response_code(HTTP_OK);
        echo json_encode($response);
        break;

    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}
