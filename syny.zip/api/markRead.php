<?php

require_once '../config/database.php';
header('Content-Type: application/json');

$requestMethod = $_SERVER['REQUEST_METHOD'];

if ($requestMethod === 'POST') {
    $input = json_decode(file_get_contents("php://input"), true);
    $conversationId = $input['conversationId'];
    $receiverId = $input['receiverId']; // ID of the user reading the messages

    $stmt = $pdo->prepare("
        UPDATE messages
        SET status = 'read'
        WHERE conversation_id = :conversation_id
        AND sender_id = :receiver_id
        AND status = 'unread'
    ");
    $stmt->execute(['conversation_id' => $conversationId, 'receiver_id' => $receiverId]);

    http_response_code(200);
    echo json_encode(['message' => 'Messages marked as read']);
} else {
    http_response_code(405);
    echo json_encode(['message' => 'Method not allowed']);
}
?>
