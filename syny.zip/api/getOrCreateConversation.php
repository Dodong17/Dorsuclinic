<?php 

// getOrCreateConversation.php
require_once '../config/database.php';
header('Content-Type: application/json');

$userId1 = $_GET['user1_id'];
$userId2 = $_GET['user2_id'];

// Fetch conversation if it exists
$stmt = $pdo->prepare("SELECT id FROM conversations WHERE (user1_id = :user1 AND user2_id = :user2) OR (user1_id = :user2 AND user2_id = :user1)");
$stmt->execute(['user1' => $userId1, 'user2' => $userId2]);
$conversation = $stmt->fetch(PDO::FETCH_ASSOC);

if ($conversation) {
    echo json_encode(['conversation_id' => $conversation['id']]);
} else {
    // Create a new conversation if it doesn't exist
    $stmt = $pdo->prepare("INSERT INTO conversations (user1_id, user2_id) VALUES (:user1, :user2)");
    $stmt->execute(['user1' => $userId1, 'user2' => $userId2]);
    echo json_encode(['conversation_id' => $pdo->lastInsertId()]);
}


?>