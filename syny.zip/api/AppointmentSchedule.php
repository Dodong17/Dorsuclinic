<?php
require_once '../config/database.php'; // Ensure PDO connection is established

// Set header for JSON response
header('Content-Type: application/json');



function fetchScheduledDatesAndTimes($pdo)
{
    // Fetch scheduled dates and times from the database
    $sql = "SELECT * FROM appointment_schedule";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    // Fetch all results as an associative array
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return ["status" => "success", "results" => $results];
}


function addEvent($pdo, $input)
{

    try {
        //code...

        [
            "date" => $date,
            "morning_slot" => $morning_slot,
            "afternoon_slot" => $afternoon_slot
        ] = $input;

        // Check if morning_slot and afternoon_slot are integers
        if (!filter_var($morning_slot, FILTER_VALIDATE_INT) || !filter_var($afternoon_slot, FILTER_VALIDATE_INT)) {
            return ["status" => "failed", "message" => "Slots must be whole numbers and must be 1 or greater"];
        }

        // Convert to integers
        $morning_slot = intval($morning_slot);
        $afternoon_slot = intval($afternoon_slot);

        // Check if the slots are greater than or equal to 1
        if ($morning_slot < 1 || $afternoon_slot < 1) {
            return ["status" => "failed", "message" => "Slots must be 1 or greater"];
        }

        // Check if the date already exists in the appointment_schedule table
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM appointment_schedule WHERE date = ?");
        $stmt->execute([$date]);
        $count = $stmt->fetchColumn();

        if ($count > 0) {
            return ["status" => "failed", "message" => "The date already exists"];
        }

        // If the date does not exist, proceed to insert the new event
        $stmt = $pdo->prepare("INSERT INTO appointment_schedule (date, morning_slot, afternoon_slot) VALUES (?, ?, ?)");
        $stmt->execute([$date, $morning_slot, $afternoon_slot]);

        return ["status" => "success", "message" => "Event added successfully"];
    } catch (Exception $e) {
        // Handle any exceptions that occur
        return ["status" => "error", "message" => "An error occurred: " . $e->getMessage()];
    }
}

function deleteEvent($pdo, $sched_id)
{
    try {
        //code...
        if (!$sched_id) {
            return ["status" => "failed", "message" => "Schedule id is required"];
        }

        $sql = "delete from appointment_schedule where id = :sched_id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':sched_id', $sched_id);
        $stmt->execute();

        return ["status" => "success", "message" => "Event deleted successfully"];
    } catch (\Throwable $th) {
        //throw $th;
        return ["status" => "failed", "message" => "Error deleting event: " . $th->getMessage()];
    }
}

function updateEvent($pdo, $input)
{
    try {
        [
            'sched_id' => $sched_id,
            'morning_slot' => $morning_slot,
            'afternoon_slot' => $afternoon_slot
        ] = $input;

        if (!$sched_id) {
            return ["status" => "failed", "message" => "Schedule id is required"];
        }

        if (!filter_var($morning_slot, FILTER_VALIDATE_INT) || !filter_var($afternoon_slot, FILTER_VALIDATE_INT)) {
            return ["status" => "failed", "message" => "Slots must be whole numbers and must be 1 or greater"];
        }

        // Convert to integers
        $morning_slot = intval($morning_slot);
        $afternoon_slot = intval($afternoon_slot);

        // Check if the slots are greater than or equal to 1
        if ($morning_slot < 1 || $afternoon_slot < 1) {
            return ["status" => "failed", "message" => "Slots must be 1 or greater"];
        }

        $sql = "update appointment_schedule set morning_slot = :morning_slot, afternoon_slot = :afternoon_slot where id = :sched_id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':sched_id', $sched_id, PDO::PARAM_INT);
        $stmt->bindParam(':morning_slot', $morning_slot, PDO::PARAM_INT);
        $stmt->bindParam(':afternoon_slot', $afternoon_slot, PDO::PARAM_INT);

        $stmt->execute();

        return ["status" => "success", "message" => "Event updated successfully"];
    } catch (\Throwable $th) {
        return ["status" => "failed", "message" => "Error deleting event: " . $th->getMessage()];
    }
}





const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'GET':
        // Call the function to fetch scheduled dates and times
        $data = fetchScheduledDatesAndTimes($pdo);
        http_response_code(HTTP_OK);
        echo json_encode($data);
        break;
    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        $response = addEvent($pdo, $input);
        if ($response) {
            http_response_code(HTTP_OK);
            echo json_encode($response);
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'Invalid input']);
        }
        break;
    case 'DELETE':
        $sched_id = $_GET['id'] ?? null;
        $response = deleteEvent($pdo, $sched_id);
        if ($response) {
            http_response_code(HTTP_OK);
            echo json_encode($response);
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'Invalid input']);
        }
        break;
    case 'PUT':
        $input = json_decode(file_get_contents("php://input"), true);
        $response = updateEvent($pdo, $input);
        if ($response) {
            http_response_code(HTTP_OK);
            echo json_encode($response);
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'Invalid input']);
        }
        break;

    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}
