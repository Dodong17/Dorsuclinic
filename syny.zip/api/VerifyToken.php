<?php
require_once '../config/database.php';
require_once '../vendor/autoload.php';
require_once '../lib/authMiddleware.php';

header('Content-Type: application/json');

const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_UNAUTHORIZED = 401; // Added for unauthorized access
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'POST':
        $headers = getallheaders();
        if (isset($headers['Authorization'])) {
            $token = str_replace('Bearer ', '', $headers['Authorization']);
            $response = verifyToken($token);

            if ($response['status'] === 'success') {
                http_response_code(HTTP_OK);
                echo json_encode($response);
            }elseif($response['status'] === 'failed'){
                http_response_code(HTTP_BAD_REQUEST);
                echo json_encode(['message' => 'Invalid token: ' . $response['message']]);
            }
            else {
                http_response_code(HTTP_UNAUTHORIZED);
                echo json_encode(['message' => 'Invalid token: ' . $response['message']]);
            }
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'No authorization header.']);
        }
        break;

    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}
