<?php
require_once '../config/database.php'; // Ensure PDO connection is established

// Set header for JSON response
header('Content-Type: application/json');

function getDoctors($pdo, $page = 1, $limit = 10, $query = "")
{
  $offset = ($page - 1) * $limit;


  $sql = "SELECT * FROM users 
            WHERE role = 'doctor' 
              AND (first_name LIKE ? OR last_name LIKE ?) 
            LIMIT ? OFFSET ?"; // Use ? for positional parameters

  $stmt = $pdo->prepare($sql);


  $likeQuery = '%' . $query . '%';

  // Bind the parameters
  $stmt->bindParam(1, $likeQuery, PDO::PARAM_STR);
  $stmt->bindParam(2, $likeQuery, PDO::PARAM_STR);

  $stmt->bindValue(3, (int)$limit, PDO::PARAM_INT);
  $stmt->bindValue(4, (int)$offset, PDO::PARAM_INT);

  // Execute the query
  $stmt->execute();
  $doctors = $stmt->fetchAll(PDO::FETCH_ASSOC);


  $countSql = "SELECT COUNT(*) as total FROM users 
                 WHERE role = 'doctor' 
                   AND (first_name LIKE ? OR last_name LIKE ?)";

  $countStmt = $pdo->prepare($countSql);

  // Bind the same name parameter for the count
  $countStmt->bindParam(1, $likeQuery, PDO::PARAM_STR);
  $countStmt->bindParam(2, $likeQuery, PDO::PARAM_STR);
  $countStmt->execute();

  $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];

  return ['doctors' => $doctors, 'total' => $total];
}

function updatePassword($pdo, $input)
{
  try {
    [
      "id" => $id,
      "current_password" => $currentPassword,
      "password" => $newPassword,
      "confirm_password" => $confirmPassword
    ] = $input;

    // Fetch current password from the database
    $passwordCheckSql = "SELECT password FROM users WHERE id = :id";
    $passwordCheckStmt = $pdo->prepare($passwordCheckSql);
    $passwordCheckStmt->execute(['id' => $id]);
    $user = $passwordCheckStmt->fetch(PDO::FETCH_ASSOC);

    // Verify user exists
    if (!$user) {
      return [
        "status" => "failed",
        "message" => "User does not exist."
      ];
    }

    // Verify current password
    if (!password_verify($currentPassword, $user['password'])) {
      return [
        "status" => "failed",
        "message" => "Current password is incorrect."
      ];
    }

    // Check if new password matches current password
    if ($newPassword === $currentPassword) {
      return [
        "status" => "failed",
        "message" => "New password cannot be the same as the current password."
      ];
    }

    // Check if new password matches confirmation
    if ($newPassword !== $confirmPassword) {
      return [
        "status" => "failed",
        "message" => "New password and confirmation do not match."
      ];
    }

    // Hash and update the new password
    $currentTime = date('Y-m-d H:i:s');
    $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $updateSql = "UPDATE users SET password = :password, updated_at = :updated_at WHERE id = :id";
    $updateStmt = $pdo->prepare($updateSql);
    $updateStmt->execute([
      'password' => $hashedNewPassword,
      'updated_at' => $currentTime,
      'id' => $id
    ]);

    return [
      "status" => "success",
      "message" => "Password updated successfully",
      "updated_at" => $currentTime
    ];
  } catch (\Throwable $th) {
    return [
      "status" => "error",
      "message" => $th->getMessage()
    ];
  }
}


function checkPassword($pdo, $input)
{
  ["id" => $id] = $input;

  // Query to get the created_at and updated_at timestamps for the user
  $sql = "SELECT created_at, updated_at FROM users WHERE id = :id";
  $stmt = $pdo->prepare($sql);
  $stmt->execute(['id' => $id]);
  $result = $stmt->fetch(PDO::FETCH_ASSOC);

  if (!$result) {
    return [
      "status" => "failed",
      "message" => "User not found."
    ];
  }

  // Check if created_at and updated_at are equal
  if ($result['created_at'] === $result['updated_at']) {
    return [
      "status" => "success",
      "password_changed" => false,
      "message" => "Password has not been changed since account creation."
    ];
  } else {
    return [
      "status" => "success",
      "password_changed" => true,
      "message" => "Password has been changed."
    ];
  }
}




// Define HTTP response codes
const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;   
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
  case 'GET':
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $query = isset($_GET['query']) ? $_GET['query'] : ""; // Get query from request

    $data = getDoctors($pdo, $page, $limit, $query); // Pass the query parameter
    http_response_code(HTTP_OK);
    echo json_encode($data);
    break;
  case 'PATCH':
    $input = json_decode(file_get_contents("php://input"), true);
    $response = updatePassword($pdo, $input);
    if ($response) {
      http_response_code(HTTP_OK);
      echo json_encode($response);
    } else {
      http_response_code(HTTP_BAD_REQUEST);
      echo json_encode(['message' => 'Invalid input']);
    }
    break;
  case 'POST':
    $input = json_decode(file_get_contents("php://input"), true);
    $response = checkPassword($pdo, $input);
    if ($response) {
      http_response_code(HTTP_OK);
      echo json_encode($response);
    } else {
      http_response_code(HTTP_BAD_REQUEST);
      echo json_encode(['message' => 'Invalid input']);
    }
    break;

  default:
    http_response_code(HTTP_METHOD_NOT_ALLOWED);
    echo json_encode(['message' => 'Method not allowed']);
    break;
}
