<?php
require_once '../config/database.php'; // Ensure PDO connection is established

// Set header for JSON response
header('Content-Type: application/json');



function getExtractedTeeth($pdo, $id)
{
    try {

        $stmt = $pdo->prepare("SELECT * FROM patient_teeth WHERE user_id = :id");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        $stmt->execute();


        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (\Throwable $th) {
        return ["status" => "error", "message" => "An error occurred: " . $th->getMessage()];
    }
}

function createExtractedTeeth($pdo, $input){
    try {
        $pdo->beginTransaction();
        $sql = "INSERT INTO patient_teeth (user_id, teeth_no, description) VALUES (:user_id, :teeth_no, :description)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':user_id' => $input['user_id'],
            ':teeth_no' => $input['teeth_no'],
            ':description' => $input['description']
        ]);
        $pdo->commit();
        return [
            "status" => "success",
            "message" => "Extracted teeth added successfully"
        ];
    } catch (Exception $e) {
        $pdo->rollBack();
        return [
            "status" => "failed",
            "message" => "An error occurred: " . $e->getMessage()
        ];
    }

}


const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;




$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'GET':
        $id = $_GET['id'];
        $extracted_teeth = getExtractedTeeth($pdo, $id);
        http_response_code(HTTP_OK);
        echo json_encode($extracted_teeth);
        break;
        // // $users = getAllUsers($pdo, $input);
        // // http_response_code(HTTP_OK);
        // // echo json_encode($users);
        // break;
    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        $response = createExtractedTeeth($pdo, $input);
        if ($response) {
            http_response_code(HTTP_OK);
            echo json_encode($response);
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'Invalid input']);
        }
        break;
    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}
