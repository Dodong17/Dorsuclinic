<?php

require_once '../config/database.php'; // Ensure PDO connection is established
require_once '../vendor/autoload.php';

use \Firebase\JWT\JWT;

// Set header for JSON response
header('Content-Type: application/json');

// Define HTTP response codes
const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;


$requestMethod = $_SERVER['REQUEST_METHOD'];



function login($pdo, $input)
{
    $secret_key = "your_secret_key";
    $id_number = $input['id_number'] ?? null;
    $password = $input['password'] ?? null;

    if (!$id_number || !$password) {
        return false;
    }

    $sql = "SELECT * FROM users WHERE id_number = :id_number ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id_number' => $id_number]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        return ["message" => "ID number not found.", "status" => "failed", "error" => "id_number"];
    }

    if (!password_verify($password, $user['password'])) {
        return ["message" => "Incorrect password.", "status" => "failed", "error" => "password"];
    }

    if (!$user['verified_at']) {

        $escapedEmail = escapeshellarg($user['email']);
        $escapedId = escapeshellarg($user['id']);

        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $hostName = $protocol . '://' . $host . "/syny";

        $escapedHostName = escapeshellarg($hostName);


        $command = "start /B php ../lib/mailer/VerificationLink.php $escapedEmail $escapedId $escapedHostName  >> ../logfile.log 2>&1";
        pclose(popen("cmd.exe /c $command", "r"));


        return ["message" => "Your account is not yet verfied. We sent a verification link to your registered email.", "status" => "failed", "error" => "password"];
    }

    // Define token payload
    $payload = [
        'iss' => "SYNY",
        'iat' => time(),
        'exp' => time() + (60 * 60), // Token expiration (1 hour)
        'data' => [
            'username' => $user["id_number"],
            "first_name" => $user["first_name"],
            "last_name" => $user["last_name"],
            "role" => $user["role"]
        ]
    ];

    // Generate JWT token
    $jwt = JWT::encode($payload, $secret_key, 'HS256');
    return ['status' => 'success', 'token' => $jwt, "role" => $user["role"], "id" => $user["id"], "user_type" => $user["user_type"], "first_name" => $user["first_name"], "last_name" => $user["last_name"]];
}


switch ($requestMethod) {


    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        $response = login($pdo, $input);

        if ($response) {
            http_response_code(HTTP_CREATED);
            echo json_encode($response);
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'Invalid input']);
        }
        break;


    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}
