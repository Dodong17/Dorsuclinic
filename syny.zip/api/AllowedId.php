<?php
require_once '../config/database.php'; // Ensure PDO connection is established

// Set header for JSON response
header('Content-Type: application/json');



function getAllowedId($pdo)
{
    try {
        $sql = "SELECT * FROM allowed_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    } catch (PDOException $e) {
        // Handle the error
        return ['error' => 'Failed to retrieve allowed IDs', 'message' => $e->getMessage()];
    }
}

function addAllowedId($pdo, $input)
{
    $sql = "INSERT INTO allowed_id (valid_id) VALUES (:allowed_id)";
    $stmt = $pdo->prepare($sql);

    // Ensure the parameter name matches the placeholder in the SQL query
    $stmt->execute(['allowed_id' => $input['allowed_id']]);

    return ['message' => 'Id added successfully', 'status' => 'success'];
}

function deleteAllowedId($pdo, $id)
{

    $sql = "DELETE FROM allowed_id WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $id]);

    return ['message' => 'Id deleted successfully', 'status' => 'success'];
}

const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'GET':
        $ids = getAllowedId($pdo);
        http_response_code(HTTP_OK);
        echo json_encode($ids);
        break;
    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        $response = addAllowedId($pdo, $input);

        if ($response) {
            http_response_code(HTTP_CREATED);
            echo json_encode($response);
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'Invalid input']);
        }
        break;
    case 'DELETE':
        $id = $_GET['id'] ?? null;
        $response = deleteAllowedId($pdo, $id);

        if ($response) {
            http_response_code(HTTP_CREATED);
            echo json_encode($response);
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'Invalid input']);
        }
        break;

    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}
