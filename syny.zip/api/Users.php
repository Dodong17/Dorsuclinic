<?php

require_once '../config/database.php'; // Ensure PDO connection is established


// Set header for JSON response
header('Content-Type: application/json');



// Function to generate a unique BIGINT(20) ID
function generateUniqueId($pdo)
{
    $uniqueId = random_int(10000, 999999999999999);

    // Ensure uniqueness
    $sql = "SELECT COUNT(*) FROM users WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $uniqueId]);

    if ($stmt->fetchColumn() > 0) {
        return generateUniqueId($pdo);
    }

    return $uniqueId;
}



function validateUserDetails($pdo, $id_number, $contact, $email)
{
    $sql = "SELECT 
                COUNT(CASE WHEN id_number = :id_number THEN 1 END) as id_count,
                COUNT(CASE WHEN contact = :contact THEN 1 END) as contact_count,
                COUNT(CASE WHEN email = :email THEN 1 END) as email_count
            FROM users";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'id_number' => $id_number,
        'contact' => $contact,
        'email' => $email
    ]);




    $counts = $stmt->fetch(PDO::FETCH_ASSOC);


    if ($counts['id_count'] > 0) {
        return [
            "status" => "failed",
            "message" => "ID Number already exists.",
            "error" => "id_number"
        ];
    } elseif ($counts['contact_count'] > 0) {
        return [
            "status" => "failed",
            "message" => "Contact number already exists.",
            "error" => "contact"
        ];
    } elseif ($counts['email_count'] > 0) {
        return [
            "status" => "failed",
            "message" => "Email address already exists.",
            "error" => "email"
        ];
    }


    return null;
}

// Function to fetch all users
function getAllUsers($pdo)
{
    $sql = "SELECT * FROM users";
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function validateBeforeSaving($pdo, $id, $id_number, $contact, $email)
{
    // Check if the user with the provided $id exists
    $idCheckSql = "SELECT COUNT(*) as valid_id FROM users WHERE id = :id";
    $idCheckStmt = $pdo->prepare($idCheckSql);
    $idCheckStmt->execute(['id' => $id]);
    $idCheckResult = $idCheckStmt->fetch(PDO::FETCH_ASSOC);

    // If the ID does not exist, return an error message
    if ($idCheckResult['valid_id'] == 0) {
        return [
            "status" => "failed",
            "message" => "User does not exist."
        ];
    }

    // If the ID exists, proceed to check id_number, contact, and email for uniqueness
    $sql = "SELECT 
    COUNT(CASE WHEN id_number = :id_number AND id != :id THEN 1 END) as id_count,
    COUNT(CASE WHEN contact = :contact AND id != :id THEN 1 END) as contact_count,
    COUNT(CASE WHEN email = :email AND id != :id THEN 1 END) as email_count
FROM users";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'id' => $id,
        'id_number' => $id_number,
        'contact' => $contact,
        'email' => $email
    ]);

    $counts = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($counts['id_count'] > 0) {
        return [
            "status" => "failed",
            "message" => "ID Number already exists.",
            "error" => "id_number"
        ];
    } elseif ($counts['contact_count'] > 0) {
        return [
            "status" => "failed",
            "message" => "Contact number already exists.",
            "error" => "contact"
        ];
    } elseif ($counts['email_count'] > 0) {
        return [
            "status" => "failed",
            "message" => "Email address already exists.",
            "error" => "email"
        ];
    }

    // If no issues are found, return null indicating success
    return null;
}


function saveEdit($pdo, $input)
{

    try {
        //code...
        [

            "id" => $id,
            "birth_date" => $birth_date,
            "contact" => $contact,
            "first_name" => $first_name,
            "gender" => $gender,
            "id_number" => $id_number,
            "last_name" => $last_name,
            "email" => $email,

        ] = $input;
        if ($input) {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return ["message" => "Invalid email address.", "error" => "email", "status" => "failed"];
            }
            $validationResponse = validateBeforeSaving($pdo, $id, $id_number, $contact, $email);
            if ($validationResponse) {
                return $validationResponse;
            }

            $sql = "UPDATE users SET 
            birth_date = :birth_date, 
            contact = :contact, 
            first_name = :first_name, 
            gender = :gender, 
            id_number = :id_number, 
            last_name = :last_name, 
            email = :email 
        WHERE id = :id";

            $stmt = $pdo->prepare($sql);

            $stmt->execute([
                "id" => $id,
                "birth_date" => $birth_date,
                "contact" => $contact,
                "first_name" => $first_name,
                "gender" => $gender,
                "id_number" => $id_number,
                "last_name" => $last_name,
                "email" => $email
            ]);

            return ['message' => 'Saved successfully', "status" => "success"];
        } else {
            return ["message" => "Something went wrong.", "status" => "error"]; // Invalid input
        }
    } catch (\Throwable $th) {
        //throw $th;
        return ["message" => $th, "status" => "error"];
    }
}


// Function to create a new user
function createUser($pdo, $input)
{

    try {
        [
            "birth_date" => $birth_date,
            "confirm_password" => $confirm_password,
            "contact" => $contact,
            "first_name" => $first_name,
            "gender" => $gender,
            "id_number" => $id_number,
            "last_name" => $last_name,
            "password" => $password,
            "user_type" => $user_type,
            "email" => $email,
            "role" => $role

        ] = $input;

        $checkIdNumber = "SELECT COUNT(*) as id_count FROM allowed_id WHERE valid_id = :id_number";
        $stmt = $pdo->prepare($checkIdNumber);
        $stmt->execute([':id_number' => $id_number]);

        // Fetch the count result
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result['id_count'] <= 0) {
            return [
                "message" => "ID number does not exist in the database.",
                "status" => "failed",
                "error" => "id_number"
            ];
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ["message" => "Invalid email address.", "error" => "email", "status" => "failed"];
        }
        if ($confirm_password != $password) {
            return ["message" => "Password not match.", "error" => "confirm_password", "status" => "failed"];
        }

        $validationResponse = validateUserDetails($pdo, $id_number, $contact, $email);
        if ($validationResponse) {
            return $validationResponse;
        }

        $hashPassword = password_hash($password, PASSWORD_DEFAULT);




        if ($input) {
            $uniqueId = generateUniqueId($pdo);
            $sql = "INSERT INTO users (id, id_number, first_name, last_name, contact, birth_date, gender, user_type, role, password, email) VALUES (:id, :id_number, :first_name, :last_name, :contact, :birth_date, :gender, :user_type, :role, :password, :email)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                "id" => $uniqueId,
                "id_number" => $id_number,
                "first_name" => $first_name,
                "last_name" => $last_name,
                "contact" => $contact,
                "birth_date" => $birth_date,
                "gender" => $gender,
                "user_type" => $user_type,
                "role" => $role,
                "password" => $hashPassword,
                "email" => $email
            ]);


            if ($role == "doctor") {
                $escapedEmail = escapeshellarg($email);
                $escapedIdNumber = escapeshellarg($id_number);
                $escapedPassword = escapeshellarg($password);

                $command = "start /B php ../lib/mailer/DoctorsCredential.php $escapedEmail $escapedIdNumber $escapedPassword >> ../logfile.log 2>&1";
                pclose(popen("cmd.exe /c $command", "r"));
            } elseif ($role == "user") {
                $escapedEmail = escapeshellarg($email);

                $command = "start /B php ../lib/mailer/UserCreation.php $escapedEmail >> ../logfile.log 2>&1";
                pclose(popen("cmd.exe /c $command", "r"));
            }

            return ['message' => 'User created successfully', 'id' => $uniqueId, "status" => "success"];
        } else {
            return ["message" => "Something went wrong.", "status" => "error"];
        }
    } catch (\Throwable $th) {
        //throw $th;
        return ["message" => $th, "status" => "error"];
    }
}

// Function to delete a user by ID
function deleteUser($pdo, $userId)
{
    $sql = "DELETE FROM users WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $userId]);

    // Check if any rows were deleted
    return $stmt->rowCount() > 0; // Returns true if at least one row was deleted
}

// Define HTTP response codes
const HTTP_OK = 200;
const HTTP_CREATED = 201;
const HTTP_NO_CONTENT = 204;
const HTTP_BAD_REQUEST = 400;
const HTTP_NOT_FOUND = 404;
const HTTP_METHOD_NOT_ALLOWED = 405;

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'GET':
        $users = getAllUsers($pdo);
        http_response_code(HTTP_OK);
        echo json_encode($users);
        break;

    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        $response = createUser($pdo, $input);

        if ($response) {
            http_response_code(HTTP_CREATED);
            echo json_encode($response);
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'Invalid input']);
        }
        break;

    case 'DELETE':
        parse_str($_SERVER['QUERY_STRING'], $queryParams);
        $userId = $queryParams['id'] ?? null;

        if ($userId) {
            if (deleteUser($pdo, $userId)) {
                http_response_code(HTTP_OK);
                echo json_encode(['message' => 'Deleted successfully', 'status' => 'success']);
            } else {
                http_response_code(HTTP_NOT_FOUND);
                echo json_encode(['message' => 'Information not found', 'status' => 'failed']);
            }
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'User ID is required']);
        }
        break;
    case 'PATCH':
        $input = json_decode(file_get_contents("php://input"), true);
        $response = saveEdit($pdo, $input);
        if ($response) {
            http_response_code(HTTP_OK);
            echo json_encode($response);
        } else {
            http_response_code(HTTP_BAD_REQUEST);
            echo json_encode(['message' => 'Invalid input']);
        }


        break;

    default:
        http_response_code(HTTP_METHOD_NOT_ALLOWED);
        echo json_encode(['message' => 'Method not allowed']);
        break;
}
