

<?php

function smsDeclineAppointment($mobile)
{

    $ch = curl_init();
    $parameters = array(
        'apikey' => '96200abeb2a535b6d13b3cc0839e2dc5', // Your API KEY
        'number' => $mobile, // Use the full international number format
        'message' => 'We regret to inform you that your appointment request has been declined.',
        'sendername' => 'SEMAPHORE'
    );
    curl_setopt($ch, CURLOPT_URL, 'https://semaphore.co/api/v4/messages');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Send the request
    $output = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        echo 'Curl error: ' . curl_error($ch);
    } else {
        // Decode the JSON response from Semaphore API
        $response = json_decode($output, true);

        // Print the response for debugging
        print_r($response);

        // echo "Message sent successfully!";
    }

    curl_close($ch);

    return true;
}


if (isset($argv[1])) {
    $mobile = $argv[1];
    smsDeclineAppointment($mobile);

} else {
    error_log("Missing parameters. Expected 1 parameter: email.");
}


?>


