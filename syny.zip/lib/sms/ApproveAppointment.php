<?php

function sendSms($mobile, $message)
{
    $ch = curl_init();
    $parameters = array(
        'apikey' => '96200abeb2a535b6d13b3cc0839e2dc5', // Your API KEY
        'number' => $mobile, // Use the full international number format
        'message' => $message,
        'sendername' => 'SEMAPHORE'
    );
    curl_setopt($ch, CURLOPT_URL, 'https://semaphore.co/api/v4/messages');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Send the request
    $output = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        $error = 'Curl error: ' . curl_error($ch);
        error_log($error); // Log the error for debugging
        curl_close($ch);
        return false;
    }

    // Decode the JSON response from Semaphore API
    $response = json_decode($output, true);

    // Log the response for debugging
    if (isset($response['status']) && $response['status'] === 'success') {
        error_log("Message sent successfully to {$mobile}");
    } else {
        error_log("Failed to send message to {$mobile}. Response: " . json_encode($response));
    }

    curl_close($ch);

    return isset($response['status']) && $response['status'] === 'success';
}

if (isset($argv[1]) && isset($argv[2])) {
    $userMobile = $argv[1];
    $doctorMobile = $argv[2];

    // Messages
    $userMessage = 'We are pleased to inform you that your appointment has been approved.';
    $doctorMessage = 'There is a new appointment assigned to you.';

    // Send SMS to the user
    if (!sendSms($userMobile, $userMessage)) {
        error_log("Failed to send SMS to user: {$userMobile}");
    }

    // Send SMS to the doctor
    if (!sendSms($doctorMobile, $doctorMessage)) {
        error_log("Failed to send SMS to doctor: {$doctorMobile}");
    }
} else {
    error_log("Missing parameters. Expected 2 parameters: user mobile and doctor mobile.");
}

// sendSms(9452084939, "testing")
?>
