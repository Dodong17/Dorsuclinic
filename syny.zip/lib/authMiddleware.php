<?php

require_once '../vendor/autoload.php';

use \Firebase\JWT\JWT;
use \Firebase\JWT\Key;



function verifyToken($token)
{
    $secret_key = "your_secret_key";
    try {
        // Decode the JWT token
        $decoded = JWT::decode($token, new Key($secret_key, 'HS256'));
        if($decoded){
            return ['status' => 'success', 'data' => $decoded];
        }else{
            return ['status' => 'failed', 'message' => 'Invalid token.'];
        }
      
    } catch (Exception $e) {
        // Handle token verification errors (e.g., invalid token, expired token)
        return ['status' => 'error', 'message' => $e->getMessage()];
    }
}
