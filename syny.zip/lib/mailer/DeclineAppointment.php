<?php
require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;




function declineAppointment($email)
{
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'dorsuclinic@gmail.com';
        $mail->Password   = 'yvxuxqamaktaqdif';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('dorsuclinic@gmail.com', 'DORSU Clinic');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Appointment Request Declined';
        $mail->Body = "Hello,<br><br>"
            . "We regret to inform you that your appointment request has been declined.<br>"
            . "Please contact us for further assistance or to reschedule.<br><br>"
            . "Thank you for your understanding,<br>"
            . "DORSU Clinic Team";



        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}
if (isset($argv[1])) {
    $email = $argv[1];

    declineAppointment($email);
} else {
    error_log("Missing parameters. Expected 1 parameter: email.");
}
