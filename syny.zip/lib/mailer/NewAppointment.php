<?php
require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;




function newAppointment($email)
{
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'dorsuclinic@gmail.com';
        $mail->Password   = 'yvxuxqamaktaqdif';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('dorsuclinic@gmail.com', 'DORSU Clinic');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'New Appointment Created';
        $mail->Body = "Hello Admin,<br><br>"
            . "A new appointment has been created in the system.<br>"
            . "Please check the dashboard for more information.<br><br>"
            . "Thank you,<br>"
            . "DORSU Clinic Team";



        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}
if (isset($argv[1])) {
    $email = $argv[1];

    newAppointment($email);
} else {
    error_log("Missing parameters. Expected 1 parameter: email.");
}
