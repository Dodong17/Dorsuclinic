<?php
require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;




function verificationLink($email, $id, $host)
{
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'dorsuclinic@gmail.com';
        $mail->Password   = 'yvxuxqamaktaqdif';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('dorsuclinic@gmail.com', 'DORSU Clinic');
        $mail->addAddress($email);

        

        


        $verificationLink = $host . "/api/verify.php?id=" .$id;


        $mail->isHTML(true);
        $mail->Subject = 'Verify Your Email Address';
        $mail->Body = "Hello,<br><br>"
            . "Thank you for reaching out to DORSU Clinic. Please verify your email address by clicking the link below:<br>"
            . "<a href='$verificationLink'>$verificationLink</a><br><br>"
            . "If you did not request this, please ignore this email.<br><br>"
            . "Thank you,<br>"
            . "DORSU Clinic Team";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}

if (isset($argv[1], $argv[2], $argv[3])) {
    $email = $argv[1];
    $id = $argv[2];
    $host = $argv[3];

    verificationLink($email, $id, $host);
} else {
    error_log("Missing parameters. Expected 1 parameter: email.");
}
