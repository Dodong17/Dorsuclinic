<?php
require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;




function approveAppointment($email, $doctorname)
{
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'dorsuclinic@gmail.com';
        $mail->Password   = 'yvxuxqamaktaqdif';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('dorsuclinic@gmail.com', 'DORSU Clinic');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Appointment Confirmation and Assigned Doctor';
        $mail->Body = "Hello,<br><br>"
            . "We are pleased to inform you that your appointment has been approved.<br>"
            . "Your assigned doctor is Dr. $doctorname. Please check your dashboard for the appointment details.<br><br>"
            . "If you have any questions, feel free to contact us.<br><br>"
            . "Thank you,<br>"
            . "DORSU Clinic Team";




        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}

function doctorsNotification($email)
{
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'dorsuclinic@gmail.com';
        $mail->Password   = 'yvxuxqamaktaqdif';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('dorsuclinic@gmail.com', 'DORSU Clinic');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'New appointment assign to you';
        $mail->Body = "Hello,<br><br>"
            . "Hello,<br>"
            . "There is new appointment assign to you.<br><br>"
            . "Thank you,<br>"
            . "DORSU Clinic Team";




        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}
if (isset($argv[1]) && isset($argv[2]) && isset($argv[3])) {
    $email = $argv[1];
    $doctoremail = $argv[2];
    $doctorname = $argv[3];

    approveAppointment($email, $doctorname);
    doctorsNotification($doctoremail);
} else {
    error_log("Missing parameters. Expected 1 parameter: email.");
}
