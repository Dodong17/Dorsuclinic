<?php
require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;




function sendDoctorsCredential($email) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'dorsuclinic@gmail.com';
        $mail->Password   = 'yvxuxqamaktaqdif';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('dorsuclinic@gmail.com', 'DORSU Clinic');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'WELCOME TO DORSU CLINIC';
        $mail->Body = "Welcome to DORSU Clinic!"
        . "Thank your for registering with us.<br>"
        . "Best regards,<br>"
        . "DORSU Clinic Team";
    


        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}
if (isset($argv[1])) {
    
    $email = $argv[1];
    sendDoctorsCredential($email);


} else {
    error_log("Missing parameters. Expected 3 parameters: email, id_number, password.");
}
?>
